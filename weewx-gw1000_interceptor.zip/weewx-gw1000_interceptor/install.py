"""
This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later
version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE.  See the GNU General Public License for more details.

                        Installer for GW1000 and Interceptor Driver

Version: 0.5.0.3kw                                        Date: May 2023

"""

# python imports
import configobj
from distutils.version import StrictVersion
from setup import ExtensionInstaller

# import StringIO, use six.moves due to python2/python3 differences
from six.moves import StringIO

# WeeWX imports
import weewx


REQUIRED_VERSION = "3.7.0"
GW1000_VERSION = "0.5.0.3kw"
# define our config as a multiline string so we can preserve comments
gw1000_config = """

[Station]
    station_type = Simulator

    station_type_new = Interceptor
    station_type_new1 = GW1000


[GW1000]
  # This section is for the GW1000 API driver.

  # How often to poll the GW1000 API, default is every 20 seconds:
  poll_interval = 20

  # The driver to use:
  driver = user.gw1000
  
  #ip_address = 192.168.0.100	# GW1100A
  port = 45000

  #wh32 = True
  #ignore_legacy_wh40_battery = True
  #show_all_batt = False
  log_unknown_fields = True
  #debug_rain = False
  #debug_wind = False
  #debug_loop = False
  #debug_sensors = False

 [[field_map_extensions]]
   batteryStatus1 = wh31_ch1_batt
   batteryStatus2 = wh31_ch2_batt
   batteryStatus3 = wh31_ch3_batt
   batteryStatus4 = wh31_ch4_batt
   batteryStatus5 = wh31_ch5_batt
   batteryStatus6 = wh31_ch6_batt
   batteryStatus7 = wh31_ch7_batt
   batteryStatus8 = wh31_ch8_batt
        
   lightning_distance = lightningdist
   lightning_disturber_count = lightningdettime
   lightning_Batt = wh57_batt
        
   co2_Temp = temp17
   co2_Hum = humid17
   pm10_0 = pm10
   pm2_5 = pm255
   co2_Batt = wh45_batt
        
   pm25_1 = pm251
   pm25_2 = pm252
   pm25_3 = pm253
   pm25_4 = pm254
   pm25_Batt1 = wh41_ch1_batt
   pm25_Batt2 = wh41_ch2_batt
   pm25_Batt3 = wh41_ch3_batt
   pm25_Batt4 = wh41_ch4_batt
        
   soilTemp1 = temp9
   soilTemp2 = temp10
   soilTemp3 = temp11
   soilTemp4 = temp12
   soilTemp5 = temp13
   soilTemp6 = temp14
   soilTemp7 = temp15
   soilTemp8 = temp16
   soilTempBatt1 = wn34_ch1_batt
   soilTempBatt2 = wn34_ch2_batt
   soilTempBatt3 = wn34_ch3_batt
   soilTempBatt4 = wn34_ch4_batt
   soilTempBatt5 = wn34_ch5_batt
   soilTempBatt6 = wn34_ch6_batt
   soilTempBatt7 = wn34_ch7_batt
   soilTempBatt8 = wn34_ch8_batt
        
   soilMoistBatt1 = wh51_ch1_batt
   soilMoistBatt2 = wh51_ch2_batt
   soilMoistBatt3 = wh51_ch3_batt
   soilMoistBatt4 = wh51_ch4_batt
   soilMoistBatt5 = wh51_ch5_batt
   soilMoistBatt6 = wh51_ch6_batt
   soilMoistBatt7 = wh51_ch7_batt
   soilMoistBatt8 = wh51_ch8_batt
        
   leak_1 = leak1
   leak_2 = leak2
   leak_3 = leak3
   leak_4 = leak4
        
   leak_Batt1 = wh55_ch1_batt
   leak_Batt2 = wh55_ch2_batt
   leak_Batt3 = wh55_ch3_batt
   leak_Batt4 = wh55_ch4_batt
        
   leafWetBatt1 = wn35_ch1_batt
   leafWetBatt2 = wn35_ch2_batt
   leafWetBatt3 = wn35_ch3_batt
   leafWetBatt4 = wn35_ch4_batt
   leafWetBatt5 = wn35_ch5_batt
   leafWetBatt6 = wn35_ch6_batt
   leafWetBatt7 = wn35_ch7_batt
   leafWetBatt8 = wn35_ch8_batt
        
   rainBatteryStatus = wh40_batt
   windBatteryStatus = ws80_batt
   hailBatteryStatus = ws90_batt
   #ws80_batt = ws80_batt
   #ws90_batt = ws90_batt

   outTempBatteryStatus = wh24_batt
   #  outTempBatteryStatus = wh26_batt
   #  outTempBatteryStatus = wh65_batt
   #  outTempBatteryStatus = wh68_batt
   inTempBatteryStatus = wh25_batt
        
   consBatteryVoltage = ws1900batt
        
   maxdailygust = daymaxwind
   pm25_24h_co2 = pm255_24h_avg
   pm10_24h_co2 = pm10_24h_avg
   pm25_avg_24h_ch1 = pm251_24h_avg
   pm25_avg_24h_ch2 = pm252_24h_avg
   pm25_avg_24h_ch3 = pm253_24h_avg
   pm25_avg_24h_ch4 = pm254_24h_avg
   
   lightningcount = lightningcount
   
   co2_24h = co2_24h_avg
   barometer = relbarometer
   
   rainrate = rainrate
   totalRain = raintotal
   eventRain = rainevent
   hourRain = t_rainhour
   dayRain = t_rainday
   weekRain = t_rainweek
   monthRain = t_rainmonth
   yearRain = t_rainyear

   rain_piezo = p_rain 
   erain_piezo = p_rainevent
   rrain_piezo = p_rainrate
   hrain_piezo = p_hourrain
   drain_piezo = p_rainday
   wrain_piezo = p_rainweek
   mrain_piezo = p_rainmonth
   yrain_piezo = p_rainyear

   hail = p_rain
   hailRate = p_rainrate

   wh24_sig = wh24_sig
   wh25_sig = wh25_sig
   wh31_ch1_sig = wh31_ch1_sig
   ws80_sig = ws80_sig
   ws90_sig = ws90_sig
   wh40_sig = wh40_sig
   wh45_sig = wh45_sig
   wh57_sig = wh57_sig
   wh51_ch1_sig = wh51_ch1_sig
   wn35_ch1_sig = wn35_ch1_sig
   wn34_ch1_sig = wn34_ch1_sig

   rain_source = rain_source
   rain_day_reset = rain_day_reset
   rain_week_reset = rain_week_reset
   rain_annual_reset = rain_annual_reset
   raingain = raingain
   gain0 = gain0
   gain1 = gain1
   gain2 = gain2
   gain3 = gain3
   gain4 = gain4
   gain5 = gain5
   gain6 = gain6
   gain7 = gain7
   gain8 = gain8
   gain9 = gain9

##############################################################################

[Interceptor]
    # This section is for the network traffic interceptor driver.
    
    # The driver to use:
    driver = user.interceptor
    
    # Specify the hardware device to capture.  Options include:
    #   acurite-bridge - acurite internet bridge, smarthub, or access
    #   observer - fine offset WH2600/HP1000/HP1003, ambient WS2902
    #   lw30x - oregon scientific LW301/LW302
    #   lacrosse-bridge - lacrosse GW1000U/C84612 internet bridge
    #   ecowitt-client - any hardware that uses the ecowitt protocol
    #   wu-client - any hardware that uses the weather underground protocol
    device_type = ecowitt-client
    port = 8575
    iface = eth0
    #iface = wlan0 
    
  [[sensor_map_extensions]]
   co2 = co2
   co2_Temp = tf_co2 
   co2_Hum = humi_co2 
   co2_Batt = co2_batt 
   pm10_0 = pm10_co2  
   pm2_5 = pm25_co2  
   pm25_1 = pm25_ch1
   pm25_2 = pm25_ch2
   pm25_3 = pm25_ch3
   pm25_4 = pm25_ch4
   pm25_Batt1 = pm25batt1 
   pm25_Batt2 = pm25batt2
   pm25_Batt3 = pm25batt3
   pm25_Batt4 = pm25batt4

   batteryStatus1 = battery_1
   batteryStatus2 = battery_2
   batteryStatus3 = battery_3
   batteryStatus4 = battery_4
   batteryStatus5 = battery_5
   batteryStatus6 = battery_6
   batteryStatus7 = battery_7
   batteryStatus8 = battery_8

   soilMoist5 = soil_moisture_5 
   soilMoist6 = soil_moisture_6
   soilMoist7 = soil_moisture_7
   soilMoist8 = soil_moisture_8
   soilMoistBatt1 = soilbatt1
   soilMoistBatt2 = soilbatt2
   soilMoistBatt3 = soilbatt3
   soilMoistBatt4 = soilbatt4
   soilMoistBatt5 = soilbatt5
   soilMoistBatt6 = soilbatt6
   soilMoistBatt7 = soilbatt7
   soilMoistBatt8 = soilbatt8

   soilTemp1 = tf_ch1
   soilTemp2 = tf_ch2
   soilTemp3 = tf_ch3
   soilTemp4 = tf_ch4
   soilTemp5 = tf_ch5
   soilTemp6 = tf_ch6
   soilTemp7 = tf_ch7
   soilTemp8 = tf_ch8
   soilTempBatt1 = tf_batt1
   soilTempBatt2 = tf_batt2
   soilTempBatt3 = tf_batt3
   soilTempBatt4 = tf_batt4
   soilTempBatt5 = tf_batt5
   soilTempBatt6 = tf_batt6
   soilTempBatt7 = tf_batt7
   soilTempBatt8 = tf_batt8

   leafWet1 = leafwetness_ch1
   leafWet2 = leafwetness_ch2
   leafWet3 = leafwetness_ch3
   leafWet4 = leafwetness_ch4
   leafWet5 = leafwetness_ch5
   leafWet6 = leafwetness_ch6
   leafWet7 = leafwetness_ch7
   leafWet8 = leafwetness_ch8
   leafWetBatt1 = leaf_batt1
   leafWetBatt2 = leaf_batt2
   leafWetBatt3 = leaf_batt3
   leafWetBatt4 = leaf_batt4
   leafWetBatt5 = leaf_batt5
   leafWetBatt6 = leaf_batt6
   leafWetBatt7 = leaf_batt7
   leafWetBatt8 = leaf_batt8
   leak_1 = leak_ch1
   leak_2 = leak_ch2
   leak_3 = leak_ch3
   leak_4 = leak_ch4
   leak_Batt1 = leakbatt1
   leak_Batt2 = leakbatt2
   leak_Batt3 = leakbatt3
   leak_Batt4 = leakbatt4
   lightning_distance = lightning
   lightning_disturber_count = lightning_time
   lightning_strike_count = lightning_num
   lightning_Batt = wh57batt

   maxdailygust = maxdailygust
   winddir_avg10m = winddir_avg10m
   windspdmph_avg10m = windspdmph_avg10m

   pm25_24h_co2 = pm25_24h_co2
   pm10_24h_co2 = pm10_24h_co2
   pm25_avg_24h_ch1 = pm25_avg_24h_ch1
   pm25_avg_24h_ch2 = pm25_avg_24h_ch2
   pm25_avg_24h_ch3 = pm25_avg_24h_ch3
   pm25_avg_24h_ch4 = pm25_avg_24h_ch4

   consBatteryVoltage = ws1900batt
        
   rainBatteryStatus = wh40batt
   hailBatteryStatus = wh90batt
   windBatteryStatus = wh80batt
   ws90_batt = wh90batt
   ws80_batt = wh80batt

   outTempBatteryStatus = wh65batt
   #  outTempBatteryStatus = wh26batt
   inTempBatteryStatus = wh25batt

   rainrate = rainratein
   totalRain = rain_total
   eventRain = rainevent
   hourRain = hourlyrainin
   dayRain = dailyrainin
   weekRain = weeklyrainin
   monthRain = monthlyrainin
   yearRain = rainyear

   rain_piezo = rain_piezo
   rrain_piezo = rrain_piezo
   erain_piezo = erain_piezo
   hrain_piezo = hrain_piezo
   drain_piezo = drain_piezo
   wrain_piezo = wrain_piezo
   mrain_piezo = mrain_piezo
   yrain_piezo = yrain_piezo

   ws90cap_volt = ws90cap_volt
   ws90_ver = ws90_ver

   runtime = runtime
   ws_interval = interval

   model = model
   stationtype = stationtype

   gain0 = gain0
   gain1 = gain1
   gain2 = gain2
   gain3 = gain3
   gain4 = gain4
   gain5 = gain5
   gain6 = gain6
   gain7 = gain7
   gain8 = gain8
   gain9 = gain9

##############################################################################

[StdReport]
    [[Defaults]]
        [[[Units]]]

            [[[[Labels]]]]
                centibar = %
##############################################################################
[DataBindings]
    
    [[wx_binding]]
        database = archive_sqlite
        table_name = archive
        manager = weewx.manager.DaySummaryManager
        schema = schemas.wview_extended.schema
        schema_new = schemas.wview_ecowitt.schema

##############################################################################
[Databases]
    
    # A SQLite database is simply a single file
    [[archive_sqlite]]
        database_name = weewx.sdb
        database_name_new = weewx_ecowitt.sdb
        database_type = SQLite

##############################################################################
[StdArchive]

    record_generation = software
    record_generation_new = software	# GW1000/GW1100/WH2650
##############################################################################
[StdCalibrate]
    
    [[Corrections]]
        # For each type, an arbitrary calibration expression can be given.
        # It should be in the units defined in the StdConvert section.
        # Example:
        foo = foo + 0.2
        radiation = luminosity / 126.7 if luminosity is not None else None
        #luminosity = radiation * 126.7

        hail = p_rain if p_rain is not None else None
        hailRate = p_rainrate if p_rainrate is not None else None

        rxCheckPercent = wh65_sig * 25 if wh65_sig is not None else None
        1rxCheckPercent = wh24_sig * 25 if wh24_sig is not None else None
        2rxCheckPercent = wh25_sig * 25 if wh25_sig is not None else None
        3rxCheckPercent = wh68_sig * 25 if wh68_sig is not None else None
        4rxCheckPercent = ws80_sig * 25 if ws80_sig is not None else None
        5rxCheckPercent = ws90_sig * 25 if ws90_sig is not None else None

        1signal1 = wh24_sig * 25 if wh24_sig is not None else None
        2signal2 = wh31_ch1_sig * 25 if wh31_ch1_sig is not None else None
        3signal3 = wh34_ch1_sig * 25 if wh34_ch1_sig is not None else None
        4signal4 = wh40_sig * 25 if wh40_sig is not None else None
        5signal5 = wh45_sig * 25 if wh45_sig is not None else None
        6signal6 = wh57_sig * 25 if wh57_sig is not None else None
        7signal7 = wh51_ch1_sig * 25 if wh51_ch1_sig is not None else None
        8signal8 = wh35_ch1_sig * 25 if wh35_ch1_sig is not None else None

##############################################################################
[StdWXCalculate]

    [[WXXTypes]]
        [[[maxSolarRad]]]
          algorithm = rs	    # default
          atc = 0.9		    # default 0.8 - atmospheric transmission coefficient [0.7-0.91]

    [[Calculations]]

        GTS = software, archive
        GTSdate = software, archive
        utcoffsetLMT = software, archive
        dayET = prefer_hardware, archive
        ET24 = prefer_hardware, archive
        yearGDD = software, archive
        seasonGDD = software, archive

##############################################################################
[Engine]
    # The following section specifies which services should be run and in what order.
    [[Services]]
        data_services = ,
        data_services_new = user.gw1000.Gw1000Service
        process_services_new = weewx.engine.StdConvert, weewx.engine.StdCalibrate, weewx.engine.StdQC, weewx.wxservices.StdWXCalculate, user.sunrainduration.SunshineDuration
        xtype_services_new = weewx.wxxtypes.StdWXXTypes, weewx.wxxtypes.StdPressureCooker, weewx.wxxtypes.StdRainRater, weewx.wxxtypes.StdDelta, user.GTS.GTSService

##############################################################################
[RadiationDays]
    min_sunshine = 120
    sunshine_log = 0
    sunshine_coeff = 0.92
    sunshine_min = 18
    rainDur_log = 0
    hailDur_log = 0

##############################################################################
# Options for extension 'GW1000' and Interceptor
[Accumulator]

   [[model]]
        accumulator = firstlast
        extractor = last
   [[stationtype]]
        accumulator = firstlast
        extractor = last

    [[gain0]]
        extractor = last
    [[gain1]]
        extractor = last
    [[gain2]]
        extractor = last
    [[gain3]]
        extractor = last
    [[gain4]]
        extractor = last
    [[gain5]]
        extractor = last

    [[lightning_distance]]
        extractor = last
    [[lightning_strike_count]]
        extractor = sum
    [[lightning_last_det_time]]
        extractor = last
    [[lightningcount]]
        extractor = last

    [[daymaxwind]]
        extractor = last
    [[windspdmph_avg10m]]
        extractor = last
    [[winddir_avg10m]]
        extractor = last

    [[rainRate]]
        extractor = max
    [[stormRain]]
        extractor = last
    [[hourRain]]
        extractor = last
    [[dayRain]]
        extractor = last
    [[weekRain]]
        extractor = last
    [[monthRain]]
        extractor = last
    [[yearRain]]
        extractor = last
    [[totalRain]]
        extractor = last

    [[rrain_piezo]]
        extractor = max
    [[erain_piezo]]
        extractor = last
    [[hrain_piezo]]
        extractor = last
    [[drain_piezo]]
        extractor = last
    [[wrain_piezo]]
        extractor = last
    [[mrain_piezo]]
        extractor = last
    [[yrain_piezo]]
        extractor = last

    [[p_rainrate]]
        extractor = max
    [[p_eventrain]]
        extractor = last
    [[p_hourrain]]
        extractor = last
    [[p_dayrain]]
        extractor = last
    [[p_weekrain]]
        extractor = last
    [[p_monthrain]]
        extractor = last
    [[p_yearrain]]
        extractor = last

    [[dayHail]]
        extractor = last
    [[hail]]
        extractor = sum

    [[pm2_51_24hav]]
        extractor = last
    [[pm2_52_24hav]]
        extractor = last
    [[pm2_53_24hav]]
        extractor = last
    [[pm2_54_24hav]]
        extractor = last
    [[24havpm255]]
        extractor = last

    [[pm2_51_24h_avg]]
        extractor = last
    [[pm2_52_24h_avg]]
        extractor = last
    [[pm2_53_24h_avg]]
        extractor = last
    [[pm2_54_24h_avg]]
        extractor = last
    [[pm2_55_24h_avg]]
        extractor = last
    [[pm10_24h_avg]]
        extractor = last
    [[co2_24h_avg]]
        extractor = last

    [[wh25_batt]]
        extractor = last
    [[wh26_batt]]
        extractor = last
    [[wh31_ch1_batt]]
        extractor = last
    [[wh31_ch2_batt]]
        extractor = last
    [[wh31_ch3_batt]]
        extractor = last
    [[wh31_ch4_batt]]
        extractor = last
    [[wh31_ch5_batt]]
        extractor = last
    [[wh31_ch6_batt]]
        extractor = last
    [[wh31_ch7_batt]]
        extractor = last
    [[wh31_ch8_batt]]
        extractor = last
    [[wn35_ch1_batt]]
        extractor = last
    [[wn35_ch2_batt]]
        extractor = last
    [[wn35_ch3_batt]]
        extractor = last
    [[wn35_ch4_batt]]
        extractor = last
    [[wn35_ch5_batt]]
        extractor = last
    [[wn35_ch6_batt]]
        extractor = last
    [[wn35_ch7_batt]]
        extractor = last
    [[wn35_ch8_batt]]
        extractor = last
    [[wh40_batt]]
        extractor = last
    [[wh41_ch1_batt]]
        extractor = last
    [[wh41_ch2_batt]]
        extractor = last
    [[wh41_ch3_batt]]
        extractor = last
    [[wh41_ch4_batt]]
        extractor = last
    [[wh45_batt]]
        extractor = last
    [[wh51_ch1_batt]]
        extractor = last
    [[wh51_ch2_batt]]
        extractor = last
    [[wh51_ch3_batt]]
        extractor = last
    [[wh51_ch4_batt]]
        extractor = last
    [[wh51_ch5_batt]]
        extractor = last
    [[wh51_ch6_batt]]
        extractor = last
    [[wh51_ch7_batt]]
        extractor = last
    [[wh51_ch8_batt]]
        extractor = last
    [[wh51_ch9_batt]]
        extractor = last
    [[wh51_ch10_batt]]
        extractor = last
    [[wh51_ch11_batt]]
        extractor = last
    [[wh51_ch12_batt]]
        extractor = last
    [[wh51_ch13_batt]]
        extractor = last
    [[wh51_ch14_batt]]
        extractor = last
    [[wh51_ch15_batt]]
        extractor = last
    [[wh51_ch16_batt]]
        extractor = last
    [[wh55_ch1_batt]]
        extractor = last
    [[wh55_ch2_batt]]
        extractor = last
    [[wh55_ch3_batt]]
        extractor = last
    [[wh55_ch4_batt]]
        extractor = last
    [[wh57_batt]]
        extractor = last
    [[wh65_batt]]
        extractor = last
    [[wh68_batt]]
        extractor = last
    [[ws80_batt]]
        extractor = last
    [[ws90_batt]]
        extractor = last
    [[ws90cap_volt]]
        extractor = last
    [[ws1900batt]]
        extractor = last


    [[wh25_sig]]
        extractor = last
    [[wh26_sig]]
        extractor = last
    [[wh31_ch1_sig]]
        extractor = last
    [[wh31_ch2_sig]]
        extractor = last
    [[wh31_ch3_sig]]
        extractor = last
    [[wh31_ch4_sig]]
        extractor = last
    [[wh31_ch5_sig]]
        extractor = last
    [[wh31_ch6_sig]]
        extractor = last
    [[wh31_ch7_sig]]
        extractor = last
    [[wh31_ch8_sig]]
        extractor = last
    [[wn34_ch1_sig]]
        extractor = last
    [[wn34_ch2_sig]]
        extractor = last
    [[wn34_ch3_sig]]
        extractor = last
    [[wn34_ch4_sig]]
        extractor = last
    [[wn34_ch5_sig]]
        extractor = last
    [[wn34_ch6_sig]]
        extractor = last
    [[wn34_ch7_sig]]
        extractor = last
    [[wn34_ch8_sig]]
        extractor = last
    [[wn35_ch1_sig]]
        extractor = last
    [[wn35_ch2_sig]]
        extractor = last
    [[wn35_ch3_sig]]
        extractor = last
    [[wn35_ch4_sig]]
        extractor = last
    [[wn35_ch5_sig]]
        extractor = last
    [[wn35_ch6_sig]]
        extractor = last
    [[wn35_ch7_sig]]
        extractor = last
    [[wn35_ch8_sig]]
        extractor = last
    [[wh40_sig]]
        extractor = last
    [[wh41_ch1_sig]]
        extractor = last
    [[wh41_ch2_sig]]
        extractor = last
    [[wh41_ch3_sig]]
        extractor = last
    [[wh41_ch4_sig]]
        extractor = last
    [[wh45_sig]]
        extractor = last
    [[wh51_ch1_sig]]
        extractor = last
    [[wh51_ch2_sig]]
        extractor = last
    [[wh51_ch3_sig]]
        extractor = last
    [[wh51_ch4_sig]]
        extractor = last
    [[wh51_ch5_sig]]
        extractor = last
    [[wh51_ch6_sig]]
        extractor = last
    [[wh51_ch7_sig]]
        extractor = last
    [[wh51_ch8_sig]]
        extractor = last
    [[wh51_ch9_sig]]
        extractor = last
    [[wh51_ch10_sig]]
        extractor = last
    [[wh51_ch11_sig]]
        extractor = last
    [[wh51_ch12_sig]]
        extractor = last
    [[wh51_ch13_sig]]
        extractor = last
    [[wh51_ch14_sig]]
        extractor = last
    [[wh51_ch15_sig]]
        extractor = last
    [[wh51_ch16_sig]]
        extractor = last
    [[wh55_ch1_sig]]
        extractor = last
    [[wh55_ch2_sig]]
        extractor = last
    [[wh55_ch3_sig]]
        extractor = last
    [[wh55_ch4_sig]]
        extractor = last
    [[wh57_sig]]
        extractor = last
    [[wh65_sig]]
        extractor = last
    [[wh68_sig]]
        extractor = last
    [[ws80_sig]]
        extractor = last
    [[ws90_sig]]
        extractor = last

    # End GW1000 and Interceptor driver extractors
##############################################################################
"""

# construct our config dict
gw1000_dict = configobj.ConfigObj(StringIO(gw1000_config))


def loader():
    return Gw1000Installer()


class Gw1000Installer(ExtensionInstaller):
    def __init__(self):
        if StrictVersion(weewx.__version__) < StrictVersion(REQUIRED_VERSION):
            msg = "%s requires WeeWX %s or greater, found %s" % (''.join(('GW1000 driver ', GW1000_VERSION)),
                                                                 REQUIRED_VERSION,
                                                                 weewx.__version__)
            raise weewx.UnsupportedFeature(msg)
        super(Gw1000Installer, self).__init__(
            version=GW1000_VERSION,
            name='GW1000',
            description='WeeWX driver for Ecowitt gateways.',
            author="Gary Roderick - Werner Krenn",
            author_email="gjroderick<@>gmail.com",
#           files=[('bin/user', ['bin/user/gw1000.py'])],
            files=[
                ('bin/user', [
                    'bin/user/gw1000.py',
                    'bin/user/interceptor.py',
                    'bin/user/extensions.py',
                    'bin/user/GTS.py',
                    'bin/user/dayboundarystats.py',
                    'bin/user/historygenerator.py',
                    'bin/user/historygenerator4.py',
                    'bin/user/sunevents.py',
                    'bin/user/jsonengine.py',
                    'bin/user/largeimagegenerator.py',
                    'bin/user/sunrainduration.py',
                ]),
                ('bin/schemas', [
                    'bin/schemas/wview_ecowitt.py',
                ]),
                ('skins/nws', [
                    'skins/Seasons/index.html.tmpl',
                    'skins/Seasons/telemetry.html.tmpl',
                    'skins/Seasons/skin.conf',
                    'skins/Seasons/seasons.css',
                    'skins/Seasons/seasons.js',
                    'skins/Seasons/current.inc',
                    'skins/Seasons/hilo.inc',
                    'skins/Seasons/sensors.inc',
                    'skins/Seasons/about.inc',
                    'skins/Seasons/statistics.inc',
                    'skins/Seasons/Batt0.png',
                    'skins/Seasons/Batt1.png',
                    'skins/Seasons/Batt2.png',
                    'skins/Seasons/Batt3.png',
                    'skins/Seasons/Batt4.png',
                    'skins/Seasons/Batt5.png',
                    'skins/Seasons/Batt6.png',
                    'skins/Seasons/Batt6x.png',
                    'skins/Seasons/lang/de.conf',
                ]),
            ],
            config=gw1000_dict
         )


