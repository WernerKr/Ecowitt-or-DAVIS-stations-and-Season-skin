# installer for the weewx-ecowittcustom driver
# Copyright 2025/2026 Werner Krenn
# Distributed under the terms of the GNU Public License (GPLv3)
# Set this station:  sudo weectl station reconfigure --driver user.ecowittcustom

# python imports
import configobj
from setup import ExtensionInstaller

# import StringIO, use six.moves due to python2/python3 differences
from six.moves import StringIO

# WeeWX imports
import weewx


REQUIRED_VERSION = "3.7.0"
Ecowittcustom_VERSION = "0.2.0"
# define our config as a multiline string so we can preserve comments
ecowittcustom_config = """
[Station]

  station_type_new = Ecowittcustom

##############################################################################

[Ecowittcustom]
# set this station:  sudo weectl station reconfigure --driver user.ecowittcustom
# iface = wlan0
  iface = eth0
  device_type = ecowitt-client
  port = 8080
  driver = user.ecowittcustom

##############################################################################
[StdReport]

    [[SeasonsReport]]
        skin = Seasons
        enable = false
        HTML_ROOT = /var/www/html/weewx/old

    [[SeasonsEcowitt]]
# lang = de
        lang = en
        skin = SeasonsEcowitt
        enable = true
        HTML_ROOT = /var/www/html/weewx

##############################################################################
[DataBindings]
    
    [[wx_binding]]
        database = archive_sqlite
        table_name = archive
        manager = weewx.manager.DaySummaryManager

        schema = schemas.wview_ecowitt.schema
        schema_new = schemas.wview_ecowitt.schema
        schema_all = schemas.wview_ecowitt_all.schema

##############################################################################
[Databases]
    
    [[archive_sqlite]]
        database_name = weewx_ecowitt.sdb
        database_name_new = weewx_ecowitt.sdb
        database_type = SQLite

##############################################################################
[StdWXCalculate]
    #  [[WXXTypes]]
    #    [[[windDir]]]
    #       force_null = True
    #    [[[maxSolarRad]]]
    #      algorithm = rs
    #      atc = 0.8
    #      nfac = 2
    #    [[[ET]]]
    #      wind_height = 2.0
    #      et_period = 3600
    #    [[[heatindex]]]
    #      algorithm = new
    #  [[PressureCooker]]
    #    max_delta_12h = 1800
    #    [[[altimeter]]]
    #      algorithm = aaASOS    # Case-sensitive!
    #  [[RainRater]]
    #    rain_period = 900
    #    retain_period = 930
    #  [[Delta]]
    #    [[[rain]]]
    #      input = totalRain

      [[WXXTypes]]
        [[[maxSolarRad]]]
          algorithm = rs	    # default
          atc = 0.9		    # default 0.8 - atmospheric transmission coefficient [0.7-0.91]

[StdArchive]
    record_generation = hardware
    record_generation_new = hardware

[StdCalibrate]
    
    [[Corrections]]
        # luminosity = radiation * 126.7
        radiation = luminosity / 126.7 if luminosity is not None else None

        rxCheckPercent = ws80_sig * 25 if ws80_sig is not None else None

        # rxCheckPercent = wh24_sig * 25 if wh24_sig is not None else None
        # rxCheckPercent = wh25_sig * 25 if wh25_sig is not None else None
        # rxCheckPercent = wh68_sig * 25 if wh68_sig is not None else None
        # rxCheckPercent = wh65_sig * 25 if wh65_sig is not None else None

        #hail = p_rain if p_rain is not None else None
        #hailRate = p_rainrate if p_rainrate is not None else None

        ws90_sig = ws90_sig * 25 if ws90_sig is not None else None
        ws85_sig = ws85_sig * 25 if ws85_sig is not None else None
        wh54_ch1_sig = wh54_ch1_sig * 25 if wh54_ch1_sig is not None else None 
        pb = heap if heap is not None else None

        lightning_distance_save = lightning_distance if lightning_distance is not None else None
        lightning_distance = lightning_distance if lightning_strike_count > 0 else None
        lightning_noise_count = lightning_strike_count if lightning_strike_count > 0 else None

[Engine]
   [[Services]]

     process_services_new = weewx.engine.StdConvert, weewx.engine.StdCalibrate, weewx.engine.StdQC, weewx.wxservices.StdWXCalculate, user.sunrainduration.SunshineDuration
     process_services_new_altern = weewx.engine.StdConvert, weewx.engine.StdCalibrate, weewx.engine.StdQC, weewx.wxservices.StdWXCalculate, user.sunrainduration.SunshineDuration, user.radiationhours.RadiationHours, user.cmon.ComputerMonitor
     xtype_services_new = weewx.wxxtypes.StdWXXTypes, weewx.wxxtypes.StdPressureCooker, weewx.wxxtypes.StdRainRater, weewx.wxxtypes.StdDelta, user.GTS.GTSService

##############################################################################
[RadiationDays]
    sunshine_coeff = 0.90
    sunshine_min = 18
    sunshine_loop = 1
    rainDur_loop = 0
    hailDur_loop = 0
    sunshine_log = 0
    rainDur_log = 0
    hailDur_log = 0

##############################################################################
# Options for extension 'Ecowittcustom'
[Accumulator]

   [[model]]
        accumulator = firstlast
        extractor = last
   [[stationtype]]
        accumulator = firstlast
        extractor = last

    [[gain0]]
        extractor = last
    [[gain1]]
        extractor = last
    [[gain2]]
        extractor = last
    [[gain3]]
        extractor = last
    [[gain4]]
        extractor = last
    [[gain5]]
        extractor = last

    [[lightning_distance]]
        extractor = last
    [[lightning_strike_count]]
        extractor = sum
    [[lightning_last_det_time]]
        extractor = last
    [[lightningcount]]
        extractor = last
    [[lightning_noise_count]]
        extractor = sum

    [[daymaxwind]]
        extractor = last
    [[windspdmph_avg10m]]
        extractor = last
    [[winddir_avg10m]]
        extractor = last

    [[rainRate]]
        extractor = max
    [[stormRain]]
        extractor = last
    [[hourRain]]
        extractor = last
    [[dayRain]]
        extractor = last
    [[weekRain]]
        extractor = last
    [[monthRain]]
        extractor = last
    [[yearRain]]
        extractor = last
    [[totalRain]]
        extractor = last

    [[rrain_piezo]]
        extractor = max
    [[erain_piezo]]
        extractor = last
    [[hrain_piezo]]
        extractor = last
    [[drain_piezo]]
        extractor = last
    [[wrain_piezo]]
        extractor = last
    [[mrain_piezo]]
        extractor = last
    [[yrain_piezo]]
        extractor = last

    [[p_rainrate]]
        extractor = max
    [[p_eventrain]]
        extractor = last
    [[p_hourrain]]
        extractor = last
    [[p_dayrain]]
        extractor = last
    [[p_weekrain]]
        extractor = last
    [[p_monthrain]]
        extractor = last
    [[p_yearrain]]
        extractor = last

    [[dayHail]]
        extractor = last
    [[hail]]
        extractor = sum

    [[vpd]]
        extractor = last
    [[depth_ch1]]
        extractor = last
    [[depth_ch2]]
        extractor = last

    [[pm2_51_24hav]]
        extractor = last
    [[pm2_52_24hav]]
        extractor = last
    [[pm2_53_24hav]]
        extractor = last
    [[pm2_54_24hav]]
        extractor = last
    [[24havpm255]]
        extractor = last

    [[pm2_51_24h_avg]]
        extractor = last
    [[pm2_52_24h_avg]]
        extractor = last
    [[pm2_53_24h_avg]]
        extractor = last
    [[pm2_54_24h_avg]]
        extractor = last
    [[pm2_55_24h_avg]]
        extractor = last
    [[pm10_24h_avg]]
        extractor = last
    [[co2_24h_avg]]
        extractor = last

    [[wh25_batt]]
        extractor = last
    [[wh26_batt]]
        extractor = last
    [[wh31_ch1_batt]]
        extractor = last
    [[wh31_ch2_batt]]
        extractor = last
    [[wh31_ch3_batt]]
        extractor = last
    [[wh31_ch4_batt]]
        extractor = last
    [[wh31_ch5_batt]]
        extractor = last
    [[wh31_ch6_batt]]
        extractor = last
    [[wh31_ch7_batt]]
        extractor = last
    [[wh31_ch8_batt]]
        extractor = last
    [[wn35_ch1_batt]]
        extractor = last
    [[wn35_ch2_batt]]
        extractor = last
    [[wn35_ch3_batt]]
        extractor = last
    [[wn35_ch4_batt]]
        extractor = last
    [[wn35_ch5_batt]]
        extractor = last
    [[wn35_ch6_batt]]
        extractor = last
    [[wn35_ch7_batt]]
        extractor = last
    [[wn35_ch8_batt]]
        extractor = last
    [[wh40_batt]]
        extractor = last
    [[wh41_ch1_batt]]
        extractor = last
    [[wh41_ch2_batt]]
        extractor = last
    [[wh41_ch3_batt]]
        extractor = last
    [[wh41_ch4_batt]]
        extractor = last
    [[wh45_batt]]
        extractor = last
    [[wh51_ch1_batt]]
        extractor = last
    [[wh51_ch2_batt]]
        extractor = last
    [[wh51_ch3_batt]]
        extractor = last
    [[wh51_ch4_batt]]
        extractor = last
    [[wh51_ch5_batt]]
        extractor = last
    [[wh51_ch6_batt]]
        extractor = last
    [[wh51_ch7_batt]]
        extractor = last
    [[wh51_ch8_batt]]
        extractor = last
    [[wh51_ch9_batt]]
        extractor = last
    [[wh51_ch10_batt]]
        extractor = last
    [[wh51_ch11_batt]]
        extractor = last
    [[wh51_ch12_batt]]
        extractor = last
    [[wh51_ch13_batt]]
        extractor = last
    [[wh51_ch14_batt]]
        extractor = last
    [[wh51_ch15_batt]]
        extractor = last
    [[wh51_ch16_batt]]
        extractor = last
    [[wh55_ch1_batt]]
        extractor = last
    [[wh55_ch2_batt]]
        extractor = last
    [[wh55_ch3_batt]]
        extractor = last
    [[wh55_ch4_batt]]
        extractor = last
    [[wh57_batt]]
        extractor = last
    [[wh65_batt]]
        extractor = last
    [[wh68_batt]]
        extractor = last
    [[ws80_batt]]
        extractor = last
    [[ws85_batt]]
        extractor = last
    [[ws90_batt]]
        extractor = last
    [[ws85cap_volt]]
        extractor = last
    [[ws90cap_volt]]
        extractor = last
    [[ws1900batt]]
        extractor = last
    [[console_batt]]
        extractor = last

    # End GW1000 and Ecowittcustom driver extractors

"""

# construct our config dict

ecowittcustom_dict = configobj.ConfigObj(StringIO(ecowittcustom_config))

def version_compare(v1, v2):
    """Basic 'distutils' and 'packaging' free version comparison.

    v1 and v2 are WeeWX version numbers in string format.

    Returns:
        0 if v1 and v2 are the same
        -1 if v1 is less than v2
        +1 if v1 is greater than v2
    """

    import itertools
    mash = itertools.zip_longest(v1.split('.'), v2.split('.'), fillvalue='0')
    for x1, x2 in mash:
        if x1 > x2:
            return 1
        if x1 < x2:
            return -1
    return 0

def loader():
    return EcowittcustomInstaller()

class EcowittcustomInstaller(ExtensionInstaller):
    def __init__(self):
        if version_compare(weewx.__version__, REQUIRED_VERSION) < 0:
            msg = "%s requires WeeWX %s or greater, found %s" % (''.join(('Ecowittcustom driver ', Ecowittcustom_VERSION)),
                                                                 REQUIRED_VERSION,
                                                                 weewx.__version__)
            raise weewx.UnsupportedFeature(msg)

        super(EcowittcustomInstaller, self).__init__(
            version=Ecowittcustom_VERSION,
            name='ecowittcustom',
            description='Capture weather data from HTTP requests (Ecowitt_client or WU_client)',
            author="Werner Krenn",
            author_email="",
            #data_services=,
            files=[
                ('bin/user', [
                    'bin/user/ecowittcustom.py',
                    'bin/user/historygenerator3.py',
                    'bin/user/sunrainduration.py',
                ]),
                ('bin/schemas', [
                    'bin/schemas/wview_ecowitt.py',
                    'bin/schemas/wview_ecowitt_all.py',
                ]),
                ('skins', [
                    'skins/SeasonsEcowitt/index.html.tmpl',
                    'skins/SeasonsEcowitt/telemetry.html.tmpl',
                    'skins/SeasonsEcowitt/celestial.html.tmpl',
                    'skins/SeasonsEcowitt/rss.xml.tmpl',
                    'skins/SeasonsEcowitt/statistics.html.tmpl',
                    'skins/SeasonsEcowitt/tabular.html.tmpl',
                    'skins/SeasonsEcowitt/skin.conf',
                    'skins/SeasonsEcowitt/seasons.css',
                    'skins/SeasonsEcowitt/seasons.js',
                    'skins/SeasonsEcowitt/current.inc',
                    'skins/SeasonsEcowitt/hilo.inc',
                    'skins/SeasonsEcowitt/sensors.inc',
                    'skins/SeasonsEcowitt/about.inc',
                    'skins/SeasonsEcowitt/titlebar.inc',
                    'skins/SeasonsEcowitt/statistics.inc',
                    'skins/SeasonsEcowitt/analytics.inc',
                    'skins/SeasonsEcowitt/celestial.inc',
                    'skins/SeasonsEcowitt/identifier.inc',
                    'skins/SeasonsEcowitt/map.inc',
                    'skins/SeasonsEcowitt/sunmoon.inc',
                    'skins/SeasonsEcowitt/radar.inc',
                    'skins/SeasonsEcowitt/satellite.inc',
                    'skins/SeasonsEcowitt/mobile.inc',
                    'skins/SeasonsEcowitt/standard.inc',
                    'skins/SeasonsEcowitt/neowx.inc',
                    'skins/SeasonsEcowitt/belchertown.inc',
                    'skins/SeasonsEcowitt/amphibian.inc',
                    'skins/SeasonsEcowitt/smartphone.inc',
                    'skins/SeasonsEcowitt/cmon.inc',
                    'skins/SeasonsEcowitt/Batt0.png',
                    'skins/SeasonsEcowitt/Batt1.png',
                    'skins/SeasonsEcowitt/Batt2.png',
                    'skins/SeasonsEcowitt/Batt3.png',
                    'skins/SeasonsEcowitt/Batt4.png',
                    'skins/SeasonsEcowitt/Batt5.png',
                    'skins/SeasonsEcowitt/Batt6.png',
                    'skins/SeasonsEcowitt/Batt6x.png',
                    'skins/SeasonsEcowitt/lang/de.conf',
                    'skins/SeasonsEcowitt/lang/en.conf',
                    'skins/SeasonsEcowitt/NOAA/NOAA-%Y-%m.txt.tmpl',
                    'skins/SeasonsEcowitt/NOAA/NOAA-%Y.txt.tmpl',
                    'skins/SeasonsEcowitt/font/OpenSans-Bold.ttf',
                    'skins/SeasonsEcowitt/font/OpenSans-Regular.ttf',
                    'skins/SeasonsEcowitt/font/OpenSans.woff',
                    'skins/SeasonsEcowitt/font/OpenSans.woff2',
                    'skins/SeasonsEcowitt/font/OFL.txt',
                    'skins/SeasonsEcowitt/font/license.txt',
                ])
            ],
            config=ecowittcustom_dict
        )
