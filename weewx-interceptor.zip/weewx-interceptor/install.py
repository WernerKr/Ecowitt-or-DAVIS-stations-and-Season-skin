# installer for the weewx-interceptor driver
# Copyright 2016 Matthew Wall, all rights reserved
# Distributed under the terms of the GNU Public License (GPLv3)
# Modified for Ecowitt stations (only ecowitt-client) , Werner Krenn, 2023

#import sys
#import weewx
#from weecfg.extension import ExtensionInstaller

# python imports
import configobj
from distutils.version import StrictVersion
from setup import ExtensionInstaller

# import StringIO, use six.moves due to python2/python3 differences
from six.moves import StringIO

# WeeWX imports
import weewx

REQUIRED_VERSION = "3.7.0"
Interceptor_VERSION = "0.55kw"
# define our config as a multiline string so we can preserve comments
interceptor_config = """
[Station]

  station_type = Interceptor
  station_type_new = Interceptor

[Interceptor]
  device_type = ecowitt-client
  port = 8574
  iface = eth0
  #iface = wlan0 
  
  [[sensor_map_extensions]]
   co2 = co2
   co2_Temp = tf_co2 
   co2_Hum = humi_co2 
   co2_Batt = co2_batt 
   pm10_0 = pm10_co2  
   pm2_5 = pm25_co2  
   pm25_1 = pm25_ch1
   pm25_2 = pm25_ch2
   pm25_3 = pm25_ch3
   pm25_4 = pm25_ch4
   pm25_Batt1 = pm25batt1 
   pm25_Batt2 = pm25batt2
   pm25_Batt3 = pm25batt3
   pm25_Batt4 = pm25batt4

   batteryStatus1 = battery_1
   batteryStatus2 = battery_2
   batteryStatus3 = battery_3
   batteryStatus4 = battery_4
   batteryStatus5 = battery_5
   batteryStatus6 = battery_6
   batteryStatus7 = battery_7
   batteryStatus8 = battery_8

   soilMoist5 = soil_moisture_5 
   soilMoist6 = soil_moisture_6
   soilMoist7 = soil_moisture_7
   soilMoist8 = soil_moisture_8
   soilMoistBatt1 = soilbatt1
   soilMoistBatt2 = soilbatt2
   soilMoistBatt3 = soilbatt3
   soilMoistBatt4 = soilbatt4
   soilMoistBatt5 = soilbatt5
   soilMoistBatt6 = soilbatt6
   soilMoistBatt7 = soilbatt7
   soilMoistBatt8 = soilbatt8

   soilTemp1 = tf_ch1
   soilTemp2 = tf_ch2
   soilTemp3 = tf_ch3
   soilTemp4 = tf_ch4
   soilTemp5 = tf_ch5
   soilTemp6 = tf_ch6
   soilTemp7 = tf_ch7
   soilTemp8 = tf_ch8
   soilTempBatt1 = tf_batt1
   soilTempBatt2 = tf_batt2
   soilTempBatt3 = tf_batt3
   soilTempBatt4 = tf_batt4
   soilTempBatt5 = tf_batt5
   soilTempBatt6 = tf_batt6
   soilTempBatt7 = tf_batt7
   soilTempBatt8 = tf_batt8

   leafWet1 = leafwetness_ch1
   leafWet2 = leafwetness_ch2
   leafWet3 = leafwetness_ch3
   leafWet4 = leafwetness_ch4
   leafWet5 = leafwetness_ch5
   leafWet6 = leafwetness_ch6
   leafWet7 = leafwetness_ch7
   leafWet8 = leafwetness_ch8
   leafWetBatt1 = leaf_batt1
   leafWetBatt2 = leaf_batt2
   leafWetBatt3 = leaf_batt3
   leafWetBatt4 = leaf_batt4
   leafWetBatt5 = leaf_batt5
   leafWetBatt6 = leaf_batt6
   leafWetBatt7 = leaf_batt7
   leafWetBatt8 = leaf_batt8
   leak_1 = leak_ch1
   leak_2 = leak_ch2
   leak_3 = leak_ch3
   leak_4 = leak_ch4
   leak_Batt1 = leakbatt1
   leak_Batt2 = leakbatt2
   leak_Batt3 = leakbatt3
   leak_Batt4 = leakbatt4
   lightning_distance = lightning
   lightning_disturber_count = lightning_time
   lightning_strike_count = lightning_num
   lightning_Batt = wh57batt

   maxdailygust = maxdailygust
   winddir_avg10m = winddir_avg10m
   windspdmph_avg10m = windspdmph_avg10m

   pm25_24h_co2 = pm25_24h_co2
   pm10_24h_co2 = pm10_24h_co2
   pm25_avg_24h_ch1 = pm25_avg_24h_ch1
   pm25_avg_24h_ch2 = pm25_avg_24h_ch2
   pm25_avg_24h_ch3 = pm25_avg_24h_ch3
   pm25_avg_24h_ch4 = pm25_avg_24h_ch4

   consBatteryVoltage = ws1900batt
        
   rainBatteryStatus = wh40batt
   hailBatteryStatus = wh90batt
   windBatteryStatus = wh80batt
   ws90_batt = wh90batt
   ws80_batt = wh80batt

   outTempBatteryStatus = wh65batt
   #  outTempBatteryStatus = wh26batt
   inTempBatteryStatus = wh25batt

   rainrate = rainratein
   totalRain = rain_total
   eventRain = rainevent
   hourRain = hourlyrainin
   dayRain = dailyrainin
   weekRain = weeklyrainin
   monthRain = monthlyrainin
   yearRain = rainyear

   rain_piezo = rain_piezo
   rrain_piezo = rrain_piezo
   erain_piezo = erain_piezo
   hrain_piezo = hrain_piezo
   drain_piezo = drain_piezo
   wrain_piezo = wrain_piezo
   mrain_piezo = mrain_piezo
   yrain_piezo = yrain_piezo

   ws90cap_volt = ws90cap_volt
   ws90_ver = ws90_ver

   runtime = runtime
   ws_interval = interval

   model = model
   stationtype = stationtype

   gain0 = gain0
   gain1 = gain1
   gain2 = gain2
   gain3 = gain3
   gain4 = gain4
   gain5 = gain5
   gain6 = gain6
   gain7 = gain7
   gain8 = gain8
   gain9 = gain9

##############################################################################
[StdReport]
    [[Defaults]]
        [[[Units]]]

            [[[[Labels]]]]
                centibar = %
##############################################################################
[DataBindings]
    
    [[wx_binding]]
        # The database must match one of the sections in [Databases].
        # This is likely to be the only option you would want to change.
        database = archive_sqlite
        #database = archive_mysql
        # The name of the table within the database
        table_name = archive
        # The manager handles aggregation of data for historical summaries
        manager = weewx.manager.DaySummaryManager
        # The schema defines the structure of the database.
        # It is *only* used when the database is created.
        schema = schemas.wview_extended.schema
        schema_new = schemas.wview_ecowitt.schema

##############################################################################
[Databases]
    
    # A SQLite database is simply a single file
    [[archive_sqlite]]
        database_name = weewx.sdb
        database_name_new = weewx_ecowitt.sdb
        database_type = SQLite

##############################################################################
[StdWXCalculate]
    #  [[WXXTypes]]
    #    [[[windDir]]]
    #       force_null = True
    #    [[[maxSolarRad]]]
    #      algorithm = rs
    #      atc = 0.8
    #      nfac = 2
    #    [[[ET]]]
    #      wind_height = 2.0
    #      et_period = 3600
    #    [[[heatindex]]]
    #      algorithm = new
    #  [[PressureCooker]]
    #    max_delta_12h = 1800
    #    [[[altimeter]]]
    #      algorithm = aaASOS    # Case-sensitive!
    #  [[RainRater]]
    #    rain_period = 900
    #    retain_period = 930
    #  [[Delta]]
    #    [[[rain]]]
    #      input = totalRain

      [[WXXTypes]]
        [[[maxSolarRad]]]
          algorithm = rs	    # default
          atc = 0.9		    # default 0.8 - atmospheric transmission coefficient [0.7-0.91]

##############################################################################
[StdArchive]

    record_generation_new = hardware

##############################################################################
[StdCalibrate]
    
    [[Corrections]]
        # For each type, an arbitrary calibration expression can be given.
        # It should be in the units defined in the StdConvert section.
        # Example:
        foo = foo + 0.2
        luminosity = radiation * 126.7

        0rxCheckPercent = wh24_sig * 25 if wh24_sig is not None else None
        1rxCheckPercent = wh25_sig * 25 if wh25_sig is not None else None
        rxCheckPercent = wh65_sig * 25 if wh65_sig is not None else None
        2rxCheckPercent = wh68_sig * 25 if wh68_sig is not None else None
        3rxCheckPercent = ws80_sig * 25 if ws80_sig is not None else None
        4rxCheckPercent = ws90_sig * 25 if ws90_sig is not None else None

        hail = rain_piezo if rain_piezo is not None else None
        hailRate = rrain_piezo if rrain_piezo is not None else None
        hailBatteryStatus = ws90cap_volt if ws90cap_volt is not None else None

##############################################################################
[RadiationDays]
    sunshine_log = 0
    sunshine_coeff = 0.95
    sunshine_min = 18
    sunshine_loop = 1
    rainDur_loop = 0
    hailDur_loop = 0
    sunshine_log = 0
    rainDur_log = 0
    hailDur_log = 0
##############################################################################
# Options for extension 'Interceptor'
[Accumulator]

   [[model]]
        accumulator = firstlast
        extractor = last
   [[stationtype]]
        accumulator = firstlast
        extractor = last

    [[gain0]]
        extractor = last
    [[gain1]]
        extractor = last
    [[gain2]]
        extractor = last
    [[gain3]]
        extractor = last
    [[gain4]]
        extractor = last
    [[gain5]]
        extractor = last

    [[lightning_distance]]
        extractor = last
    [[lightning_strike_count]]
        extractor = sum
    [[lightning_last_det_time]]
        extractor = last
    [[lightningcount]]
        extractor = last

    [[daymaxwind]]
        extractor = last
    [[windspdmph_avg10m]]
        extractor = last
    [[winddir_avg10m]]
        extractor = last

    [[rainRate]]
        extractor = max
    [[stormRain]]
        extractor = last
    [[hourRain]]
        extractor = last
    [[dayRain]]
        extractor = last
    [[weekRain]]
        extractor = last
    [[monthRain]]
        extractor = last
    [[yearRain]]
        extractor = last
    [[totalRain]]
        extractor = last

    [[rrain_piezo]]
        extractor = max
    [[erain_piezo]]
        extractor = last
    [[hrain_piezo]]
        extractor = last
    [[drain_piezo]]
        extractor = last
    [[wrain_piezo]]
        extractor = last
    [[mrain_piezo]]
        extractor = last
    [[yrain_piezo]]
        extractor = last

    [[p_rainrate]]
        extractor = max
    [[p_eventrain]]
        extractor = last
    [[p_hourrain]]
        extractor = last
    [[p_dayrain]]
        extractor = last
    [[p_weekrain]]
        extractor = last
    [[p_monthrain]]
        extractor = last
    [[p_yearrain]]
        extractor = last

    [[dayHail]]
        extractor = last
    [[hail]]
        extractor = sum

    [[pm2_51_24hav]]
        extractor = last
    [[pm2_52_24hav]]
        extractor = last
    [[pm2_53_24hav]]
        extractor = last
    [[pm2_54_24hav]]
        extractor = last
    [[24havpm255]]
        extractor = last

    [[pm2_51_24h_avg]]
        extractor = last
    [[pm2_52_24h_avg]]
        extractor = last
    [[pm2_53_24h_avg]]
        extractor = last
    [[pm2_54_24h_avg]]
        extractor = last
    [[pm2_55_24h_avg]]
        extractor = last
    [[pm10_24h_avg]]
        extractor = last
    [[co2_24h_avg]]
        extractor = last

    [[wh25_batt]]
        extractor = last
    [[wh26_batt]]
        extractor = last
    [[wh31_ch1_batt]]
        extractor = last
    [[wh31_ch2_batt]]
        extractor = last
    [[wh31_ch3_batt]]
        extractor = last
    [[wh31_ch4_batt]]
        extractor = last
    [[wh31_ch5_batt]]
        extractor = last
    [[wh31_ch6_batt]]
        extractor = last
    [[wh31_ch7_batt]]
        extractor = last
    [[wh31_ch8_batt]]
        extractor = last
    [[wn35_ch1_batt]]
        extractor = last
    [[wn35_ch2_batt]]
        extractor = last
    [[wn35_ch3_batt]]
        extractor = last
    [[wn35_ch4_batt]]
        extractor = last
    [[wn35_ch5_batt]]
        extractor = last
    [[wn35_ch6_batt]]
        extractor = last
    [[wn35_ch7_batt]]
        extractor = last
    [[wn35_ch8_batt]]
        extractor = last
    [[wh40_batt]]
        extractor = last
    [[wh41_ch1_batt]]
        extractor = last
    [[wh41_ch2_batt]]
        extractor = last
    [[wh41_ch3_batt]]
        extractor = last
    [[wh41_ch4_batt]]
        extractor = last
    [[wh45_batt]]
        extractor = last
    [[wh51_ch1_batt]]
        extractor = last
    [[wh51_ch2_batt]]
        extractor = last
    [[wh51_ch3_batt]]
        extractor = last
    [[wh51_ch4_batt]]
        extractor = last
    [[wh51_ch5_batt]]
        extractor = last
    [[wh51_ch6_batt]]
        extractor = last
    [[wh51_ch7_batt]]
        extractor = last
    [[wh51_ch8_batt]]
        extractor = last
    [[wh51_ch9_batt]]
        extractor = last
    [[wh51_ch10_batt]]
        extractor = last
    [[wh51_ch11_batt]]
        extractor = last
    [[wh51_ch12_batt]]
        extractor = last
    [[wh51_ch13_batt]]
        extractor = last
    [[wh51_ch14_batt]]
        extractor = last
    [[wh51_ch15_batt]]
        extractor = last
    [[wh51_ch16_batt]]
        extractor = last
    [[wh55_ch1_batt]]
        extractor = last
    [[wh55_ch2_batt]]
        extractor = last
    [[wh55_ch3_batt]]
        extractor = last
    [[wh55_ch4_batt]]
        extractor = last
    [[wh57_batt]]
        extractor = last
    [[wh65_batt]]
        extractor = last
    [[wh68_batt]]
        extractor = last
    [[ws80_batt]]
        extractor = last
    [[ws90_batt]]
        extractor = last
    [[ws90cap_volt]]
        extractor = last
    [[ws1900batt]]
        extractor = last


    [[wh25_sig]]
        extractor = last
    [[wh26_sig]]
        extractor = last
    [[wh31_ch1_sig]]
        extractor = last
    [[wh31_ch2_sig]]
        extractor = last
    [[wh31_ch3_sig]]
        extractor = last
    [[wh31_ch4_sig]]
        extractor = last
    [[wh31_ch5_sig]]
        extractor = last
    [[wh31_ch6_sig]]
        extractor = last
    [[wh31_ch7_sig]]
        extractor = last
    [[wh31_ch8_sig]]
        extractor = last
    [[wn34_ch1_sig]]
        extractor = last
    [[wn34_ch2_sig]]
        extractor = last
    [[wn34_ch3_sig]]
        extractor = last
    [[wn34_ch4_sig]]
        extractor = last
    [[wn34_ch5_sig]]
        extractor = last
    [[wn34_ch6_sig]]
        extractor = last
    [[wn34_ch7_sig]]
        extractor = last
    [[wn34_ch8_sig]]
        extractor = last
    [[wn35_ch1_sig]]
        extractor = last
    [[wn35_ch2_sig]]
        extractor = last
    [[wn35_ch3_sig]]
        extractor = last
    [[wn35_ch4_sig]]
        extractor = last
    [[wn35_ch5_sig]]
        extractor = last
    [[wn35_ch6_sig]]
        extractor = last
    [[wn35_ch7_sig]]
        extractor = last
    [[wn35_ch8_sig]]
        extractor = last
    [[wh40_sig]]
        extractor = last
    [[wh41_ch1_sig]]
        extractor = last
    [[wh41_ch2_sig]]
        extractor = last
    [[wh41_ch3_sig]]
        extractor = last
    [[wh41_ch4_sig]]
        extractor = last
    [[wh45_sig]]
        extractor = last
    [[wh51_ch1_sig]]
        extractor = last
    [[wh51_ch2_sig]]
        extractor = last
    [[wh51_ch3_sig]]
        extractor = last
    [[wh51_ch4_sig]]
        extractor = last
    [[wh51_ch5_sig]]
        extractor = last
    [[wh51_ch6_sig]]
        extractor = last
    [[wh51_ch7_sig]]
        extractor = last
    [[wh51_ch8_sig]]
        extractor = last
    [[wh51_ch9_sig]]
        extractor = last
    [[wh51_ch10_sig]]
        extractor = last
    [[wh51_ch11_sig]]
        extractor = last
    [[wh51_ch12_sig]]
        extractor = last
    [[wh51_ch13_sig]]
        extractor = last
    [[wh51_ch14_sig]]
        extractor = last
    [[wh51_ch15_sig]]
        extractor = last
    [[wh51_ch16_sig]]
        extractor = last
    [[wh55_ch1_sig]]
        extractor = last
    [[wh55_ch2_sig]]
        extractor = last
    [[wh55_ch3_sig]]
        extractor = last
    [[wh55_ch4_sig]]
        extractor = last
    [[wh57_sig]]
        extractor = last
    [[wh65_sig]]
        extractor = last
    [[wh68_sig]]
        extractor = last
    [[ws80_sig]]
        extractor = last
    [[ws90_sig]]
        extractor = last

    # End GW1000 and Interceptor driver extractors
##############################################################################
"""

# construct our config dict
interceptor_dict = configobj.ConfigObj(StringIO(interceptor_config))


def loader():
    return InterceptorInstaller()

class InterceptorInstaller(ExtensionInstaller):
    def __init__(self):
        if StrictVersion(weewx.__version__) < StrictVersion(REQUIRED_VERSION):
            msg = "%s requires WeeWX %s or greater, found %s" % (''.join(('Interceptor driver ', Interceptor_VERSION)),
                                                                 REQUIRED_VERSION,
                                                                 weewx.__version__)
            raise weewx.UnsupportedFeature(msg)

        super(InterceptorInstaller, self).__init__(
            version=Interceptor_VERSION,
            name='interceptor',
            description='Capture weather data from HTTP requests (Ecowitt_client)',
            author="Matthew Wall - Werner Krenn",
            author_email="mwall@users.sourceforge.net",
            files=[
                ('bin/user', [
                    'bin/user/interceptor.py',
                    'bin/user/extensions.py',
                    'bin/user/historygenerator.py',
                    'bin/user/historygenerator4.py',
                    'bin/user/sunevents.py',
                    'bin/user/jsonengine.py',
                    'bin/user/largeimagegenerator.py',
                    'bin/user/sunrainduration.py',
                ]),
                ('bin/schemas', [
                    'bin/schemas/wview_ecowitt.py',
                ]),
                ('skins/nws', [
                    'skins/Seasons/index.html.tmpl',
                    'skins/Seasons/telemetry.html.tmpl',
                    'skins/Seasons/skin.conf',
                    'skins/Seasons/seasons.css',
                    'skins/Seasons/seasons.js',
                    'skins/Seasons/current.inc',
                    'skins/Seasons/hilo.inc',
                    'skins/Seasons/sensors.inc',
                    'skins/Seasons/about.inc',
                    'skins/Seasons/titlebar.inc',
                    'skins/Seasons/statistics.inc',
                    'skins/Seasons/Batt0.png',
                    'skins/Seasons/Batt1.png',
                    'skins/Seasons/Batt2.png',
                    'skins/Seasons/Batt3.png',
                    'skins/Seasons/Batt4.png',
                    'skins/Seasons/Batt5.png',
                    'skins/Seasons/Batt6.png',
                    'skins/Seasons/Batt6x.png',
                    'skins/Seasons/lang/de.conf',
                ]),
            ],
            config=interceptor_dict
        )
