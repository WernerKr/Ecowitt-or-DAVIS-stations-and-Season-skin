# installer for the weewx-interceptor driver
# Copyright 2016 Matthew Wall, all rights reserved
# Distributed under the terms of the GNU Public License (GPLv3)
# Modified for Ecowitt stations (only ecowitt-client) , Werner Krenn, 2021

import sys
import weewx

from weecfg.extension import ExtensionInstaller

def loader():
    return InterceptorInstaller()

class InterceptorInstaller(ExtensionInstaller):
    def __init__(self):
        super(InterceptorInstaller, self).__init__(
            version="0.54",
            name='interceptor',
            description='Capture weather data from HTTP requests',
            author="Matthew Wall",
            author_email="mwall@users.sourceforge.net",
            config = {
                'Station': {
                    'station_type': 'Interceptor'
                },

                'Interceptor': {
                    'driver': 'user.interceptor',
                    'device_type': 'ecowitt-client',
                    'port': '8080',
                    'iface': 'eth0',
                    '#iface': 'wlan0',
                    'sensor_map_extensions': {
                        'co2' : 'co2',
                        'co2_Temp' : 'tf_co2',
                        'co2_Hum' : 'humi_co2',
                        'co2_Batt' : 'co2_batt',
                        'pm10_0' : 'pm10_co2',
                        'pm2_5' : 'pm25_co2',
                        'pm25_1' : 'pm25_ch1',
                        'pm25_2' : 'pm25_ch2',
                        'pm25_3' : 'pm25_ch3',
                        'pm25_4' : 'pm25_ch4',
                        'pm25_Batt1' : 'pm25batt1',
                        'pm25_Batt2' : 'pm25batt2',
                        'pm25_Batt3' : 'pm25batt3',
                        'pm25_Batt4' : 'pm25batt4',
                        'batteryStatus1' : 'battery_1',
                        'batteryStatus2' : 'battery_2',
                        'batteryStatus3' : 'battery_3',
                        'batteryStatus4' : 'battery_4',
                        'batteryStatus5' : 'battery_5',
                        'batteryStatus6' : 'battery_6',
                        'batteryStatus7' : 'battery_7',
                        'batteryStatus8' : 'battery_8',

                        'soilMoist5' : 'soil_moisture_5',
                        'soilMoist6' : 'soil_moisture_6',
                        'soilMoist7' : 'soil_moisture_7',
                        'soilMoist8' : 'soil_moisture_8',
                        'soilMoistBatt1' : 'soilbatt1',
                        'soilMoistBatt2' : 'soilbatt2',
                        'soilMoistBatt3' : 'soilbatt3',
                        'soilMoistBatt4' : 'soilbatt4',
                        'soilMoistBatt5' : 'soilbatt5',
                        'soilMoistBatt6' : 'soilbatt6',
                        'soilMoistBatt7' : 'soilbatt7',
                        'soilMoistBatt8' : 'soilbatt8',

                        'soilTemp1' : 'tf_ch1',
                        'soilTemp2' : 'tf_ch2',
                        'soilTemp3' : 'tf_ch3',
                        'soilTemp4' : 'tf_ch4',
                        'soilTemp5' : 'tf_ch5',
                        'soilTemp6' : 'tf_ch6',
                        'soilTemp7' : 'tf_ch7',
                        'soilTemp8' : 'tf_ch8',
                        'soilTempBatt1' : 'tf_batt1',
                        'soilTempBatt2' : 'tf_batt2',
                        'soilTempBatt3' : 'tf_batt3',
                        'soilTempBatt4' : 'tf_batt4',
                        'soilTempBatt5' : 'tf_batt5',
                        'soilTempBatt6' : 'tf_batt6',
                        'soilTempBatt7' : 'tf_batt7',
                        'soilTempBatt8' : 'tf_batt8',

                        'leafWet1' : 'leafwetness_ch1',
                        'leafWet2' : 'leafwetness_ch2',
                        'leafWet3' : 'leafwetness_ch3',
                        'leafWet4' : 'leafwetness_ch4',
                        'leafWet5' : 'leafwetness_ch5',
                        'leafWet6' : 'leafwetness_ch6',
                        'leafWet7' : 'leafwetness_ch7',
                        'leafWet8' : 'leafwetness_ch8',
                        'leafWetBatt1' : 'leaf_batt1',
                        'leafWetBatt2' : 'leaf_batt2',
                        'leafWetBatt3' : 'leaf_batt3',
                        'leafWetBatt4' : 'leaf_batt4',
                        'leafWetBatt5' : 'leaf_batt5',
                        'leafWetBatt6' : 'leaf_batt6',
                        'leafWetBatt7' : 'leaf_batt7',
                        'leafWetBatt8' : 'leaf_batt8',
                        'leak_1' : 'leak_ch1',
                        'leak_2' : 'leak_ch2',
                        'leak_3' : 'leak_ch3',
                        'leak_4' : 'leak_ch4',
                        'leak_Batt1' : 'leakbatt1',
                        'leak_Batt2' : 'leakbatt2',
                        'leak_Batt3' : 'leakbatt3',
                        'leak_Batt4' : 'leakbatt4',
                        'lightning_distance' : 'lightning',
                        'lightning_disturber_count' : 'lightning_time',
                        'lightning_strike_count' : 'lightning_num',
                        'lightning_Batt' : 'wh57batt',

                        'rainBatteryStatus' : 'wh40batt',
                        'windBatteryStatus' : 'wh80batt',
                        'outTempBatteryStatus' : 'wh65batt',
                        'xoutTempBatteryStatus' : 'wh26batt',
                        'inTempBatteryStatus' : 'wh25batt',

                        'maxdailygust' : 'maxdailygust',
                        'winddir_avg10m' : 'winddir_avg10m',
                        'windspdmph_avg10m' : 'windspdmph_avg10m',

                        'rainrate' : 'rainratein',
                        'totalRain' : 'rain_total',
                        'eventRain' : 'rainevent',
                        'hourRain' : 'hourlyrainin',
                        'dayRain' : 'dailyrainin',
                        'weekRain' : 'weeklyrainin',
                        'monthRain' : 'monthlyrainin',
                        'yearRain' : 'rainyear',

                        'co2_24h' : 'co2_24h',
                        'pm25_24h_co2' : 'pm25_24h_co2',
                        'pm10_24h_co2' : 'pm10_24h_co2',
                        'pm25_avg_24h_ch1' : 'pm25_avg_24h_ch1',
                        'pm25_avg_24h_ch2' : 'pm25_avg_24h_ch2',
                        'pm25_avg_24h_ch3' : 'pm25_avg_24h_ch3',
                        'pm25_avg_24h_ch4' : 'pm25_avg_24h_ch4',
                    }, 
                },
                'DataBindings': {
                    'wx_binding': {
                        'database': 'archive_sqlite',
                        'table_name': 'archive',
                        'manager': 'weewx.manager.DaySummaryManager',
                        'schema': 'schemas.wview_ecowitt.schema',
                        '#schema': 'schemas.wview_ecowitt.schema',
                    }
                },
                'Databases': {
                    'archive_sqlite': {
                        'database_type': 'SQLite',
                        'database_name': 'weewx_ecowitt.sdb',
                        '#database_name': 'weewx_ecowitt.sdb',
                    }
                },
                'RadiationDays': {
                        'sunshine_log': '0',
                        'sunshine_coeff': '0.8',
                        'sunshine_min': '18'
                },
                'StdCalibrate': {
                    'Corrections': {
                        'luminosity': 'radiation * 126.7',
                        'rxCheckPercent': 'ws80_sig * 25 if ws80_sig is not None else None',
                        '#rxCheckPercent': 'ws65_sig * 25 if ws65_sig is not None else None',
                    }
                 },

                'Accumulator': {
                    'daymaxwind': {
                        'extractor': 'last'},
                    'windspdmph_avg10m': {
                        'extractor': 'last'},
                    'winddir_avg10m': {
                        'extractor': 'last'},
                    'lightning_distance': {
                        'extractor': 'last'},
                    'lightning_strike_count': {
                        'extractor': 'last'},
                    'lightning_last_det_time': {
                        'extractor': 'last'},
                    'lightningcount': {
                        'extractor': 'last'},
                },
            },
            files=[
                ('bin/user', [
                    'bin/user/interceptor.py',
                    'bin/user/extensions.py',
                    'bin/user/sunduration.py',
                ]),
                ('bin/schemas', [
                    'bin/schemas/wview_ecowitt.py',
                ]),
                ('skins/nws', [
                    'skins/Seasons/index.html.tmpl',
                    'skins/Seasons/skin.conf',
                    'skins/Seasons/seasons.css',
                    'skins/Seasons/telemetry.html.tmpl',
                    'skins/Seasons/celestial.html.tmpl',
                    'skins/Seasons/statistics.html.tmpl',
                    'skins/Seasons/tabular.html.tmpl',
                    'skins/Seasons/about.inc',
                    'skins/Seasons/current.inc',
                    'skins/Seasons/hilo.inc',
                    'skins/Seasons/sensors.inc',
                    'skins/Seasons/statistics.inc',
                ]),
            ]
        )
