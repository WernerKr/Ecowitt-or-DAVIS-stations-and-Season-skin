"""
This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later
version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE.  See the GNU General Public License for more details.

                        Installer for Ecowitt GW1000 Driver

Version: 0.5.0.3kw                                        Date: May 2023
"""

# python imports
import configobj
from distutils.version import StrictVersion
from setup import ExtensionInstaller

# import StringIO, use six.moves due to python2/python3 differences
from six.moves import StringIO

# WeeWX imports
import weewx


REQUIRED_VERSION = "3.7.0"
GW1000_VERSION = "0.5.0.3kw"
# define our config as a multiline string so we can preserve comments
gw1000_config = """
[Station]
    station_type = GW1000
    station_type_new = GW1000

[GW1000]
  # This section is for the GW1000 API driver.

  # How often to poll the GW1000 API, default is every 20 seconds:
  poll_interval = 20

  # The driver to use:
  driver = user.gw1000
  
  #ip_address = 192.168.0.100	# GW1100A
  port = 45000

  #wh32 = True
  #ignore_legacy_wh40_battery = True
  #show_all_batt = False
  #log_unknown_fields = True
  #debug_rain = False
  #debug_wind = False
  #debug_loop = False
  #debug_sensors = False
  
  [[field_map_extensions]]
   batteryStatus1 = wh31_ch1_batt
   batteryStatus2 = wh31_ch2_batt
   batteryStatus3 = wh31_ch3_batt
   batteryStatus4 = wh31_ch4_batt
   batteryStatus5 = wh31_ch5_batt
   batteryStatus6 = wh31_ch6_batt
   batteryStatus7 = wh31_ch7_batt
   batteryStatus8 = wh31_ch8_batt
        
   lightning_distance = lightningdist
   lightning_disturber_count = lightningdettime
   lightning_Batt = wh57_batt
        
   co2_Temp = temp17
   co2_Hum = humid17
   pm10_0 = pm10
   pm2_5 = pm255
   co2_Batt = wh45_batt
        
   pm25_1 = pm251
   pm25_2 = pm252
   pm25_3 = pm253
   pm25_4 = pm254
   pm25_Batt1 = wh41_ch1_batt
   pm25_Batt2 = wh41_ch2_batt
   pm25_Batt3 = wh41_ch3_batt
   pm25_Batt4 = wh41_ch4_batt
        
   soilTemp1 = temp9
   soilTemp2 = temp10
   soilTemp3 = temp11
   soilTemp4 = temp12
   soilTemp5 = temp13
   soilTemp6 = temp14
   soilTemp7 = temp15
   soilTemp8 = temp16
   soilTempBatt1 = wn34_ch1_batt
   soilTempBatt2 = wn34_ch2_batt
   soilTempBatt3 = wn34_ch3_batt
   soilTempBatt4 = wn34_ch4_batt
   soilTempBatt5 = wn34_ch5_batt
   soilTempBatt6 = wn34_ch6_batt
   soilTempBatt7 = wn34_ch7_batt
   soilTempBatt8 = wn34_ch8_batt
        
   soilMoistBatt1 = wh51_ch1_batt
   soilMoistBatt2 = wh51_ch2_batt
   soilMoistBatt3 = wh51_ch3_batt
   soilMoistBatt4 = wh51_ch4_batt
   soilMoistBatt5 = wh51_ch5_batt
   soilMoistBatt6 = wh51_ch6_batt
   soilMoistBatt7 = wh51_ch7_batt
   soilMoistBatt8 = wh51_ch8_batt
        
   leak_1 = leak1
   leak_2 = leak2
   leak_3 = leak3
   leak_4 = leak4
        
   leak_Batt1 = wh55_ch1_batt
   leak_Batt2 = wh55_ch2_batt
   leak_Batt3 = wh55_ch3_batt
   leak_Batt4 = wh55_ch4_batt
        
   leafWetBatt1 = wn35_ch1_batt
   leafWetBatt2 = wn35_ch2_batt
   leafWetBatt3 = wn35_ch3_batt
   leafWetBatt4 = wn35_ch4_batt
   leafWetBatt5 = wn35_ch5_batt
   leafWetBatt6 = wn35_ch6_batt
   leafWetBatt7 = wn35_ch7_batt
   leafWetBatt8 = wn35_ch8_batt
        
   rainBatteryStatus = wh40_batt
   windBatteryStatus = ws80_batt
   hailBatteryStatus = ws90_batt
   #ws80_batt = ws80_batt
   #ws90_batt = ws90_batt

   outTempBatteryStatus = wh24_batt
   #  outTempBatteryStatus = wh26_batt
   #  outTempBatteryStatus = wh65_batt
   #  outTempBatteryStatus = wh68_batt
   inTempBatteryStatus = wh25_batt
        
   consBatteryVoltage = ws1900batt
        
   maxdailygust = daymaxwind
   pm25_24h_co2 = pm255_24h_avg
   pm10_24h_co2 = pm10_24h_avg
   pm25_avg_24h_ch1 = pm251_24h_avg
   pm25_avg_24h_ch2 = pm252_24h_avg
   pm25_avg_24h_ch3 = pm253_24h_avg
   pm25_avg_24h_ch4 = pm254_24h_avg
   
   lightningcount = lightningcount
   
   co2_24h = co2_24h_avg
   barometer = relbarometer
   
   rainrate = rainrate
   totalRain = raintotal
   eventRain = rainevent
   hourRain = t_rainhour
   dayRain = t_rainday
   weekRain = t_rainweek
   monthRain = t_rainmonth
   yearRain = t_rainyear

   rain_piezo = p_rain 
   erain_piezo = p_rainevent
   rrain_piezo = p_rainrate
   hrain_piezo = p_hourrain
   drain_piezo = p_rainday
   wrain_piezo = p_rainweek
   mrain_piezo = p_rainmonth
   yrain_piezo = p_rainyear

   hail = p_rain
   hailRate = p_rainrate

   wh24_sig = wh24_sig
   wh25_sig = wh25_sig
   wh31_ch1_sig = wh31_ch1_sig
   ws80_sig = ws80_sig
   ws90_sig = ws90_sig
   wh40_sig = wh40_sig
   wh45_sig = wh45_sig
   wh57_sig = wh57_sig
   wh51_ch1_sig = wh51_ch1_sig
   wn35_ch1_sig = wn35_ch1_sig
   wn34_ch1_sig = wn34_ch1_sig

   rain_source = rain_source
   rain_day_reset = rain_day_reset
   rain_week_reset = rain_week_reset
   rain_annual_reset = rain_annual_reset
   raingain = raingain
   gain0 = gain0
   gain1 = gain1
   gain2 = gain2
   gain3 = gain3
   gain4 = gain4
   gain5 = gain5
   gain6 = gain6
   gain7 = gain7
   gain8 = gain8
   gain9 = gain9

##############################################################################
[StdReport]
    [[Defaults]]
        [[[Units]]]

            [[[[Labels]]]]
                centibar = %
##############################################################################
[DataBindings]
    
    [[wx_binding]]
        # The database must match one of the sections in [Databases].
        # This is likely to be the only option you would want to change.
        database = archive_sqlite
        #database = archive_mysql
        # The name of the table within the database
        table_name = archive
        # The manager handles aggregation of data for historical summaries
        manager = weewx.manager.DaySummaryManager
        # The schema defines the structure of the database.
        # It is *only* used when the database is created.
        schema = schemas.wview_extended.schema
        schema_new = schemas.wview_ecowitt.schema
##############################################################################
[Databases]
    
    # A SQLite database is simply a single file
    [[archive_sqlite]]
        database_name = weewx.sdb
        database_name_new = weewx_ecowitt.sdb
        database_type = SQLite
##############################################################################
[StdArchive]

    record_generation = software
    record_generation_new = software

[StdCalibrate]
    
    [[Corrections]]
        # For each type, an arbitrary calibration expression can be given.
        # It should be in the units defined in the StdConvert section.
        # Example:
        foo = foo + 0.2
        radiation = luminosity / 126.7 if luminosity is not None else None
        #luminosity = radiation * 126.7

        hail = p_rain if p_rain is not None else None
        hailRate = p_rainrate if p_rainrate is not None else None

        0rxCheckPercent = wh24_sig * 25 if wh24_sig is not None else None
        1rxCheckPercent = wh25_sig * 25 if wh25_sig is not None else None
        rxCheckPercent = wh65_sig * 25 if wh65_sig is not None else None
        2rxCheckPercent = wh68_sig * 25 if wh68_sig is not None else None
        3rxCheckPercent = ws80_sig * 25 if ws80_sig is not None else None
        4rxCheckPercent = ws90_sig * 25 if ws90_sig is not None else None

        1signal1 = wh24_sig * 25 if wh24_sig is not None else None
        2signal2 = wh31_ch1_sig * 25 if wh31_ch1_sig is not None else None
        3signal3 = wh34_ch1_sig * 25 if wh34_ch1_sig is not None else None
        4signal4 = wh40_sig * 25 if wh40_sig is not None else None
        5signal5 = wh45_sig * 25 if wh45_sig is not None else None
        6signal6 = wh57_sig * 25 if wh57_sig is not None else None
        7signal7 = wh51_ch1_sig * 25 if wh51_ch1_sig is not None else None
        8signal8 = wh35_ch1_sig * 25 if wh35_ch1_sig is not None else None

##############################################################################
[StdWXCalculate]

      [[WXXTypes]]
        [[[maxSolarRad]]]
          algorithm = rs	    # default
          atc = 0.9		    # default 0.8 - atmospheric transmission coefficient [0.7-0.91]
##############################################################################
[Engine]
    # The following section specifies which services should be run and in what order.
    [[Services]]
        data_services = ,
        data_services_new = user.gw1000.Gw1000Service
        process_services_new = weewx.engine.StdConvert, weewx.engine.StdCalibrate, weewx.engine.StdQC, weewx.wxservices.StdWXCalculate, user.sunrainduration.SunshineDuration
        xtype_services_new = weewx.wxxtypes.StdWXXTypes, weewx.wxxtypes.StdPressureCooker, weewx.wxxtypes.StdRainRater, weewx.wxxtypes.StdDelta, user.GTS.GTSService

##############################################################################
[RadiationDays]
    min_sunshine = 120
    sunshine_log = 0
    sunshine_coeff = 0.92
    sunshine_min = 18
    rainDur_log = 0
    hailDur_log = 0

##############################################################################
# Options for extension 'GW1000'
[Accumulator]
   [[model]]
        accumulator = firstlast
        extractor = last
   [[stationtype]]
        accumulator = firstlast
        extractor = last

    [[gain0]]
        extractor = last
    [[gain1]]
        extractor = last
    [[gain2]]
        extractor = last
    [[gain3]]
        extractor = last
    [[gain4]]
        extractor = last
    [[gain5]]
        extractor = last

    [[lightning_distance]]
        extractor = last
    [[lightning_strike_count]]
        extractor = sum
    [[lightning_last_det_time]]
        extractor = last
    [[lightningcount]]
        extractor = last

    [[daymaxwind]]
        extractor = last
    [[windspdmph_avg10m]]
        extractor = last
    [[winddir_avg10m]]
        extractor = last

    [[rainRate]]
        extractor = max
    [[stormRain]]
        extractor = last
    [[hourRain]]
        extractor = last
    [[dayRain]]
        extractor = last
    [[weekRain]]
        extractor = last
    [[monthRain]]
        extractor = last
    [[yearRain]]
        extractor = last
    [[totalRain]]
        extractor = last

    [[rrain_piezo]]
        extractor = max
    [[erain_piezo]]
        extractor = last
    [[hrain_piezo]]
        extractor = last
    [[drain_piezo]]
        extractor = last
    [[wrain_piezo]]
        extractor = last
    [[mrain_piezo]]
        extractor = last
    [[yrain_piezo]]
        extractor = last

    [[p_rainrate]]
        extractor = max
    [[p_eventrain]]
        extractor = last
    [[p_hourrain]]
        extractor = last
    [[p_dayrain]]
        extractor = last
    [[p_weekrain]]
        extractor = last
    [[p_monthrain]]
        extractor = last
    [[p_yearrain]]
        extractor = last

    [[dayHail]]
        extractor = last
    [[hail]]
        extractor = sum

    [[pm2_51_24hav]]
        extractor = last
    [[pm2_52_24hav]]
        extractor = last
    [[pm2_53_24hav]]
        extractor = last
    [[pm2_54_24hav]]
        extractor = last
    [[24havpm255]]
        extractor = last

    [[pm2_51_24h_avg]]
        extractor = last
    [[pm2_52_24h_avg]]
        extractor = last
    [[pm2_53_24h_avg]]
        extractor = last
    [[pm2_54_24h_avg]]
        extractor = last
    [[pm2_55_24h_avg]]
        extractor = last
    [[pm10_24h_avg]]
        extractor = last
    [[co2_24h_avg]]
        extractor = last

    [[wh25_batt]]
        extractor = last
    [[wh26_batt]]
        extractor = last
    [[wh31_ch1_batt]]
        extractor = last
    [[wh31_ch2_batt]]
        extractor = last
    [[wh31_ch3_batt]]
        extractor = last
    [[wh31_ch4_batt]]
        extractor = last
    [[wh31_ch5_batt]]
        extractor = last
    [[wh31_ch6_batt]]
        extractor = last
    [[wh31_ch7_batt]]
        extractor = last
    [[wh31_ch8_batt]]
        extractor = last
    [[wn35_ch1_batt]]
        extractor = last
    [[wn35_ch2_batt]]
        extractor = last
    [[wn35_ch3_batt]]
        extractor = last
    [[wn35_ch4_batt]]
        extractor = last
    [[wn35_ch5_batt]]
        extractor = last
    [[wn35_ch6_batt]]
        extractor = last
    [[wn35_ch7_batt]]
        extractor = last
    [[wn35_ch8_batt]]
        extractor = last
    [[wh40_batt]]
        extractor = last
    [[wh41_ch1_batt]]
        extractor = last
    [[wh41_ch2_batt]]
        extractor = last
    [[wh41_ch3_batt]]
        extractor = last
    [[wh41_ch4_batt]]
        extractor = last
    [[wh45_batt]]
        extractor = last
    [[wh51_ch1_batt]]
        extractor = last
    [[wh51_ch2_batt]]
        extractor = last
    [[wh51_ch3_batt]]
        extractor = last
    [[wh51_ch4_batt]]
        extractor = last
    [[wh51_ch5_batt]]
        extractor = last
    [[wh51_ch6_batt]]
        extractor = last
    [[wh51_ch7_batt]]
        extractor = last
    [[wh51_ch8_batt]]
        extractor = last
    [[wh51_ch9_batt]]
        extractor = last
    [[wh51_ch10_batt]]
        extractor = last
    [[wh51_ch11_batt]]
        extractor = last
    [[wh51_ch12_batt]]
        extractor = last
    [[wh51_ch13_batt]]
        extractor = last
    [[wh51_ch14_batt]]
        extractor = last
    [[wh51_ch15_batt]]
        extractor = last
    [[wh51_ch16_batt]]
        extractor = last
    [[wh55_ch1_batt]]
        extractor = last
    [[wh55_ch2_batt]]
        extractor = last
    [[wh55_ch3_batt]]
        extractor = last
    [[wh55_ch4_batt]]
        extractor = last
    [[wh57_batt]]
        extractor = last
    [[wh65_batt]]
        extractor = last
    [[wh68_batt]]
        extractor = last
    [[ws80_batt]]
        extractor = last
    [[ws90_batt]]
        extractor = last
    [[ws90cap_volt]]
        extractor = last
    [[ws1900batt]]
        extractor = last

    [[wh25_sig]]
        extractor = last
    [[wh26_sig]]
        extractor = last
    [[wh31_ch1_sig]]
        extractor = last
    [[wh31_ch2_sig]]
        extractor = last
    [[wh31_ch3_sig]]
        extractor = last
    [[wh31_ch4_sig]]
        extractor = last
    [[wh31_ch5_sig]]
        extractor = last
    [[wh31_ch6_sig]]
        extractor = last
    [[wh31_ch7_sig]]
        extractor = last
    [[wh31_ch8_sig]]
        extractor = last
    [[wn34_ch1_sig]]
        extractor = last
    [[wn34_ch2_sig]]
        extractor = last
    [[wn34_ch3_sig]]
        extractor = last
    [[wn34_ch4_sig]]
        extractor = last
    [[wn34_ch5_sig]]
        extractor = last
    [[wn34_ch6_sig]]
        extractor = last
    [[wn34_ch7_sig]]
        extractor = last
    [[wn34_ch8_sig]]
        extractor = last
    [[wn35_ch1_sig]]
        extractor = last
    [[wn35_ch2_sig]]
        extractor = last
    [[wn35_ch3_sig]]
        extractor = last
    [[wn35_ch4_sig]]
        extractor = last
    [[wn35_ch5_sig]]
        extractor = last
    [[wn35_ch6_sig]]
        extractor = last
    [[wn35_ch7_sig]]
        extractor = last
    [[wn35_ch8_sig]]
        extractor = last
    [[wh40_sig]]
        extractor = last
    [[wh41_ch1_sig]]
        extractor = last
    [[wh41_ch2_sig]]
        extractor = last
    [[wh41_ch3_sig]]
        extractor = last
    [[wh41_ch4_sig]]
        extractor = last
    [[wh45_sig]]
        extractor = last
    [[wh51_ch1_sig]]
        extractor = last
    [[wh51_ch2_sig]]
        extractor = last
    [[wh51_ch3_sig]]
        extractor = last
    [[wh51_ch4_sig]]
        extractor = last
    [[wh51_ch5_sig]]
        extractor = last
    [[wh51_ch6_sig]]
        extractor = last
    [[wh51_ch7_sig]]
        extractor = last
    [[wh51_ch8_sig]]
        extractor = last
    [[wh51_ch9_sig]]
        extractor = last
    [[wh51_ch10_sig]]
        extractor = last
    [[wh51_ch11_sig]]
        extractor = last
    [[wh51_ch12_sig]]
        extractor = last
    [[wh51_ch13_sig]]
        extractor = last
    [[wh51_ch14_sig]]
        extractor = last
    [[wh51_ch15_sig]]
        extractor = last
    [[wh51_ch16_sig]]
        extractor = last
    [[wh55_ch1_sig]]
        extractor = last
    [[wh55_ch2_sig]]
        extractor = last
    [[wh55_ch3_sig]]
        extractor = last
    [[wh55_ch4_sig]]
        extractor = last
    [[wh57_sig]]
        extractor = last
    [[wh65_sig]]
        extractor = last
    [[wh68_sig]]
        extractor = last
    [[ws80_sig]]
        extractor = last
    [[ws90_sig]]
        extractor = last

    # End GW1000 and Interceptor driver extractors
##############################################################################
"""

# construct our config dict
gw1000_dict = configobj.ConfigObj(StringIO(gw1000_config))


def loader():
    return Gw1000Installer()


class Gw1000Installer(ExtensionInstaller):
    def __init__(self):
        if StrictVersion(weewx.__version__) < StrictVersion(REQUIRED_VERSION):
            msg = "%s requires WeeWX %s or greater, found %s" % (''.join(('GW1000 driver ', GW1000_VERSION)),
                                                                 REQUIRED_VERSION,
                                                                 weewx.__version__)
            raise weewx.UnsupportedFeature(msg)
        super(Gw1000Installer, self).__init__(
            version=GW1000_VERSION,
            name='GW1000',
            description='WeeWX driver for Ecowitt gateways.',
            author="Gary Roderick - Werner Krenn",
            author_email="gjroderick<@>gmail.com",
#           files=[('bin/user', ['bin/user/gw1000.py'])],
            files=[
                ('bin/user', [
                    'bin/user/gw1000.py',
                    'bin/user/extensions.py',
                    'bin/user/historygenerator.py',
                    'bin/user/historygenerator4.py',
                    'bin/user/sunevents.py',
                    'bin/user/jsonengine.py',
                    'bin/user/largeimagegenerator.py',
                    'bin/user/sunrainduration.py',
                ]),
                ('bin/schemas', [
                    'bin/schemas/wview_ecowitt.py',
                ]),
                ('skins/nws', [
                    'skins/Seasons/index.html.tmpl',
                    'skins/Seasons/telemetry.html.tmpl',
                    'skins/Seasons/skin.conf',
                    'skins/Seasons/seasons.css',
                    'skins/Seasons/seasons.js',
                    'skins/Seasons/current.inc',
                    'skins/Seasons/hilo.inc',
                    'skins/Seasons/sensors.inc',
                    'skins/Seasons/about.inc',
                    'skins/Seasons/statistics.inc',
                    'skins/Seasons/Batt0.png',
                    'skins/Seasons/Batt1.png',
                    'skins/Seasons/Batt2.png',
                    'skins/Seasons/Batt3.png',
                    'skins/Seasons/Batt4.png',
                    'skins/Seasons/Batt5.png',
                    'skins/Seasons/Batt6.png',
                    'skins/Seasons/Batt6x.png',
                    'skins/Seasons/lang/de.conf',
                ]),
            ],
            config=gw1000_dict
         )


