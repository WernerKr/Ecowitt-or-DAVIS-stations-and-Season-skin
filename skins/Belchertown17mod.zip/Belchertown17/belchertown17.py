"""
Extension for the Belchertown skin.
This extension builds search list extensions as well
as a crude "cron" to download necessary files.

Pat O'Brien, August 19, 2018
"""

import calendar
import datetime
import json
import locale
import logging
import os
import time
from urllib.request import Request, urlopen
import urllib.error
from collections import OrderedDict
from math import asin, atan2, cos, degrees, pi, radians, sin, sqrt
from re import match

import configobj
import weeutil.weeutil
import weewx
import weewx.reportengine
import weewx.tags
import weewx.units
from weeutil.config import accumulateLeaves
from weeutil.weeutil import (
    TimeSpan,
    archiveDaySpan,
    archiveMonthSpan,
    archiveSpanSpan,
    archiveWeekSpan,
    archiveYearSpan,
    isStartOfDay,
    startOfDay,
    to_bool,
    to_float,
    to_int,
)
from weewx.cheetahgenerator import SearchList
from weewx.tags import TimespanBinder

if weewx.__version__ < "5":
    raise weewx.UnsupportedFeature(
        f"WeeWX 5 and newer is required, found {weewx.__version__}"
    )

log = logging.getLogger(__name__)

# Print version in syslog for easier troubleshooting
VERSION = "1.7kw_beta2-new-belchertown"
log.info(f"version {VERSION}")

# Default timeout for all HTTP requests (seconds)
DEFAULT_HTTP_TIMEOUT = 15

# HTTP Headers for different services
HTTP_HEADERS = {
    "PIRATE_WEATHER": {
        "User-Agent": "weewx-belchertown-new/pirateweather",
        "Connection": "keep-alive",
    },
    "AERIS_WEATHER": {
        "User-Agent": "weewx-belchertown-new/aerisweather",
        "Connection": "keep-alive",
    },
}


# Module-level helper functions for HTTP and JSON processing


def _http_get_json(url, timeout=DEFAULT_HTTP_TIMEOUT):
    """Fetch JSON data from the Pirate Weather API."""
    req = Request(url, headers=HTTP_HEADERS["PIRATE_WEATHER"])
    with urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def _extract_fields(source, fields):
    """Extract specified fields from a source dictionary."""
    return {field: source.get(field) for field in fields}


def _pw_transform_to_belch(pw):
    """Map Dark Sky-style JSON from Pirate Weather to the compact structure
    this skin uses: current, hourly[], daily[], alerts[].
    """
    CURRENT_FIELDS = [
        "summary", "icon", "temperature", "apparentTemperature", "windSpeed",
        "windGust", "windBearing", "humidity", "pressure", "visibility",
        "dewPoint", "precipIntensity", "precipProbability", "cloudCover",
        "uvIndex", "time"
    ]
    HOURLY_FIELDS = [
        "time", "summary", "icon", "temperature", "apparentTemperature",
        "windSpeed", "windGust", "windBearing", "precipIntensity",
        "precipProbability", "cloudCover", "uvIndex"
    ]
    DAILY_FIELDS = [
        "time", "summary", "icon", "temperatureHigh", "temperatureLow",
        "windSpeed", "windGust", "windBearing", "precipIntensity",
        "precipProbability", "cloudCover", "uvIndex"
    ]
    ALERT_FIELDS = ["title", "expires", "description", "severity", "uri"]

    current_data = pw.get("currently") or {}
    hourly_list = (pw.get("hourly") or {}).get("data", [])
    daily_list = (pw.get("daily") or {}).get("data", [])
    alerts_list = pw.get("alerts") or []

    return {
        "current": _extract_fields(current_data, CURRENT_FIELDS),
        "hourly": [_extract_fields(h, HOURLY_FIELDS) for h in hourly_list],
        "daily": [_extract_fields(d, DAILY_FIELDS) for d in daily_list],
        "alerts": [_extract_fields(a, ALERT_FIELDS) for a in alerts_list],
        "provider": "pirateweather",
        "generated_at": int(time.time()),
    }


def _parse_aeris_json(obj):
    """Robustly parse JSON whether it's str or bytes."""
    try:
        return json.loads(obj)
    except (ValueError, TypeError):
        pass
    
    try:
        if isinstance(obj, (bytes, bytearray)):
            return json.loads(obj.decode("utf-8"))
        return json.loads(obj.decode("utf-8", "replace"))
    except Exception as e:
        log.error(f"Error parsing forecast JSON: {e}")
        return {}


class getData(SearchList):
    """Collect all custom data and calculations, then return search list extension."""

    def __init__(self, generator):
        SearchList.__init__(self, generator)

    def get_gps_distance(self, pointA, pointB, distance_unit):
        """
        https://www.geeksforgeeks.org/program-distance-two-points-earth/ and
        https://stackoverflow.com/a/43960736 The math module contains a
        function named radians which converts from degrees to radians.
        """

        if not isinstance(pointA, tuple) or not isinstance(pointB, tuple):
            raise TypeError("Only tuples are supported as arguments")

        lat1r = radians(pointA[0])
        lon1r = radians(pointA[1])
        lat2r = radians(pointB[0])
        lon2r = radians(pointB[1])

        # Haversine formula (minimized repeated trig calls)
        dlat = lat2r - lat1r
        dlon = lon2r - lon1r
        sin_dlat_2 = sin(dlat * 0.5)
        sin_dlon_2 = sin(dlon * 0.5)
        a = sin_dlat_2 * sin_dlat_2 + cos(lat1r) * cos(lat2r) * sin_dlon_2 * sin_dlon_2
        c = 2 * asin(sqrt(a))

        # Radius of earth: kilometers or miles
        r = 6371 if distance_unit == "km" else 3956

        # Inline bearing calculation to avoid extra function call
        x = sin(dlon) * cos(lat2r)
        y = cos(lat1r) * sin(lat2r) - sin(lat1r) * cos(lat2r) * cos(dlon)
        initial_bearing = degrees(atan2(x, y))
        # Now we have the initial bearing but math.atan2 return values
        # from -180 to + 180 degrees which is not what we want for a compass bearing
        # The solution is to normalize the initial bearing as shown below
        bearing = (initial_bearing + 360) % 360

        # Returns distance (index 0), cardinal (index 1), raw bearing (index 2)
        return [(c * r), self.get_cardinal_direction(bearing), bearing]

    def get_cardinal_direction(self, degree, return_only_labels=False):
        """
        Divides compass into 16 wedges and returns direction label.
        """
        DEFAULT_DIRECTIONS = [
            "N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE",
            "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW",
        ]
        
        skin_dict = self.generator.skin_dict
        ordinate_names = (
            skin_dict.get("Units", {}).get("Ordinates", {}).get("directions", None)
        )
        
        if ordinate_names is not None:
            names = (
                ordinate_names if isinstance(ordinate_names, list)
                else weeutil.weeutil.option_as_list(ordinate_names)
            )
        else:
            names = DEFAULT_DIRECTIONS
            
        if return_only_labels:
            return names
            
        try:
            idx = int(((float(degree) - 11.25) / 22.5) + 1) % 16
            return names[idx]
        except (ValueError, TypeError):
            return names[0]

    def _get_radar_html(self, extras_dict, lat, lon, zoom, width, height,
                        rain, wind, temp, marker, overlay):
        """Generate radar HTML based on provider configuration."""
        custom = extras_dict.get("radar_html", "")
        if custom:
            return custom
        
        if extras_dict.get("aeris_map") == "1":
            return self._build_aeris_radar(
                extras_dict, width, height, lat, lon, zoom, dark=False
            )
        return self._build_windy_radar(
            width, height, lat, lon, zoom, rain, wind, temp, marker == "true", overlay
        )

    def _get_radar_html_dark(self, extras_dict, lat, lon, zoom, overlay, width, height):
        """Generate dark mode radar HTML based on provider configuration."""
        custom = extras_dict.get("radar_html_dark", "")
        if custom:
            return custom
        
        if extras_dict.get("aeris_map") == "1":
            return self._build_aeris_radar(
                extras_dict, width, height, lat, lon, zoom, dark=True
            )
        return "None"

    def _get_radar_html_kiosk(self, extras_dict, skin_dict):
        """Generate kiosk mode radar HTML."""
        width = extras_dict.get("radar_width_kiosk", "")
        height = extras_dict.get("radar_height_kiosk", "")
        src = skin_dict.get("Extras", {}).get("radar_html_kiosk", "")
        return f'<iframe width="{width}px" height="{height}px" src="{src}" frameborder="0"></iframe>'

    def _build_aeris_radar(self, extras_dict, width, height, lat, lon, zoom, dark=False):
        """Build Aeris API radar embed HTML."""
        theme = "flat-dk" if dark else "flat"
        blend = "lighten" if dark else "darken"
        city_suffix = "-dk" if dark else ""
        water_suffix = "-dk" if dark else ""
        
        return (
            f'<img style="object-fit:cover;width:{width}px;height:{height}px" '
            f'src="https://maps.aerisapi.com/{extras_dict["forecast_api_id"]}'
            f'_{extras_dict["forecast_api_secret"]}/{theme},water-depth{water_suffix},'
            f'counties:60,rivers,interstates:60,admin-cities{city_suffix},'
            f'alerts-severe:50:blend({blend}),radar:blend({blend})/'
            f'{width}x{height}/{lat},{lon},{zoom}/current.png" '
            f'referrerpolicy="no-referrer"></img>'
        )

    def _build_windy_radar(self, width, height, lat, lon, zoom, rain, wind, temp, marker, overlay):
        """Build Windy.com embedded radar HTML."""
        marker_str = "true" if marker else "false"
        return (
            f'<iframe width="{width}px" height="{height}px" '
            f'src="https://embed.windy.com/embed2.html?lat={lat}&lon={lon}'
            f'&zoom={zoom}&level=surface'
            f'&overlay={overlay}'
            f'&menu=&message=true'
            f'&marker={marker_str}&calendar=&pressure=&type=map'
            f'&location=coordinates&detail=&detailLat={lat}&detailLon={lon}'
            f'&metricRain={rain}&metricWind={wind}&metricTemp={temp}'
            f'&radarRange=-1" frameborder="0"></iframe>'
        )

    def _convert_temperature(self, value, from_unit, formatter):
        """Convert temperature value and format for display."""
        conversion_tuple = (value, from_unit, "group_temperature")
        converted = self.generator.converter.convert(conversion_tuple)[0]
        return formatter % converted

    def get_extension_list(self, timespan, db_lookup):
        """
        Build the data needed for the Belchertown skin
        """
        # Cache frequently accessed objects
        config_dict = self.generator.config_dict
        skin_dict = self.generator.skin_dict
        extras_dict = self.generator.skin_dict["Extras"]
        db_binder = self.generator.db_binder

        # Look for the debug flag which can be used to show more logging
        weewx.debug = int(config_dict.get("debug", 0))

        # Setup label dict for text and titles
        try:
            d = skin_dict["Labels"]["Generic"]
        except KeyError:
            d = {}
        label_dict = weeutil.weeutil.KeyDict(d)

        # Setup database manager
        binding = config_dict["StdReport"].get("data_binding", "wx_binding")
        manager = db_binder.get_manager(binding)

        belchertown_debug = int(extras_dict.get("belchertown_debug", 0))

        if belchertown_debug > 0:
            log.info(f"'belchertown_debug' set to {belchertown_debug}")

        # Find the right HTML ROOT
        weewx_root = config_dict["WEEWX_ROOT"]
        if "HTML_ROOT" in skin_dict:
            html_root = os.path.join(
                weewx_root,
                skin_dict["HTML_ROOT"],
            )
        else:
            html_root = os.path.join(
                weewx_root,
                config_dict["StdReport"]["HTML_ROOT"],
            )

        # Setup UTC offset hours for moment.js in index.html
        moment_js_stop_struct = time.localtime(time.time())
        moment_js_utc_offset = (
            calendar.timegm(moment_js_stop_struct)
            - calendar.timegm(time.gmtime(time.mktime(moment_js_stop_struct)))
        ) / 60

        try:
            moment_js_tz = skin_dict["Units"]["TimeZone"].get("time_zone")
        except KeyError:
            moment_js_tz = ""

        # Highcharts UTC offset is the opposite of normal. Positive values are
        # west, negative values are east of UTC.
        # https://api.highcharts.com/highcharts/time.timezoneOffset Multiplying
        # by -1 will reverse the number sign and keep 0 (not -0).
        # https://stackoverflow.com/a/14053631/1177153
        highcharts_timezoneoffset = moment_js_utc_offset * -1

        # If theme locale is auto, get the system locale for use with
        # moment.js, and the system decimal for use with highcharts
        belchertown_locale = extras_dict["belchertown_locale"]
        if belchertown_locale == "auto":
            system_locale, locale_encoding = locale.getdefaultlocale()
        else:
            try:
                # Try setting the locale. Locale needs to be in locale.encoding
                # format. Example: "en_US.UTF-8", or "de_DE.UTF-8"
                locale.setlocale(
                    locale.LC_ALL,
                    belchertown_locale,
                )
                system_locale, locale_encoding = locale.getlocale()
            except Exception as e:
                # The system can't find the locale requested, so just set the
                # variables anyways for JavaScript's use.
                system_locale, locale_encoding = belchertown_locale.split(".")
                if belchertown_debug:
                    log.error(
                        f"Error using locale {belchertown_locale}. "
                        "This locale may not be installed on your system and you may see unexpected results. "
                        f"Python could not set the requested locale, but Belchertown skin JavaScript will attempt to use the provided locale string. Full error: {e}"
                    )

        if system_locale is None:
            # Unable to determine locale. Fallback to en_US
            system_locale = "en_US"

        if locale_encoding is None:
            # Unable to determine locale_encoding. Fallback to UTF-8
            locale_encoding = "UTF-8"

        try:
            system_locale_js = system_locale.replace(
                "_", "-"
            )  # Python's locale is underscore. JS uses dashes.
        except Exception:
            system_locale_js = "en-US"  # Error finding locale, set to en-US

        # Cache locale conversion for highcharts settings
        locale_conv = locale.localeconv()

        highcharts_decimal = extras_dict.get("highcharts_decimal", None)
        # Change the Highcharts decimal to the locale if the option is missing
        # or on auto mode, otherwise use whats defined in Extras
        if highcharts_decimal is None or highcharts_decimal == "auto":
            highcharts_decimal = locale_conv.get("decimal_point", ".")

        highcharts_thousands = extras_dict.get("highcharts_thousands", None)
        # Change the Highcharts thousands separator to the locale if the option
        # is missing or on auto mode, otherwise use whats defined in Extras
        if highcharts_thousands is None or highcharts_thousands == "auto":
            highcharts_thousands = locale_conv.get("thousands_sep", ",")

        # Get the archive interval for the highcharts gapsize
        try:
            archive_interval_ms = (
                int(config_dict["StdArchive"]["archive_interval"]) * 1000
            )
        except KeyError:
            archive_interval_ms = (
                300000  # 300*1000 for archive_interval emulated to millis
            )

        # Get the ordinal labels
        ordinate_names = self.get_cardinal_direction("", True)

        # Build the chart array for the HTML.  Outputs a dict of nested lists
        # which allow you to have different charts for different timespans on
        # the site in different order with different names.
        # OrderedDict([('day', ['chart1', 'chart2', 'chart3', 'chart4']),
        # ('week', ['chart1', 'chart5', 'chart6', 'chart2', 'chart3', 'chart4']),
        # ('month', ['this_is_chart1', 'chart2_is_here', 'chart3', 'windSpeed_and_windDir', 'chart5', 'chart6', 'chart7']),
        # ('year', ['chart1', 'chart2', 'chart3', 'chart4', 'chart5'])])
        skin_root_path = os.path.join(
            weewx_root,
            skin_dict["SKIN_ROOT"],
            skin_dict.get("skin", ""),
        )
        chart_config_path = os.path.join(skin_root_path, "graphs.conf")
        default_chart_config_path = os.path.join(skin_root_path, "graphs.conf.example")
        if os.path.exists(chart_config_path):
            chart_dict = configobj.ConfigObj(chart_config_path, file_error=True)
        else:
            chart_dict = configobj.ConfigObj(default_chart_config_path, file_error=True)
        charts = OrderedDict()
        for chart_timespan in chart_dict.sections:
            timespan_chart_list = []
            for plotname in chart_dict[chart_timespan].sections:
                if plotname not in timespan_chart_list:
                    timespan_chart_list.append(plotname)
            charts[chart_timespan] = timespan_chart_list

        # Create a dict of chart group titles for use on the graphs page
        # header. If no title defined, use the chart group name
        graphpage_titles = OrderedDict()
        for chartgroup in chart_dict.sections:
            chart_group_config = chart_dict[chartgroup]
            graphpage_titles[chartgroup] = chart_group_config.get("title", chartgroup)

        # Create a dict of chart group page content for use on the graphs page
        # below the header.
        graphpage_content = OrderedDict()
        for chartgroup in chart_dict.sections:
            if "page_content" in chart_dict[chartgroup]:
                graphpage_content[chartgroup] = chart_dict[chartgroup]["page_content"]

        # Setup the Graphs page button row based on the skin extras option and
        # the button_text from graphs.conf
        graph_page_graphgroup_buttons = [
            chartgroup
            for chartgroup in chart_dict.sections
            if chart_dict[chartgroup].get("show_button", "").lower() == "true"
        ]
        button_parts = []
        for gg in graph_page_graphgroup_buttons:
            button_text = chart_dict[gg].get("button_text", gg)
            button_parts.append(
                f'<a href="./?graph={gg}"><button type="button" class="btn btn-primary">{button_text}</button></a>'
            )
        graph_page_buttons = " ".join(button_parts)

        # Set a default radar URL using station's lat/lon
        lat = config_dict["Station"]["latitude"]
        lon = config_dict["Station"]["longitude"]
        radar_width = extras_dict["radar_width"]
        radar_height = extras_dict["radar_height"]
        radar_rain = extras_dict["radar_rain"]
        radar_temp = extras_dict["radar_temp"]
        radar_wind = extras_dict["radar_wind"]
        zoom = extras_dict.get("radar_zoom", "8")
        marker = "true" if (
            "radar_marker" in extras_dict and extras_dict["radar_marker"] == "1"
        ) else ""
        radar_overlay = "radar"
        if ("radar_overlay" in extras_dict and extras_dict["radar_overlay"] != ""):
          radar_overlay = extras_dict["radar_overlay"]

        radar_html = self._get_radar_html(
            extras_dict, lat, lon, zoom, radar_width, radar_height,
            radar_rain, radar_wind, radar_temp, marker, radar_overlay
        )
        radar_html_dark = self._get_radar_html_dark(
            extras_dict, lat, lon, zoom, radar_width, radar_height, radar_overlay
        )
        radar_html_kiosk = (
            self._get_radar_html_kiosk(extras_dict, skin_dict)
            if extras_dict.get("radar_html_kiosk") != ""
            else radar_html
        )

        if extras_dict.get("radar_html_kiosk") != "":
            radar_width_kiosk = extras_dict["radar_width_kiosk"]
            radar_height_kiosk = extras_dict["radar_height_kiosk"]
            radar_html_kiosk = f'<iframe width="{radar_width_kiosk}px" height="{radar_height_kiosk}px" src="{skin_dict["Extras"]["radar_html_kiosk"]}" frameborder="0"></iframe>'

        # ==============================================================================
        # Build the all time stats.
        # ==============================================================================

        wx_manager = db_lookup()

        # Find the beginning of the current year
        now = datetime.datetime.now()
        year_start_epoch = int(datetime.datetime(now.year, 1, 1, 0, 0).timestamp())
        today_start_epoch = int(
            datetime.datetime(now.year, now.month, now.day, 0, 0).timestamp()
        )

        # Setup the converter
        # Get the target unit nickname (something like 'US' or 'METRIC'):
        target_unit_nickname = config_dict["StdConvert"]["target_unit"]
        # Get the target unit: weewx.US, weewx.METRIC, weewx.METRICWX
        target_unit = weewx.units.unit_constants[target_unit_nickname.upper()]
        # Bind to the appropriate standard converter units
        converter = weewx.units.StdUnitConverters[target_unit]

        # Temperature Range Lookups
        # Use parameterized queries for safety and clarity
        temp_range_sql = """
            SELECT dateTime, (max - min) as total, min, max
            FROM archive_day_outTemp
            WHERE dateTime >= ? AND dateTime < ? AND min IS NOT NULL AND max IS NOT NULL
            ORDER BY total {order} LIMIT 1;
        """
        
        year_outTemp_max_range_query = wx_manager.getSql(
            temp_range_sql.format(order="DESC"), (year_start_epoch, today_start_epoch)
        )
        year_outTemp_min_range_query = wx_manager.getSql(
            temp_range_sql.format(order="ASC"), (year_start_epoch, today_start_epoch)
        )
        at_outTemp_max_range_query = wx_manager.getSql(
            temp_range_sql.format(order="DESC"), (0, today_start_epoch)
        )
        at_outTemp_min_range_query = wx_manager.getSql(
            temp_range_sql.format(order="ASC"), (0, today_start_epoch)
        )

        # Find the group_name for outTemp in database
        outTemp_unit = converter.group_unit_dict["group_temperature"]

        # Find the group_name for outTemp from the skin.conf
        skin_outTemp_unit = self.generator.converter.group_unit_dict[
            "group_temperature"
        ]

        # Find the number of decimals to round to based on the skin.conf
        outTemp_round = skin_dict["Units"]["StringFormats"].get(
            skin_outTemp_unit, "%.1f"
        )

        # Largest Daily Temperature Range Conversions
        if year_outTemp_max_range_query is not None:
            max_val = self._convert_temperature(
                year_outTemp_max_range_query[3], outTemp_unit, outTemp_round
            )
            min_val = self._convert_temperature(
                year_outTemp_max_range_query[2], outTemp_unit, outTemp_round
            )
            total = outTemp_round % (float(max_val) - float(min_val))
            year_outTemp_range_max = [
                year_outTemp_max_range_query[0],
                locale.format_string("%g", float(total)),
                locale.format_string("%g", float(min_val)),
                locale.format_string("%g", float(max_val)),
            ]
        else:
            year_outTemp_range_max = [
                calendar.timegm(time.gmtime()),
                locale.format_string("%.1f", 0),
                locale.format_string("%.1f", 0),
                locale.format_string("%.1f", 0),
            ]

        if year_outTemp_min_range_query is not None:
            max_val = self._convert_temperature(
                year_outTemp_min_range_query[3], outTemp_unit, outTemp_round
            )
            min_val = self._convert_temperature(
                year_outTemp_min_range_query[2], outTemp_unit, outTemp_round
            )
            total = outTemp_round % (float(max_val) - float(min_val))
            year_outTemp_range_min = [
                year_outTemp_min_range_query[0],
                locale.format_string("%g", float(total)),
                locale.format_string("%g", float(min_val)),
                locale.format_string("%g", float(max_val)),
            ]
        else:
            year_outTemp_range_min = [
                calendar.timegm(time.gmtime()),
                locale.format_string("%.1f", 0),
                locale.format_string("%.1f", 0),
                locale.format_string("%.1f", 0),
            ]

        if at_outTemp_max_range_query is not None:
            max_val = self._convert_temperature(
                at_outTemp_max_range_query[3], outTemp_unit, outTemp_round
            )
            min_val = self._convert_temperature(
                at_outTemp_max_range_query[2], outTemp_unit, outTemp_round
            )
            total = outTemp_round % (float(max_val) - float(min_val))
            at_outTemp_range_max = [
                at_outTemp_max_range_query[0],
                locale.format_string("%g", float(total)),
                locale.format_string("%g", float(min_val)),
                locale.format_string("%g", float(max_val)),
            ]
        else:
            at_outTemp_range_max = [
                calendar.timegm(time.gmtime()),
                locale.format_string("%.1f", 0),
                locale.format_string("%.1f", 0),
                locale.format_string("%.1f", 0),
            ]

        # All Time - Smallest Daily Temperature Range Conversions
        # Max temperature for this day
        if at_outTemp_min_range_query is not None:
            at_outTemp_min_range_max_tuple = (
                at_outTemp_min_range_query[3],
                outTemp_unit,
                "group_temperature",
            )
            at_outTemp_min_range_max = (
                outTemp_round
                % self.generator.converter.convert(at_outTemp_min_range_max_tuple)[0]
            )
            # Min temperature for this day
            at_outTemp_min_range_min_tuple = (
                at_outTemp_min_range_query[2],
                outTemp_unit,
                "group_temperature",
            )
            at_outTemp_min_range_min = (
                outTemp_round
                % self.generator.converter.convert(at_outTemp_min_range_min_tuple)[0]
            )
            # Smallest Daily Temperature Range total
            at_outTemp_min_range_total = outTemp_round % (
                float(at_outTemp_min_range_max) - float(at_outTemp_min_range_min)
            )
            # Replace the SQL Query output with the converted values
            at_outTemp_range_min = [
                at_outTemp_min_range_query[0],
                locale.format_string("%g", float(at_outTemp_min_range_total)),
                locale.format_string("%g", float(at_outTemp_min_range_min)),
                locale.format_string("%g", float(at_outTemp_min_range_max)),
            ]
        else:
            at_outTemp_range_min = [
                calendar.timegm(time.gmtime()),
                locale.format_string("%.1f", 0),
                locale.format_string("%.1f", 0),
                locale.format_string("%.1f", 0),
            ]

        # Rain lookups
        # Find the group_name for rain in database
        rain_unit = converter.group_unit_dict["group_rain"]

        # Find the group_name for rain in the skin.conf
        skin_rain_unit = self.generator.converter.group_unit_dict["group_rain"]

        # Find the number of decimals to round the result based on the skin.conf
        rain_round = skin_dict["Units"]["StringFormats"].get(skin_rain_unit, "%.2f")

        rainiest_day_sql = """
            SELECT dateTime, sum FROM archive_day_rain
            WHERE dateTime >= ? ORDER BY sum DESC LIMIT 1;
        """
        rainiest_day_query = wx_manager.getSql(rainiest_day_sql, (year_start_epoch,))
        if rainiest_day_query is not None:
            rainiest_day_tuple = (rainiest_day_query[1], rain_unit, "group_rain")
            rainiest_day_converted = (
                rain_round % self.generator.converter.convert(rainiest_day_tuple)[0]
            )
            rainiest_day = [
                rainiest_day_query[0],
                locale.format_string("%g", float(rainiest_day_converted)),
            ]
        else:
            rainiest_day = [
                calendar.timegm(time.gmtime()),
                locale.format_string("%.2f", 0),
            ]

        at_rainiest_day_sql = """
            SELECT dateTime, sum FROM archive_day_rain
            ORDER BY sum DESC LIMIT 1;
        """
        at_rainiest_day_query = wx_manager.getSql(at_rainiest_day_sql)
        at_rainiest_day_tuple = (at_rainiest_day_query[1], rain_unit, "group_rain")
        at_rainiest_day_converted = (
            rain_round % self.generator.converter.convert(at_rainiest_day_tuple)[0]
        )
        at_rainiest_day = [
            at_rainiest_day_query[0],
            locale.format_string("%g", float(at_rainiest_day_converted)),
        ]

        # Find what kind of database we're working with and specify the
        # correctly tailored SQL Query for each type of database
        data_binding = config_dict["StdArchive"]["data_binding"]
        database = config_dict["DataBindings"][data_binding]["database"]
        database_type = config_dict["Databases"][database]["database_type"]
        driver = config_dict["DatabaseTypes"][database_type]["driver"]
        current_year = str(now.year)
        if driver == "weedb.sqlite":
            year_rainiest_month_sql = """
                SELECT strftime('%m', datetime(dateTime, 'unixepoch', 'localtime')) AS month, SUM(sum) AS total
                FROM archive_day_rain
                WHERE strftime('%Y', datetime(dateTime, 'unixepoch', 'localtime')) = ?
                GROUP BY month ORDER BY total DESC LIMIT 1;
            """
            at_rainiest_month_sql = """
                SELECT strftime('%m', datetime(dateTime, 'unixepoch', 'localtime')) AS month, strftime('%Y', datetime(dateTime, 'unixepoch', 'localtime')) AS year, SUM(sum) AS total
                FROM archive_day_rain
                GROUP BY month, year ORDER BY total DESC LIMIT 1;
            """
            year_rain_data_sql = """
                SELECT dateTime, sum FROM archive_day_rain
                WHERE strftime('%Y', datetime(dateTime, 'unixepoch', 'localtime')) = ?;
            """
            at_rain_highest_year_sql = """
                SELECT strftime('%Y', datetime(dateTime, 'unixepoch', 'localtime')) AS year, SUM(sum) AS total
                FROM archive_day_rain
                GROUP BY year ORDER BY total DESC LIMIT 1;
            """
        elif driver == "weedb.mysql":
            year_rainiest_month_sql = """
                SELECT FROM_UNIXTIME(dateTime, '%%m') AS month, ROUND(SUM(sum), 2) AS total
                FROM archive_day_rain
                WHERE YEAR(FROM_UNIXTIME(dateTime)) = ?
                GROUP BY month ORDER BY total DESC LIMIT 1;
            """
            at_rainiest_month_sql = """
                SELECT FROM_UNIXTIME(dateTime, '%%m') AS month, FROM_UNIXTIME(dateTime, '%%Y') AS year, ROUND(SUM(sum), 2) AS total
                FROM archive_day_rain
                GROUP BY month, year ORDER BY total DESC LIMIT 1;
            """
            year_rain_data_sql = """
                SELECT dateTime, ROUND(sum, 2) FROM archive_day_rain
                WHERE year(FROM_UNIXTIME(dateTime)) = ?;
            """
            at_rain_highest_year_sql = """
                SELECT FROM_UNIXTIME(dateTime, '%%Y') AS year, ROUND(SUM(sum), 2) AS total
                FROM archive_day_rain
                GROUP BY year ORDER BY total DESC LIMIT 1;
            """

        # Rainiest month
        year_rainiest_month_query = wx_manager.getSql(
            year_rainiest_month_sql, (current_year,)
        )
        if year_rainiest_month_query is not None:
            year_rainiest_month_tuple = (
                year_rainiest_month_query[1],
                rain_unit,
                "group_rain",
            )
            year_rainiest_month_converted = (
                rain_round
                % self.generator.converter.convert(year_rainiest_month_tuple)[0]
            )
            year_rainiest_month_name = calendar.month_name[
                int(year_rainiest_month_query[0])
            ]
            year_rainiest_month = [
                year_rainiest_month_name,
                locale.format_string("%g", float(year_rainiest_month_converted)),
            ]
        else:
            year_rainiest_month = ["N/A", 0.0]

        # All time rainiest month
        at_rainiest_month_query = wx_manager.getSql(at_rainiest_month_sql)
        at_rainiest_month_tuple = (at_rainiest_month_query[2], rain_unit, "group_rain")
        at_rainiest_month_converted = (
            rain_round % self.generator.converter.convert(at_rainiest_month_tuple)[0]
        )
        at_rainiest_month_name = calendar.month_name[int(at_rainiest_month_query[0])]
        at_rainiest_month = [
            f"{at_rainiest_month_name}, {at_rainiest_month_query[1]}",
            locale.format_string("%g", float(at_rainiest_month_converted)),
        ]

        # All time rainiest year
        at_rain_highest_year_query = wx_manager.getSql(at_rain_highest_year_sql)
        at_rain_highest_year_tuple = (
            at_rain_highest_year_query[1],
            rain_unit,
            "group_rain",
        )
        at_rain_highest_year_converted = (
            rain_round % self.generator.converter.convert(at_rain_highest_year_tuple)[0]
        )
        at_rain_highest_year = [
            at_rain_highest_year_query[0],
            locale.format_string("%g", float(at_rain_highest_year_converted)),
        ]

        # Consecutive days with/without rainfall
        year_days_with_rain_total = 0
        year_days_without_rain_total = 0
        year_days_with_rain_output = {}
        year_days_without_rain_output = {}
        year_rain_query = wx_manager.genSql(year_rain_data_sql, (current_year,))
        for row in year_rain_query:
            if row[1] != 0:
                year_days_with_rain_total += 1
            else:
                year_days_with_rain_total = 0
            if row[1] == 0:
                year_days_without_rain_total += 1
            else:
                year_days_without_rain_total = 0
            year_days_with_rain_output[row[0]] = year_days_with_rain_total
            year_days_without_rain_output[row[0]] = year_days_without_rain_total

        if year_days_with_rain_output:
            year_days_with_rain = max(
                zip(
                    year_days_with_rain_output.values(),
                    year_days_with_rain_output.keys(),
                )
            )
        else:
            year_days_with_rain = [
                locale.format_string("%.1f", 0),
                calendar.timegm(time.gmtime()),
            ]

        if year_days_without_rain_output:
            year_days_without_rain = max(
                zip(
                    year_days_without_rain_output.values(),
                    year_days_without_rain_output.keys(),
                )
            )
        else:
            year_days_without_rain = [
                locale.format_string("%.1f", 0),
                calendar.timegm(time.gmtime()),
            ]

        epoch_prev = 0
        at_days_with_rain_total = 0
        at_days_without_rain_total = 0
        at_days_with_rain_output = {}
        at_days_without_rain_output = {}
        at_rain_query = wx_manager.genSql(
            "SELECT dateTime, ROUND( sum, 2 ), count FROM archive_day_rain;"
        )
        for row in at_rain_query:
            if round((row[0] / 86400)) - epoch_prev != 1 or row[2] == 0:
                at_days_with_rain_total = 0
                at_days_without_rain_total = 0
            epoch_prev = round((row[0] / 86400))
            # Original MySQL way: CASE WHEN sum!=0 THEN @total+1 ELSE 0 END
            if row[1] != 0:
                at_days_with_rain_total += 1
            else:
                at_days_with_rain_total = 0

            # Original MySQL way: CASE WHEN sum=0 THEN @total+1 ELSE 0 END
            if row[1] == 0:
                at_days_without_rain_total += 1
            else:
                at_days_without_rain_total = 0

            at_days_with_rain_output[row[0]] = at_days_with_rain_total
            at_days_without_rain_output[row[0]] = at_days_without_rain_total

        if len(at_days_with_rain_output) > 0:
            at_days_with_rain = max(
                zip(at_days_with_rain_output.values(), at_days_with_rain_output.keys())
            )
        else:
            at_days_with_rain = (0, 0)

        if len(at_days_without_rain_output) > 0:
            at_days_without_rain = max(
                zip(
                    at_days_without_rain_output.values(),
                    at_days_without_rain_output.keys(),
                )
            )
        else:
            at_days_without_rain = (0, 0)

        # This portion is right from the WeeWX sample
        # http://www.weewx.com/docs/customizing.htm

        all_stats = TimespanBinder(
            timespan,
            db_lookup,
            formatter=self.generator.formatter,
            converter=self.generator.converter,
            skin_dict=self.generator.skin_dict,
        )

        # Get the unit label from the skin dict for speed.
        windSpeed_unit = self.generator.skin_dict["Units"]["Groups"]["group_speed"]
        windSpeed_unit_label = self.generator.skin_dict["Units"]["Labels"][
            windSpeed_unit
        ]

        # ==============================================================================
        # Get NOAA Data
        # ==============================================================================
        years = []
        noaa_header_html = ""
        default_noaa_file = ""
        noaa_dir = html_root + "/NOAA/"

        try:
            noaa_file_list = os.listdir(noaa_dir)

            # Generate a list of years based on file name
            for f in noaa_file_list:
                filename = f.split(".")[0]  # Drop the .txt
                year = filename.split("-")[1]
                years.append(year)

            # Remove duplicates with set, and sort numerically, then reverse
            # sort with [::-1] oldest year last
            # first_year = years[0]
            # final_year = years[-1]
            years = sorted(set(years))[::-1]

            # Build NOAA header HTML using list then join for efficiency
            noaa_parts = []
            for y in years:
                # Link to the year file
                year_file = f"{noaa_dir}NOAA-{y}.txt"
                if os.path.exists(year_file):
                    noaa_parts.append(
                        f"""<a href="?yr={y}" class="noaa_rep_nav"><b>{y}</b></a>:"""
                    )
                else:
                    noaa_parts.append(
                        f"""<span class="noaa_rep_nav"><b>{y}</b></span>:"""
                    )

                # Loop through all 12 months and find if the file exists.  If
                # the file doesn't exist, just show the month name in the
                # header without a href link.  There is no month 13, but we
                # need to loop to 12, so 13 is where it stops.
                month_links = []
                for i in range(1, 13):
                    month_num = f"{i:02d}"  # Pad the number with a 0 since the NOAA files use 2 digit month
                    month_abbr = calendar.month_abbr[i]
                    month_file = f"{noaa_dir}NOAA-{y}-{month_num}.txt"
                    if os.path.exists(month_file):
                        month_links.append(
                            f"""<a href="?yr={y}&amp;mo={month_num}" class="noaa_rep_nav"><b>{month_abbr}</b></a>"""
                        )
                    else:
                        month_links.append(
                            f"""<span class="noaa_rep_nav"><b>{month_abbr}</b></span>"""
                        )

                noaa_parts.append(" ".join(month_links))
                noaa_parts.append("<br>")

            noaa_header_html = "".join(noaa_parts)

            # Find the current month's NOAA file for the default file to show
            # on JavaScript page load.  The NOAA files are generated as part of
            # this skin, but if for some reason that the month file doesn't
            # exist, use the year file.
            now = datetime.datetime.now()
            current_year = str(now.year)
            current_month = str(format(now.month, "02"))
            if os.path.exists(noaa_dir + f"NOAA-{current_year}-{current_month}.txt"):
                default_noaa_file = f"NOAA-{current_year}-{current_month}.txt"
            else:
                default_noaa_file = f"NOAA-{current_year}.txt"
        except Exception:
            # There's an error - I've seen this on first run and the NOAA
            # folder is not created yet. Skip this section.
            pass

        # ==============================================================================
        # Forecast Data
        # ==============================================================================

        # provider switch (default Xweather/Aeris)
        forecast_provider = extras_dict.get("forecast_provider", "").strip().lower()
        if forecast_provider not in ("", "pirateweather", "aeris", "xweather"):
            forecast_provider = ""

        # Ensure AQI variables are always defined to avoid NameError when forecast is disabled or fails
        # aqi and aqi_category are global so they can be used by Highcharts
        global aqi, aqi_category
        aqi = "No Data"
        aqi_category = ""
        aqi_location = ""
        aqi_time = ""

        # ----------------------------
        # Pirate Weather
        # ----------------------------

        try:
            if (
                extras_dict["forecast_enabled"] == "1"
                and extras_dict["forecast_api_id"] != ""
                or "forecast_dev_file" in extras_dict
            ):

                # Setup variables common to both forecast sources
                forecast_file = f"{html_root}/json/forecast.json"
                current_conditions_file = f"{html_root}/json/current_conditions.json"

                forecast_api_id = extras_dict["forecast_api_id"]
                forecast_api_secret = extras_dict["forecast_api_secret"]
                forecast_units = extras_dict["forecast_units"].lower()
                forecast_lang = extras_dict["forecast_lang"].lower()

                latitude = config_dict["Station"]["latitude"]
                longitude = config_dict["Station"]["longitude"]

                forecast_place = extras_dict["forecast_place"]
                if forecast_place:
                    if belchertown_debug > 0:
                        log.info(
                            f"Forecast data using {forecast_place}, instead of [Station] longitude/latitude"
                        )
                else:
                    forecast_place = f"{latitude},{longitude}"
                if belchertown_debug > 0:
                    log.info(f"forecast_place set to {forecast_place}")

                forecast_stale_timer = int(extras_dict["forecast_stale"])
                current_conditions_stale_timer = int(
                    extras_dict["current_conditions_stale"]
                )

                if os.path.isfile(forecast_file):
                    # belchertown.py is called 12 times per archive, so the last condition ensures forecast on the hour is only downloaded once
                    current_time = int(time.time())
                    file_modtime = int(os.path.getmtime(forecast_file))
                    archive_interval = int(
                        config_dict["StdArchive"]["archive_interval"]
                    )
                    forecast_is_stale = (
                        (current_time - file_modtime) > forecast_stale_timer
                        or os.stat(forecast_file).st_size == 0
                        or (
                            int(time.strftime("%M")) < archive_interval / 60
                            and (current_time - file_modtime) > archive_interval
                        )
                    )
                else:
                    forecast_is_stale = True
                current_conditions_is_stale = True
                if os.path.isfile(current_conditions_file):
                    current_conditions_is_stale = (
                        int(time.time())
                        - int(os.path.getmtime(current_conditions_file))
                    ) > current_conditions_stale_timer or os.stat(
                        current_conditions_file
                    ).st_size == 0

                if forecast_provider == "pirateweather":
                    # Fetch → normalize → write forecast
                    if forecast_is_stale:
                        try:
                            url = f"https://api.pirateweather.net/forecast/{forecast_api_id}/{latitude},{longitude}?units={forecast_units}&lang={forecast_lang}&exclude=minutely"
                            pw_raw = _http_get_json(url)
                            normalized = _pw_transform_to_belch(pw_raw)
                            os.makedirs(os.path.dirname(forecast_file), exist_ok=True)
                            with open(forecast_file, "w", encoding="utf-8") as fh:
                                json.dump(
                                    normalized,
                                    fh,
                                    ensure_ascii=False,
                                    separators=(",", ":"),
                                )
                            log.debug(
                                f"New Pirate Weather forecast cached to {forecast_file}"
                            ),
                        except urllib.error.HTTPError as e:
                            log.error(
                                f"Pirate Weather HTTP error {e.code}: {e.reason}",
                            )
                        except ValueError as e:
                            log.error(f"Pirate Weather missing config: {e}")
                        except Exception as e:
                            log.error(f"Pirate Weather update failed: {e}")
                    #else:
                    #   log.info("Forecast is current, no update needed.")

                    # current_conditions.json (tiny file just with 'current')
                    if current_conditions_is_stale:
                        try:
                            with open(forecast_file, "r", encoding="utf-8") as rf:
                                data_cc = json.load(rf)
                            cc_out = {
                                "timestamp": int(time.time()),
                                "current": [data_cc.get("current", {})],
                            }
                            with open(
                                current_conditions_file, "w", encoding="utf-8"
                            ) as wf:
                                json.dump(
                                    cc_out,
                                    wf,
                                    ensure_ascii=False,
                                    separators=(",", ":"),
                                )
                            log.info(
                                f"New Pirate Weather current conditions cached to {current_conditions_file}",
                            )
                        except Exception as e:
                            log.error(
                                f"Pirate Weather current-conditions write failed: {e}",
                            )
                    #else:
                    #   log.info("Current conditions are current, no update needed.")

                    # Read current_conditions.json and populate the variables used below
                    with open(current_conditions_file, "r") as read_file:
                        data = json.load(read_file)
                    try:
                        current_conditions_data = data["current"][0]
                        vis_val = current_conditions_data.get("visibility")
                        if forecast_units in ("si", "ca"):
                            visibility = (
                                locale.format_string("%g", float(vis_val))
                                if vis_val is not None
                                else "N/A"
                            )
                            visibility_unit = "km"
                        else:
                            visibility = (
                                locale.format_string("%g", float(vis_val))
                                if vis_val is not None
                                else "N/A"
                            )
                            visibility_unit = "miles"
                        current_obs_icon = current_conditions_data.get("icon", "") or ""
                        current_obs_summary = (
                            current_conditions_data.get("summary", "") or ""
                        )
                        cloud_cover = f"{current_conditions_data.get('cloudCover', '')}"
                    except Exception as e:
                        current_obs_icon = ""
                        current_obs_summary = ""
                        visibility = "N/A"
                        visibility_unit = ""
                        cloud_cover = ""
                        log.error(f"Pirate Weather parse error: {e}")
                else:

                    def xweather_coded_weather(data):
                        """Convert Aeris/Xweather codes to human readable strings."""
                        # https://www.xweather.com/docs/weather-api/reference/weather-codes
                        output = ""
                        coverage_code = data.split(":")[0]
                        intensity_code = data.split(":")[1]
                        weather_code = data.split(":")[2]

                        cloud_dict = {
                            "CL": label_dict["forecast_cloud_code_CL"],
                            "FW": label_dict["forecast_cloud_code_FW"],
                            "SC": label_dict["forecast_cloud_code_SC"],
                            "BK": label_dict["forecast_cloud_code_BK"],
                            "OV": label_dict["forecast_cloud_code_OV"],
                        }

                        coverage_dict = {
                            "AR": label_dict["forecast_coverage_code_AR"],
                            "BR": label_dict["forecast_coverage_code_BR"],
                            "C": label_dict["forecast_coverage_code_C"],
                            "D": label_dict["forecast_coverage_code_D"],
                            "FQ": label_dict["forecast_coverage_code_FQ"],
                            "IN": label_dict["forecast_coverage_code_IN"],
                            "IS": label_dict["forecast_coverage_code_IS"],
                            "L": label_dict["forecast_coverage_code_L"],
                            "NM": label_dict["forecast_coverage_code_NM"],
                            "O": label_dict["forecast_coverage_code_O"],
                            "PA": label_dict["forecast_coverage_code_PA"],
                            "PD": label_dict["forecast_coverage_code_PD"],
                            "S": label_dict["forecast_coverage_code_S"],
                            "SC": label_dict["forecast_coverage_code_SC"],
                            "VC": label_dict["forecast_coverage_code_VC"],
                            "WD": label_dict["forecast_coverage_code_WD"],
                        }

                        intensity_dict = {
                            "VL": label_dict["forecast_intensity_code_VL"],
                            "L": label_dict["forecast_intensity_code_L"],
                            "H": label_dict["forecast_intensity_code_H"],
                            "VH": label_dict["forecast_intensity_code_VH"],
                        }

                        weather_dict = {
                            "A": label_dict["forecast_weather_code_A"],
                            "BD": label_dict["forecast_weather_code_BD"],
                            "BN": label_dict["forecast_weather_code_BN"],
                            "BR": label_dict["forecast_weather_code_BR"],
                            "BS": label_dict["forecast_weather_code_BS"],
                            "BY": label_dict["forecast_weather_code_BY"],
                            "F": label_dict["forecast_weather_code_F"],
                            "FR": label_dict["forecast_weather_code_FR"],
                            "H": label_dict["forecast_weather_code_H"],
                            "IC": label_dict["forecast_weather_code_IC"],
                            "IF": label_dict["forecast_weather_code_IF"],
                            "IP": label_dict["forecast_weather_code_IP"],
                            "K": label_dict["forecast_weather_code_K"],
                            "L": label_dict["forecast_weather_code_L"],
                            "R": label_dict["forecast_weather_code_R"],
                            "RW": label_dict["forecast_weather_code_RW"],
                            "RS": label_dict["forecast_weather_code_RS"],
                            "SI": label_dict["forecast_weather_code_SI"],
                            "WM": label_dict["forecast_weather_code_WM"],
                            "S": label_dict["forecast_weather_code_S"],
                            "SW": label_dict["forecast_weather_code_SW"],
                            "T": label_dict["forecast_weather_code_T"],
                            "UP": label_dict["forecast_weather_code_UP"],
                            "VA": label_dict["forecast_weather_code_VA"],
                            "WP": label_dict["forecast_weather_code_WP"],
                            "ZF": label_dict["forecast_weather_code_ZF"],
                            "ZL": label_dict["forecast_weather_code_ZL"],
                            "ZR": label_dict["forecast_weather_code_ZR"],
                            "ZY": label_dict["forecast_weather_code_ZY"],
                        }

                        # Check if the weather_code is in the cloud_dict and use that
                        # if it's there. If not then it's a combined weather code.
                        if weather_code in cloud_dict:
                            return cloud_dict[weather_code]

                        # Add the coverage if it's present, and full observation
                        # forecast is requested
                        if coverage_code:
                            output += coverage_dict[coverage_code] + " "
                        # Add the intensity if it's present
                        if intensity_code:
                            output += intensity_dict[intensity_code] + " "
                        # Weather output
                        output += weather_dict[weather_code]
                        return output

                    def xweather_icon(data):
                        """Get the Aeris/Xweather icon description from the icon list."""
                        # https://www.xweather.com/docs/weather-api/reference/icon-list
                        iconlist_file_path = os.path.join(
                            config_dict["WEEWX_ROOT"],
                            skin_dict["SKIN_ROOT"],
                            skin_dict.get("skin", ""),
                            "images/aeris-icon-list.json",
                        )
                        if os.path.exists(iconlist_file_path):
                            icon_name = data.split(".")[0]  # Remove .png
                            with open(iconlist_file_path, "r") as dict:
                                icon_dict = json.load(dict)
                            return icon_dict[icon_name]
                        else:
                            log.error(
                                f"aeris-icon-list.json is missing in {iconlist_file_path}"
                            )
                            return "unknown"

                    current_conditions = extras_dict["current_conditions"]
                    if current_conditions == "obs":
                        if belchertown_debug > 0:
                            log.info(
                                "Current conditions based on /observations endpoint"
                            )
                    elif current_conditions == "conds":
                        if belchertown_debug > 0:
                            log.info("Current conditions based on /conditions endpoint")
                    elif current_conditions == "obs-on-fail-conds":
                        if belchertown_debug > 0:
                            log.info(
                                "Current conditions based on /observations, if no data, use /conditions endpoint"
                            )
                    else:  # W0t?
                        log.info(
                            f"Setting current_conditions to obs due to unknown value: {current_conditions}"
                        )
                        current_conditions = "obs"

                    if (
                        extras_dict["forecast_aeris_use_metar"] == "1"
                    ):  # filter on METAR
                        current_obs_url = f"https://data.api.xweather.com/observations/{forecast_place}?format=json&filter=metar&limit=1&client_id={forecast_api_id}&client_secret={forecast_api_secret}"
                    else:  # filter on All stations
                        current_obs_url = f"https://data.api.xweather.com/observations/{forecast_place}?format=json&filter=allstations&limit=1&client_id={forecast_api_id}&client_secret={forecast_api_secret}"

                    current_conds_url = f"https://data.api.xweather.com/conditions/{forecast_place}?format=json&plimit=1&filter=1min&client_id={forecast_api_id}&client_secret={forecast_api_secret}"
                    forecast_24hr_url = f"https://data.api.xweather.com/forecasts/{forecast_place}?format=json&filter=day&limit=7&client_id={forecast_api_id}&client_secret={forecast_api_secret}"
                    forecast_3hr_url = f"https://data.api.xweather.com/forecasts/{forecast_place}?format=json&filter=3hr&limit=8&client_id={forecast_api_id}&client_secret={forecast_api_secret}"
                    forecast_1hr_url = f"https://data.api.xweather.com/forecasts/{forecast_place}?format=json&filter=1hr&limit=16&client_id={forecast_api_id}&client_secret={forecast_api_secret}"
                    aqi_url = f"https://data.api.xweather.com/airquality/{forecast_place}?format=json&client_id={forecast_api_id}&client_secret={forecast_api_secret}"

                    if extras_dict["forecast_alert_limit"]:
                        forecast_alert_limit = extras_dict["forecast_alert_limit"]
                    else:  # Default to 1 alerts to show if the option is missing. Can go up to 10
                        forecast_alert_limit = 1

                    forecast_alerts_url = f"https://data.api.xweather.com/alerts/{forecast_place}?format=json&limit={forecast_alert_limit}&lang={forecast_lang}&client_id={forecast_api_id}&client_secret={forecast_api_secret}"

                    # File is stale, download a new copy
                    if forecast_is_stale:
                        try:
                            if "forecast_dev_file" in extras_dict:
                                # Hidden option to use a pre-downloaded forecast file
                                # rather than using API calls for no reason
                                dev_forecast_file = extras_dict["forecast_dev_file"]
                                req = Request(dev_forecast_file, None, headers)
                                with urlopen(
                                    req, timeout=DEFAULT_HTTP_TIMEOUT
                                ) as response:
                                    forecast_file_result = response.read()
                            else:
                                # 24hr forecast (was Forecast)
                                req = Request(
                                    forecast_24hr_url,
                                    None,
                                    HTTP_HEADERS["AERIS_WEATHER"],
                                )
                                with urlopen(
                                    req, timeout=DEFAULT_HTTP_TIMEOUT
                                ) as response:
                                    forecast_24hr_page = response.read()
                                if belchertown_debug > 1:
                                    log.info(f"Forecast 24hr URL: {forecast_24hr_url}")
                                # 3hr forecast
                                req = Request(
                                    forecast_3hr_url,
                                    None,
                                    HTTP_HEADERS["AERIS_WEATHER"],
                                )
                                with urlopen(
                                    req, timeout=DEFAULT_HTTP_TIMEOUT
                                ) as response:
                                    forecast_3hr_page = response.read()
                                if belchertown_debug > 1:
                                    log.info(f"Forecast 3hr URL: {forecast_3hr_url}")
                                # 1hr forecast
                                req = Request(
                                    forecast_1hr_url,
                                    None,
                                    HTTP_HEADERS["AERIS_WEATHER"],
                                )
                                with urlopen(
                                    req, timeout=DEFAULT_HTTP_TIMEOUT
                                ) as response:
                                    forecast_1hr_page = response.read()
                                if belchertown_debug > 1:
                                    log.info(f"Forecast 1hr URL: {forecast_1hr_url}")
                                # AQI
                                req = Request(
                                    aqi_url, None, HTTP_HEADERS["AERIS_WEATHER"]
                                )
                                with urlopen(
                                    req, timeout=DEFAULT_HTTP_TIMEOUT
                                ) as response:
                                    aqi_page = response.read()
                                if belchertown_debug > 1:
                                    log.info(f"AQI URL: {aqi_url}")
                                if extras_dict["forecast_alert_enabled"] == "1":
                                    # Alerts
                                    req = Request(
                                        forecast_alerts_url,
                                        None,
                                        HTTP_HEADERS["AERIS_WEATHER"],
                                    )
                                    with urlopen(
                                        req, timeout=DEFAULT_HTTP_TIMEOUT
                                    ) as response:
                                        alerts_page = response.read()
                                    if belchertown_debug > 1:
                                        log.info(f"Alerts URL: {forecast_alerts_url}")

                                # Combine all into 1 file - simplified parsing helper

                                data = {
                                    "timestamp": int(time.time()),
                                    "forecast_24hr": [
                                        _parse_aeris_json(forecast_24hr_page)
                                    ],
                                    "forecast_3hr": [
                                        _parse_aeris_json(forecast_3hr_page)
                                    ],
                                    "forecast_1hr": [
                                        _parse_aeris_json(forecast_1hr_page)
                                    ],
                                    "aqi": [_parse_aeris_json(aqi_page)],
                                }
                                if extras_dict.get("forecast_alert_enabled") == "1":
                                    data["alerts"] = [_parse_aeris_json(alerts_page)]
                                forecast_file_result = json.dumps(data)
                        except Exception as e:
                            log.error(f"Error downloading forecast data: {e}")

                        # Save forecast data to file. w+ creates the file if it doesn't
                        # exist, and truncates the file and re-writes it everytime
                        try:
                            with open(forecast_file, "wb+") as file:
                                file.write(forecast_file_result.encode("utf-8"))
                                log.info(
                                    f"New forecast file downloaded to {forecast_file}"
                                )
                        except FileNotFoundError:
                            log.info(
                                "Belchertown JSON folder does not exist. Usually this "
                                "is an error that only occurs on the first run. If it "
                                "is appearing repeatedly, check file permissions."
                            )
                        except IOError as e:
                            log.error(
                                f"Error writing forecast info to {forecast_file}. Reason: {e}"
                            )

                    # File is stale, download a new copy
                    if current_conditions_is_stale:
                        try:
                            if "current_conditions_dev_file" in extras_dict:
                                # Hidden option to use a pre-downloaded forecast file
                                # rather than using API calls for no reason
                                dev_forecast_file = extras_dict[
                                    "current_conditions_dev_file"
                                ]
                                req = Request(
                                    dev_forecast_file,
                                    None,
                                    HTTP_HEADERS["AERIS_WEATHER"],
                                )
                                with urlopen(
                                    req, timeout=DEFAULT_HTTP_TIMEOUT
                                ) as response:
                                    forecast_file_result = response.read()
                            else:
                                # Current conditions
                                if current_conditions == "obs":
                                    req = Request(
                                        current_obs_url,
                                        None,
                                        HTTP_HEADERS["AERIS_WEATHER"],
                                    )
                                    with urlopen(
                                        req, timeout=DEFAULT_HTTP_TIMEOUT
                                    ) as response:
                                        current_page = response.read()
                                    if belchertown_debug > 1:
                                        log.info(f"Obs URL: {current_obs_url}")
                                elif current_conditions == "conds":
                                    req = Request(
                                        current_conds_url,
                                        None,
                                        HTTP_HEADERS["AERIS_WEATHER"],
                                    )
                                    with urlopen(
                                        req, timeout=DEFAULT_HTTP_TIMEOUT
                                    ) as response:
                                        current_page = response.read()
                                    if belchertown_debug > 1:
                                        log.info(f"Conditions URL: {current_conds_url}")
                                else:  # current_conditions == "obs-on-fail-conds":
                                    req = Request(
                                        current_obs_url,
                                        None,
                                        HTTP_HEADERS["AERIS_WEATHER"],
                                    )
                                    with urlopen(
                                        req, timeout=DEFAULT_HTTP_TIMEOUT
                                    ) as response:
                                        current_page = response.read()
                                    try:  # Obs okay?
                                        current_conditions_data = data["current"][0][
                                            "response"
                                        ]["ob"]
                                    except Exception:  # Nope, try Conds
                                        if belchertown_debug > 0:
                                            log.info("No good Obs data, using Conds")
                                        req = Request(
                                            current_conds_url,
                                            None,
                                            HTTP_HEADERS["AERIS_WEATHER"],
                                        )
                                        with urlopen(
                                            req, timeout=DEFAULT_HTTP_TIMEOUT
                                        ) as response:
                                            current_page = response.read()
                                # Stash in a file
                                data = {
                                    "timestamp": int(time.time()),
                                    "current": [_parse_aeris_json(current_page)],
                                }
                                forecast_file_result = json.dumps(data)
                        except Exception as e:
                            if current_conditions == "obs":
                                log.error(
                                    "Error downloading forecast Current Conditions data. "
                                    "Check the URL in your configuration and try again. "
                                    f"You are trying to use URL: {current_obs_url}, "
                                    f"and the error is: {e}"
                                )
                            elif current_conditions == "conds":
                                log.error(
                                    "Error downloading forecast Current Conditions data. "
                                    "Check the URL in your configuration and try again. "
                                    f"You are trying to use URL: {current_conds_url}, "
                                    f"and the error is: {e}"
                                )
                            elif current_conditions == "obs-on-fail-conds":
                                log.error(
                                    "Error downloading forecast Current Conditions data. "
                                    "Check the URL in your configuration and try again. "
                                    f"You are trying to use URL: {current_conds_url}, "
                                    f"and the error is: {e}"
                                )

                        # Save forecast Current Conditions data to file. w+ creates the file if it doesn't
                        # exist, and truncates the file and re-writes it everytime
                        try:
                            with open(current_conditions_file, "wb+") as file:
                                file.write(forecast_file_result.encode("utf-8"))
                                log.info(
                                    f"New forecast Current Conditions file downloaded to {current_conditions_file}"
                                )
                        except FileNotFoundError:
                            log.info(
                                "Belchertown JSON folder does not exist. Usually this "
                                "is an error that only occurs on the first run. If it "
                                "is appearing repeatedly, check file permissions."
                            )
                        except IOError as e:
                            log.error(
                                "Error writing forecast Current Conditions info to "
                                f"{current_conditions_file}. Reason: {e}"
                            )
                        except Exception as e:
                            log.error(f"Current Conditions error: {e}")

                    # Read the forecast Current Conditions file
                    with open(current_conditions_file, "r") as read_file:
                        data = json.load(read_file)

                    # We prefer using an observation (actual) over conditions (an interpolation)
                    try:
                        if current_conditions == "obs":
                            current_conditions_data_len = len(
                                data["current"][0]["response"]
                            )
                            current_conditions_data = data["current"][0]["response"][
                                "ob"
                            ]
                        elif current_conditions == "conds":
                            current_conditions_data_len = len(
                                data["current"][0]["response"]
                            )
                            current_conditions_data = data["current"][0]["response"][0][
                                "periods"
                            ][0]
                        else:  # current_conditions == "obs-on-fail-conds"
                            try:  # Obs
                                current_conditions_data_len = len(
                                    data["current"][0]["response"]
                                )
                                current_conditions_data = data["current"][0][
                                    "response"
                                ]["ob"]
                            except Exception:  # Conds
                                if belchertown_debug > 0:
                                    log.info("No good Obs data, using Conds")
                                current_conditions_data_len = len(
                                    data["current"][0]["response"]
                                )
                                current_conditions_data = data["current"][0][
                                    "response"
                                ][0]["periods"][0]
                        cloud_cover = f"""{current_conditions_data["sky"]}"""
                    except Exception:
                        log.info("No cloud cover data from Xweather weather")
                        cloud_cover = ""
                        current_conditions_data_len = (
                            0  # Not really but good enough for our Use Case below
                        )

                    # Process the forecast file and the Current Conditions data
                    with open(forecast_file, "r") as read_file:
                        data = json.load(read_file)

                    try:
                        if data["aqi"][0]["response"]:
                            if data["aqi"][0]["error"]:
                                log.error(
                                    f"""Error getting AQI from Xweather weather. The error was: {data["aqi"]}"""
                                )
                            else:
                                aqi = data["aqi"][0]["response"][0]["periods"][0]["aqi"]
                                aqi_category = data["aqi"][0]["response"][0]["periods"][
                                    0
                                ]["category"]
                                aqi_location = data["aqi"][0]["response"][0]["place"][
                                    "name"
                                ].title()
                                aqi_time = data["aqi"][0]["response"][0]["periods"][0][
                                    "timestamp"
                                ]
                    except Exception as e:
                        log.error(
                            f"Error getting AQI from Xweather weather. The error was: {e}. Data: {data['aqi']}"
                        )
                        pass

                    # https://www.xweather.com/docs/weather-api/endpoints/airquality
                    if aqi_category == "good":
                        aqi_category = label_dict["aqi_good"]
                    elif aqi_category == "moderate":
                        aqi_category = label_dict["aqi_moderate"]
                    elif aqi_category == "usg":
                        aqi_category = label_dict["aqi_usg"]
                    elif aqi_category == "unhealthy":
                        aqi_category = label_dict["aqi_unhealthy"]
                    elif aqi_category == "very unhealthy":
                        aqi_category = label_dict["aqi_very_unhealthy"]
                    elif aqi_category == "hazardous":
                        aqi_category = label_dict["aqi_hazardous"]
                    else:
                        aqi_category = label_dict["aqi_unknown"]

                    # For forecasts/ endpoint and METAR != 0, no visibilty seems to be available
                    # (used Los Angeles as test case)
                    if current_conditions_data_len > 0:
                        current_obs_summary = xweather_coded_weather(
                            current_conditions_data["weatherPrimaryCoded"]
                        )
                        current_obs_icon = (
                            xweather_icon(current_conditions_data["icon"]) + ".png"
                        )

                        if forecast_units in ("si", "ca"):
                            if current_conditions_data["visibilityKM"] is not None:
                                visibility = locale.format_string(
                                    "%g",
                                    current_conditions_data["visibilityKM"],
                                )
                                visibility_unit = "km"
                            else:
                                visibility = "N/A"
                                visibility_unit = ""
                        else:
                            # us, uk2 and default to miles per hour
                            if current_conditions_data["visibilityMI"] is not None:
                                visibility = locale.format_string(
                                    "%g",
                                    float(current_conditions_data["visibilityMI"]),
                                )
                                visibility_unit = "miles"
                            else:
                                visibility = "N/A"
                                visibility_unit = ""
                    else:
                        # If there's no data in the ob array then it's probably because of an error.
                        # Example:
                        # "code": "warn_no_data",
                        # "description": "Valid request. No results available based on
                        # your query parameters."
                        current_obs_summary = ""
                        current_obs_icon = ""
                        visibility = "N/A"
                        visibility_unit = ""
            else:
                current_obs_icon = ""
                current_obs_summary = ""
                visibility = "N/A"
                visibility_unit = ""
                cloud_cover = ""
        except Exception as e:
            current_obs_icon = ""
            current_obs_summary = ""
            visibility = "N/A"
            visibility_unit = ""
            cloud_cover = ""
            (
                log.error(f"Pirate Weather error: {e}")
                if forecast_provider == "pirateweather"
                else log.error(f"Aeris/Xweather error: {e}")
            )

        # ==============================================================================
        # Earthquake Data
        # ==============================================================================

        # Only process if Earthquake data is enabled
        if extras_dict["earthquake_enabled"] == "1":
            earthquake_file = html_root + "/json/earthquake.json"
            earthquake_stale_timer = extras_dict["earthquake_stale"]
            latitude = config_dict["Station"]["latitude"]
            longitude = config_dict["Station"]["longitude"]
            distance_unit = self.generator.converter.group_unit_dict["group_distance"]
            eq_distance_label = skin_dict["Units"]["Labels"].get(distance_unit, "")
            eq_distance_round = skin_dict["Units"]["StringFormats"].get(
                distance_unit, "%.1f"
            )
            earthquake_maxradiuskm = extras_dict["earthquake_maxradiuskm"]
            # Sample URL from Belchertown Weather:
            # http://earthquake.usgs.gov/fdsnws/event/1/query?limit=1&lat=42.223&lon=-72.374&maxradiuskm=1000&format=geojson&nodata=204&minmag=2
            if extras_dict["earthquake_server"] == "USGS":
                earthquake_url = f"http://earthquake.usgs.gov/fdsnws/event/1/query?limit=1&lat={latitude}&lon={longitude}&maxradiuskm={earthquake_maxradiuskm}&format=geojson&nodata=204&minmag=2"
            elif extras_dict["earthquake_server"] == "GeoNet":
                earthquake_url = f"""https://api.geonet.org.nz/quake?MMI={extras_dict["geonet_mmi"]}"""
            elif extras_dict["earthquake_server"] == "ReNaSS":
                # Calculate min/max latitude and min/max longitude from radius and station location. https://stackoverflow.com/a/23118314
                lat = float(latitude)
                long = float(longitude)
                radiusInKm = int(earthquake_maxradiuskm)

                kmInLongitudeDegree = 111.320 * cos(lat / 180.0 * pi)

                deltaLat = radiusInKm / 111.1
                deltaLong = radiusInKm / kmInLongitudeDegree

                minLat = lat - deltaLat
                maxLat = lat + deltaLat
                minLong = long - deltaLong
                maxLong = long + deltaLong

                earthquake_url = f"https://api.franceseisme.fr/fdsnws/event/1/query?eventtype=earthquake&minmagnitude=2&minlatitude={minLat:.2f}&minlongitude={minLong:.2f}&maxlatitude={maxLat:.2f}&maxlongitude={maxLong:.2f}&format=json&limit=1&orderby=time"

            earthquake_is_stale = False

            # Determine if the file exists and get its modified time
            if os.path.isfile(earthquake_file) and os.stat(earthquake_file).st_size > 0:
                if (int(time.time()) - int(os.path.getmtime(earthquake_file))) > int(
                    earthquake_stale_timer
                ):
                    earthquake_is_stale = True
            else:
                # File doesn't exist or is blank, download a new copy
                earthquake_is_stale = True

            # File is stale, download a new copy
            if earthquake_is_stale:
                # Download new earthquake data
                try:
                    user_agent = "Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_4; en-US) AppleWebKit/534.3 (KHTML, like Gecko) Chrome/6.0.472.63 Safari/534.3"
                    headers = {"User-Agent": user_agent}
                    req = Request(earthquake_url, None, headers)
                    with urlopen(req, timeout=DEFAULT_HTTP_TIMEOUT) as response:
                        page = response.read()
                    if weewx.debug:
                        log.debug(
                            "Downloading earthquake data using urllib2 was successful"
                        )
                except Exception as forecast_error:
                    if weewx.debug:
                        log.debug(
                            f"Error downloading earthquake data with urllib2, reverting to curl and subprocess. "
                            f"Full error: {forecast_error}"
                        )
                    # Nested try - only execute if the urllib2 method fails
                    try:
                        import subprocess

                        command = f'curl -L --silent "{earthquake_url}"'
                        p = subprocess.Popen(
                            command,
                            shell=True,
                            stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT,
                        )
                        page = p.communicate()[0]
                        if weewx.debug:
                            log.debug(
                                "Downloading earthquake data with curl was successful."
                            )
                    except Exception as e:
                        log.error(
                            f"Error downloading earthquake data using urllib2 and subprocess curl. "
                            f"Your software may need to be updated, or the URL is incorrect. "
                            f"You are trying to use URL: {earthquake_url}, and the error is: {e}"
                        )

                # Save earthquake data to file. w+ creates the file if it
                # doesn't exist, and truncates the file and re-writes it
                # everytime
                try:
                    with open(earthquake_file, "wb+") as file:
                        try:
                            file.write(page.encode("utf-8"))
                        except Exception:
                            # Catch errors caused by ASCII characters
                            file.write(page)
                        if weewx.debug:
                            log.debug(f"Earthquake data saved to {earthquake_file}")
                except IOError as e:
                    log.error(
                        f"Error writing earthquake data to {earthquake_file}. Reason: {e}"
                    )

            # Process the earthquake file
            with open(earthquake_file, "r") as read_file:
                try:
                    eqdata = json.load(read_file)
                except Exception:
                    eqdata = ""

            try:
                if extras_dict["earthquake_server"] == "USGS":
                    eqtime = eqdata["features"][0]["properties"]["time"] / 1000
                    equrl = eqdata["features"][0]["properties"]["url"]
                    if distance_unit == "km":
                        eqplace = eqdata["features"][0]["properties"]["place"]
                    else:  # assume miles
                        try:
                            eqmatched = match(
                                "(?P<distance>[0-9]*\\.?[0-9]+) km(?P<rest>.*)$",
                                eqdata["features"][0]["properties"]["place"],
                            )
                            eqdist_km = eqmatched.group("distance")
                            eqdist_miles = round(float(eqdist_km) / 1.609, 1)
                            eqplace = (
                                str(eqdist_miles) + " miles" + eqmatched.group("rest")
                            )
                        except Exception:
                            eqplace = eqdata["features"][0]["properties"]["place"]
                    eqmag = locale.format_string(
                        "%g", float(eqdata["features"][0]["properties"]["mag"])
                    )
                elif extras_dict["earthquake_server"] == "ReNaSS":
                    eqtime = eqdata["features"][0]["properties"]["time"]
                    # convert time to UNIX format
                    eqtime = datetime.datetime.strptime(eqtime, "%Y-%m-%dT%H:%M:%S.%fZ")
                    eqtime = int(
                        (eqtime - datetime.datetime(1970, 1, 1)).total_seconds()
                    )
                    if match("fr_.*", system_locale):
                        equrl = eqdata["features"][0]["properties"]["url"]["fr"]
                        eqplace = eqdata["features"][0]["properties"]["description"][
                            "fr"
                        ]
                    else:
                        equrl = eqdata["features"][0]["properties"]["url"]["en"]
                        eqplace = eqdata["features"][0]["properties"]["description"][
                            "en"
                        ]
                    eqmag = format(eqdata["features"][0]["properties"]["mag"], ".1f")
                elif extras_dict["earthquake_server"] == "GeoNet":
                    eqtime = eqdata["features"][0]["properties"]["time"]
                    # convert time to UNIX format
                    eqtime = datetime.datetime.strptime(eqtime, "%Y-%m-%dT%H:%M:%S.%fZ")
                    eqtime = int(
                        (eqtime - datetime.datetime(1970, 1, 1)).total_seconds()
                    )
                    equrl = (
                        "https://www.geonet.org.nz/earthquake/"
                        + eqdata["features"][0]["properties"]["publicID"]
                    )
                    eqplace = eqdata["features"][0]["properties"]["locality"]
                    eqmag = locale.format_string(
                        "%g",
                        float(
                            round(eqdata["features"][0]["properties"]["magnitude"], 1)
                        ),
                    )
                eqlat = str(
                    round(eqdata["features"][0]["geometry"]["coordinates"][1], 4)
                )
                eqlon = str(
                    round(eqdata["features"][0]["geometry"]["coordinates"][0], 4)
                )
                eqdistance_bearing = self.get_gps_distance(
                    (float(latitude), float(longitude)),
                    (float(eqlat), float(eqlon)),
                    distance_unit,
                )
                eqdistance = locale.format_string(
                    "%g", float(eq_distance_round % eqdistance_bearing[0])
                )
                eqbearing = eqdistance_bearing[1]
                eqbearing_raw = eqdistance_bearing[2]
            except Exception:
                # No earthquake data
                eqtime = label_dict["earthquake_no_data"]
                equrl = ""
                eqplace = ""
                eqmag = ""
                eqlat = ""
                eqlon = ""
                eqdistance = ""
                eqbearing = ""
                eqbearing_raw = ""

        else:
            eqtime = ""
            equrl = ""
            eqplace = ""
            eqmag = ""
            eqlat = ""
            eqlon = ""
            eqdistance = ""
            eqbearing = ""
            eqbearing_raw = ""
            eq_distance_label = ""

        # ==============================================================================
        # Get Current Station Observation Data for the table html
        # ==============================================================================

        station_obs_binding = None
        station_obs_json = OrderedDict()
        station_obs_html = ""
        station_observations = extras_dict["station_observations"]
        # Check if this is a list. If not then we have 1 item, so force it into a list
        if isinstance(station_observations, list) is False:
            station_observations = station_observations.split()
        current_stamp = manager.lastGoodStamp()
        current_record = manager.getRecord(current_stamp)
        current = weewx.tags.CurrentObj(
            db_lookup,
            station_obs_binding,
            current_stamp,
            self.generator.formatter,
            self.generator.converter,
            None,
            current_record,
        )
        for obs in station_observations:
            if "data_binding" in obs:
                station_obs_binding = obs[obs.find("(") + 1 : obs.rfind(")")].split(
                    "="
                )[
                    1
                ]  # Thanks https://stackoverflow.com/a/40811994/1177153
                obs = obs.split("(")[0]
            if station_obs_binding is not None:
                obs_binding_manager = db_binder.get_manager(station_obs_binding)
                current_stamp = obs_binding_manager.lastGoodStamp()
                current_record = obs_binding_manager.getRecord(current_stamp)
                current = weewx.tags.CurrentObj(
                    db_lookup,
                    station_obs_binding,
                    current_stamp,
                    self.generator.formatter,
                    self.generator.converter,
                    None,
                    current_record,
                )

            if obs == "visibility":
                try:
                    obs_output = f"{float(visibility):.2f} {visibility_unit}"
                except Exception:
                    log.error(
                        "Error adding visiblity to station observations table. "
                        "Check that you have forecast data, or remove visibility from your station_observations Extras option."
                    )
            elif obs == "rainWithRainRate":
                # rainWithRainRate Rain shows rain daily sum and rain rate
                obs_binder = weewx.tags.ObservationBinder(
                    "rain",
                    archiveDaySpan(current_stamp),
                    db_lookup,
                    None,
                    "day",
                    self.generator.formatter,
                    self.generator.converter,
                )
                dayRain_sum = getattr(obs_binder, "sum")
                # Need to use dayRain for class name since that is weewx-mqtt
                # payload's name
                obs_rain_output = (
                    f"<span class='dayRain'>{dayRain_sum}</span><!-- AJAX -->"
                )
                obs_rain_output += "&nbsp;<span class='border-left'>&nbsp;</span>"
                obs_rain_output += f"<span class='rainRate'>{getattr(current, 'rainRate')}</span><!-- AJAX -->"

                # Empty field for the JSON "current" output
                obs_output = ""
            elif obs == "cloud_cover":
                obs_output = cloud_cover
            elif obs == "aqi":
                obs_output = aqi
            else:
                # Only call getattr for observations not handled above
                obs_output = getattr(current, obs)
                if "?" in str(obs_output):
                    # Try to catch those invalid observations, like 'uv' needs
                    # to be 'UV'.
                    obs_output = "Invalid observation"

            # Build the json "current" array for weewx_data.json for JavaScript
            if obs not in station_obs_json:
                station_obs_json[obs] = str(obs_output)

            # Build the HTML for the front page
            station_obs_html += "<tr>"
            station_obs_html += (
                f"<td class='station-observations-label'>{label_dict[obs]}</td>"
            )
            station_obs_html += "<td>"
            if obs == "rainWithRainRate":
                # Add special rain + rainRate one liner
                station_obs_html += obs_rain_output
            else:
                station_obs_html += (
                    f"<span class={obs}>{obs_output}</span><!-- AJAX -->"
                )
            if obs in ("barometer", "pressure", "altimeter"):
                # Append the trend arrow to the pressure observation. Need this
                # for non-mqtt pages
                trend = weewx.tags.TrendObj(
                    10800,
                    300,
                    db_lookup,
                    None,
                    current_stamp,
                    self.generator.formatter,
                    self.generator.converter,
                )
                obs_trend = getattr(trend, obs)
                station_obs_html += (
                    ' <span class="pressure-trend">'  # Maintain leading spacing
                )
                if str(obs_trend) == "N/A":
                    pass
                elif "-" in str(obs_trend):
                    station_obs_html += (
                        '<i class="fa fa-arrow-down barometer-down"></i>'
                    )
                else:
                    station_obs_html += '<i class="fa fa-arrow-up barometer-up"></i>'
                station_obs_html += "</span>"  # Close the span
            station_obs_html += "</td>"
            station_obs_html += "</tr>"

        # ==============================================================================
        # Get all observations and their rounding values
        # ==============================================================================

        all_obs_rounding_json = OrderedDict()
        all_obs_unit_labels_json = OrderedDict()
        for obs in sorted(weewx.units.obs_group_dict):
            try:
                # Find the unit from group (like group_temperature = degree_F)
                obs_group = weewx.units.obs_group_dict[obs]
                obs_unit = self.generator.converter.group_unit_dict[obs_group]
            except Exception:
                # Something's wrong. Continue this loop to ignore this group
                # (like group_dust or something non-standard)
                continue
            try:
                # Find the number of decimals to round to based on group name
                obs_round = skin_dict["Units"]["StringFormats"].get(obs_unit, "0")[2]
            except Exception:
                obs_round = skin_dict["Units"]["StringFormats"].get(obs_unit, "0")
            # Add to the rounding array
            if obs not in all_obs_rounding_json:
                all_obs_rounding_json[obs] = str(obs_round)
            # Get the unit's label
            # Add to label array and strip whitespace if possible
            if obs not in all_obs_unit_labels_json:
                obs_unit_label = weewx.units.get_label_string(
                    self.generator.formatter, self.generator.converter, obs
                )
                all_obs_unit_labels_json[obs] = obs_unit_label

            # Special handling items
            if visibility:
                all_obs_rounding_json["visibility"] = "2"
                all_obs_unit_labels_json["visibility"] = visibility_unit
            else:
                all_obs_rounding_json["visibility"] = ""
                all_obs_unit_labels_json["visibility"] = ""

        # ==============================================================================
        # Social Share
        # ==============================================================================

        facebook_enabled = extras_dict["facebook_enabled"]
        twitter_enabled = extras_dict["twitter_enabled"]
        social_share_html = extras_dict["social_share_html"]
        twitter_text = label_dict["twitter_text"]
        twitter_owner = label_dict["twitter_owner"]
        twitter_hashtags = label_dict["twitter_hashtags"]

        if facebook_enabled == "1":
            facebook_html = (
                """
                <div id="fb-root"></div>
                <script>(function(d, s, id) {
                var js, fjs = d.getElementsByTagName(s)[0];
                if (d.getElementById(id)) return;
                js = d.createElement(s); js.id = id;
                js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5";
                fjs.parentNode.insertBefore(js, fjs);
                }(document, 'script', 'facebook-jssdk'));</script>
                <div class="fb-like" data-href="%s" data-width="500px" data-layout="button_count" data-action="like" data-show-faces="false" data-share="true"></div>
            """
                % social_share_html
            )
        else:
            facebook_html = ""

        if twitter_enabled == "1":
            twitter_html = f"""
                <script>
                    !function(d,s,id){{var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){{js=d.createElement(s);js.id=id;js.src=p+'://platform.twitter.com/widgets.js';fjs.parentNode.insertBefore(js,fjs);}}}}(document, 'script', 'twitter-wjs');
                </script>
                <a href="https://twitter.com/share" class="twitter-share-button" data-url="{social_share_html}" data-text="{twitter_text}" data-via="{twitter_owner}" data-hashtags="{twitter_hashtags}">Tweet</a>
            """
        else:
            twitter_html = ""

        # Build the output
        social_html = ""
        if facebook_html != "" or twitter_html != "":
            social_html = '<div class="wx-stn-share">'
            # Facebook first
            if facebook_html != "":
                social_html += facebook_html
            # Add a separator margin if both are enabled
            if facebook_html != "" and twitter_html != "":
                social_html += '<div class="wx-share-sep"></div>'
            # Twitter second
            if twitter_html != "":
                social_html += twitter_html
            social_html += "</div>"

        # ==============================================================================
        # MQTT settings for Kiosk page
        # ==============================================================================

        if extras_dict["mqtt_websockets_host_kiosk"] != "":
            if extras_dict["mqtt_websockets_port_kiosk"] != "":
                mqtt_websockets_port_kiosk = extras_dict["mqtt_websockets_port_kiosk"]
            else:
                mqtt_websockets_port_kiosk = extras_dict["mqtt_websockets_port"]
            if extras_dict["mqtt_websockets_ssl_kiosk"] != "":
                mqtt_websockets_ssl_kiosk = extras_dict["mqtt_websockets_ssl_kiosk"]
            else:
                mqtt_websockets_ssl_kiosk = extras_dict["mqtt_websockets_ssl"]
        else:
            mqtt_websockets_port_kiosk = extras_dict["mqtt_websockets_host"]
            mqtt_websockets_port_kiosk = extras_dict["mqtt_websockets_port"]
            mqtt_websockets_ssl_kiosk = extras_dict["mqtt_websockets_ssl"]

        # Include custom.css if it exists in the HTML_ROOT folder
        custom_css_file = html_root + "/custom.css"
        # Determine if the file exists
        custom_css_exists = os.path.isfile(custom_css_file)

        # Build the search list with the new values
        search_list_extension = {
            "belchertown_version": VERSION,
            "belchertown_debug": belchertown_debug,
            "moment_js_utc_offset": moment_js_utc_offset,
            "moment_js_tz": moment_js_tz,
            "highcharts_timezoneoffset": highcharts_timezoneoffset,
            "system_locale": system_locale,
            "system_locale_js": system_locale_js,
            "locale_encoding": locale_encoding,
            "highcharts_decimal": highcharts_decimal,
            "highcharts_thousands": highcharts_thousands,
            "radar_html": radar_html,
            "radar_html_dark": radar_html_dark,
            "radar_html_kiosk": radar_html_kiosk,
            "archive_interval_ms": archive_interval_ms,
            "ordinate_names": ordinate_names,
            "charts": json.dumps(charts),
            "graphpage_titles": json.dumps(graphpage_titles),
            "graphpage_titles_dict": graphpage_titles,
            "graphpage_content": json.dumps(graphpage_content),
            "graph_page_buttons": graph_page_buttons,
            "alltime": all_stats,
            "year_outTemp_range_max": year_outTemp_range_max,
            "year_outTemp_range_min": year_outTemp_range_min,
            "at_outTemp_range_max": at_outTemp_range_max,
            "at_outTemp_range_min": at_outTemp_range_min,
            "rainiest_day": rainiest_day,
            "at_rainiest_day": at_rainiest_day,
            "year_rainiest_month": year_rainiest_month,
            "at_rainiest_month": at_rainiest_month,
            "at_rain_highest_year": at_rain_highest_year,
            "year_days_with_rain": year_days_with_rain,
            "year_days_without_rain": year_days_without_rain,
            "at_days_with_rain": at_days_with_rain,
            "at_days_without_rain": at_days_without_rain,
            "windSpeedUnitLabel": windSpeed_unit_label,
            "noaa_header_html": noaa_header_html,
            "default_noaa_file": default_noaa_file,
            "current_obs_icon": current_obs_icon,
            "current_obs_summary": current_obs_summary,
            "visibility": visibility,
            "visibility_unit": visibility_unit,
            "cloud_cover": cloud_cover,
            "station_obs_json": json.dumps(station_obs_json),
            "station_obs_html": station_obs_html,
            "all_obs_rounding_json": json.dumps(all_obs_rounding_json),
            "all_obs_unit_labels_json": json.dumps(all_obs_unit_labels_json),
            "earthquake_time": eqtime,
            "earthquake_url": equrl,
            "earthquake_place": eqplace,
            "earthquake_magnitude": eqmag,
            "earthquake_lat": eqlat,
            "earthquake_lon": eqlon,
            "earthquake_distance_away": eqdistance,
            "earthquake_distance_label": eq_distance_label,
            "earthquake_bearing": eqbearing,
            "earthquake_bearing_raw": eqbearing_raw,
            "social_html": social_html,
            "custom_css_exists": custom_css_exists,
            "aqi": aqi,
            "aqi_category": aqi_category,
            "aqi_location": aqi_location,
            "aqi_time": aqi_time,
            "beaufort0": label_dict["beaufort0"],
            "beaufort1": label_dict["beaufort1"],
            "beaufort2": label_dict["beaufort2"],
            "beaufort3": label_dict["beaufort3"],
            "beaufort4": label_dict["beaufort4"],
            "beaufort5": label_dict["beaufort5"],
            "beaufort6": label_dict["beaufort6"],
            "beaufort7": label_dict["beaufort7"],
            "beaufort8": label_dict["beaufort8"],
            "beaufort9": label_dict["beaufort9"],
            "beaufort10": label_dict["beaufort10"],
            "beaufort11": label_dict["beaufort11"],
            "beaufort12": label_dict["beaufort12"],
            "mqtt_websockets_port_kiosk": mqtt_websockets_port_kiosk,
            "mqtt_websockets_ssl_kiosk": mqtt_websockets_ssl_kiosk,
        }
        # Finally, return our extension as a list:
        return [search_list_extension]


# ======================================================================================
# HighchartsJsonGenerator
# ======================================================================================


class HighchartsJsonGenerator(weewx.reportengine.ReportGenerator):
    """Class for generating JSON files for the Highcharts.
    Adapted from the ImageGenerator class.

    Useful attributes (some inherited from ReportGenerator):

        config_dict:      The WeeWX configuration dictionary
        skin_dict:        The dictionary for this skin
        gen_ts:           The generation time
        first_run:        Is this the first time the generator has been run?
        stn_info:         An instance of weewx.station.StationInfo
        record:           A copy of the "current" record. May be None.
        formatter:        An instance of weewx.units.Formatter
        converter:        An instance of weewx.units.Converter
        search_list_objs: A list holding search list extensions
        db_binder:        An instance of weewx.manager.DBBinder from which the data should be extracted
    """

    def run(self):
        """Main entry point for file generation."""

        chart_config_path = os.path.join(
            self.config_dict["WEEWX_ROOT"],
            self.skin_dict["SKIN_ROOT"],
            self.skin_dict.get("skin", ""),
            "graphs.conf",
        )
        default_chart_config_path = os.path.join(
            self.config_dict["WEEWX_ROOT"],
            self.skin_dict["SKIN_ROOT"],
            self.skin_dict.get("skin", ""),
            "graphs.conf.example",
        )
        if os.path.exists(chart_config_path):
            self.chart_dict = configobj.ConfigObj(chart_config_path, file_error=True)
        else:
            self.chart_dict = configobj.ConfigObj(
                default_chart_config_path, file_error=True
            )

        self.converter = weewx.units.Converter.fromSkinDict(self.skin_dict)
        self.formatter = weewx.units.Formatter.fromSkinDict(self.skin_dict)

        # Setup title dict for plot titles
        try:
            d = self.skin_dict["Labels"]["Generic"]
        except KeyError:
            d = {}
        label_dict = weeutil.weeutil.KeyDict(d)

        # Final output dict
        output = {}

        # Loop through each [section]. This is the first bracket group of
        # options including global options.
        for chart_group in self.chart_dict.sections:
            output[chart_group] = (
                OrderedDict()
            )  # This retains the order in which to load the charts on the page.
            chart_options = accumulateLeaves(self.chart_dict[chart_group])

            output[chart_group]["belchertown_version"] = VERSION
            output[chart_group]["generated_timestamp"] = time.strftime(
                "%m/%d/%Y %H:%M:%S"
            )

            # Setup the JSON file name for each chart group
            html_dest_dir = os.path.join(
                self.config_dict["WEEWX_ROOT"], self.skin_dict["HTML_ROOT"], "json"
            )
            json_filename = html_dest_dir + "/" + chart_group + ".json"

            # Default back to Highcharts standards
            colors = chart_options.get(
                "colors",
                "#7cb5ec, #b2df8a, #f7a35c, #8c6bb1, #dd3497, #e4d354, #268bd2, #f45b5b, #6a3d9a, #33a02c",
            )
            output[chart_group]["colors"] = colors

            # chartgroup_title is used on the graphs page
            chartgroup_title = chart_options.get("title", None)
            if chartgroup_title:
                output[chart_group]["chartgroup_title"] = chartgroup_title

            # Define the default tooltip datetime format from the global options
            tooltip_date_format = chart_options.get("tooltip_date_format", "LLLL")
            output[chart_group]["tooltip_date_format"] = tooltip_date_format

            # Credits Text
            credits = chart_options.get("credits", "highcharts_default")
            output[chart_group]["credits"] = credits

            # Credits URL
            credits_url = chart_options.get("credits_url", "highcharts_default")
            output[chart_group]["credits_url"] = credits_url

            # Credits position
            credits_position = chart_options.get(
                "credits_position", "highcharts_default"
            )
            output[chart_group]["credits_position"] = credits_position

            # Check if there are any user override on generation periods.
            # Takes the crontab approach. If the words hourly, daily, monthly,
            # yearly are present use them, otherwise use an integer interval if
            # available.  Since WeeWX could be restarted, we'll lose our
            # end-timestamp to trigger off of for chart staleness.  So we have
            # to use the timestamp of the file to generate this. If the file
            # does not exist, we need to create it first.  Once created we use
            # that to see if we need to generate a fresh data set for the
            # chart.
            generate = chart_options.get("generate", None)
            if generate is not None:
                # Default to not making a new chart
                create_new_chart = False

                # Get our intervals. Minus 60 seconds so that it'll run a
                # little more reliably on the next interval.
                if generate.lower() == "hourly":
                    chart_stale_timer = 3540
                elif generate.lower() == "daily":
                    chart_stale_timer = 86340
                elif generate.lower() == "weekly":
                    chart_stale_timer = 604740
                elif generate.lower() == "monthly":
                    chart_stale_timer = 2629686
                elif generate.lower() == "yearly":
                    chart_stale_timer = 31556892
                else:
                    chart_stale_timer = int(generate)

                if not os.path.isfile(json_filename):
                    # File doesn't exist. Chart is stale no matter what.
                    create_new_chart = True
                else:
                    # The file exists get timestamp to compare against what the
                    # user wants for an interval
                    if (int(time.time()) - int(os.path.getmtime(json_filename))) >= int(
                        chart_stale_timer
                    ):
                        create_new_chart = True

                # Chart isn't stale, so continue to next chart (this current
                # chart_group is skipped and not generated)
                if not create_new_chart:
                    continue

            # Loop through each [[chart_group]] within the section.
            for plotname in self.chart_dict[chart_group].sections:
                output[chart_group][plotname] = {}

                # This retains the observation position in the dictionary to
                # match the order in the conf so the chart is in the right
                # user-defined order
                output[chart_group][plotname]["series"] = OrderedDict()

                output[chart_group][plotname]["options"] = {}
                # output[chart_group][plotname]["options"]["renderTo"] = chart_group + plotname # daychart1, weekchart1, etc.
                # Used for the graphs page and the different chart_groups
                output[chart_group][plotname]["options"][
                    "renderTo"
                ] = plotname  # daychart1, weekchart1, etc. Used for the graphs page and the different chart_groups
                output[chart_group][plotname]["options"]["chart_group"] = chart_group

                plot_options = accumulateLeaves(self.chart_dict[chart_group][plotname])

                # Setup the database binding, default to weewx.conf's binding
                # if none supplied.
                binding = plot_options.get(
                    "data_binding",
                    self.config_dict["StdReport"].get("data_binding", "wx_binding"),
                )
                archive = self.db_binder.get_manager(binding)

                # Generate timespan for the string time windows
                start_ts = archive.firstGoodStamp()
                stop_ts = archive.lastGoodStamp()
                timespan = weeutil.weeutil.TimeSpan(start_ts, stop_ts)

                # Find timestamps for the rolling window
                plotgen_ts = self.gen_ts
                if not plotgen_ts:
                    plotgen_ts = stop_ts
                    if not plotgen_ts:
                        plotgen_ts = time.time()

                chart_title = plot_options.get("title", "")
                output[chart_group][plotname]["options"]["title"] = chart_title

                chart_subtitle = plot_options.get("subtitle", "")
                output[chart_group][plotname]["options"]["subtitle"] = chart_subtitle

                # Get the type of plot ("bar', 'line', 'spline', or 'scatter')
                plottype = plot_options.get("type", "line")
                output[chart_group][plotname]["options"]["type"] = plottype

                # gapsize has to be in milliseconds. Take the graphs.conf value
                # and multiply by 1000
                gapsize = plot_options.get(
                    "gapsize", 300
                )  # Default to 5 minutes in millis
                if gapsize:
                    output[chart_group][plotname]["options"]["gapsize"] = (
                        int(gapsize) * 1000
                    )

                connectNulls = plot_options.get("connectNulls", "false")
                output[chart_group][plotname]["options"]["connectNulls"] = connectNulls

                xAxis_groupby = plot_options.get("xAxis_groupby", None)
                xAxis_categories = plot_options.get("xAxis_categories", "")
                # Check if this is a list. If not then we have 1 item, so force
                # it into a list
                if isinstance(xAxis_categories, list) is False:
                    xAxis_categories = xAxis_categories.split()
                output[chart_group][plotname]["options"][
                    "xAxis_categories"
                ] = xAxis_categories

                # Grab any per-chart tooltip date format overrides
                plot_tooltip_date_format = plot_options.get("tooltip_date_format", None)
                output[chart_group][plotname]["options"][
                    "plot_tooltip_date_format"
                ] = plot_tooltip_date_format

                # Width and height specific CSS overrides
                output[chart_group][plotname]["options"]["css_width"] = (
                    plot_options.get("width", "")
                )
                output[chart_group][plotname]["options"]["css_height"] = (
                    plot_options.get("height", "")
                )

                # Setup legend option
                legend = plot_options.get("legend", None)
                if legend is None:
                    # Default to true if the option is missing
                    output[chart_group][plotname]["options"]["legend"] = "true"
                else:
                    output[chart_group][plotname]["options"]["legend"] = legend

                # Setup exporting option
                exporting = plot_options.get("exporting", None)
                if exporting is not None and to_bool(exporting):
                    # Only turn on exporting if it's not none and it's true (1 or True)
                    output[chart_group][plotname]["options"]["exporting"] = "true"
                else:
                    output[chart_group][plotname]["options"]["exporting"] = "false"

                # Loop through each [[[observation]]] within the chart_group.
                for line_name in self.chart_dict[chart_group][plotname].sections:
                    output[chart_group][plotname]["series"][line_name] = {}
                    output[chart_group][plotname]["series"][line_name][
                        "obsType"
                    ] = line_name

                    line_options = accumulateLeaves(
                        self.chart_dict[chart_group][plotname][line_name]
                    )

                    # Look for any keyword timespans first and default to those
                    # start/stop times for the chart
                    time_length = line_options.get("time_length", 86400)
                    time_ago = int(line_options.get("time_ago", 1))
                    day_specific = line_options.get(
                        "day_specific", 1
                    )  # Force a day so we don't error out
                    month_specific = line_options.get(
                        "month_specific", 8
                    )  # Force a month so we don't error out
                    year_specific = line_options.get(
                        "year_specific", 2019
                    )  # Force a year so we don't error out
                    start_at_midnight = to_bool(
                        line_options.get("start_at_midnight", False)
                    )  # Should our timespan start at midnight?
                    start_at_whole_hour = to_bool(
                        line_options.get("start_at_whole_hour", False)
                    )  # Should our timespan start at a whole hour?
                    start_at_beginning_of_month = to_bool(
                        line_options.get("start_at_beginning_of_month", False)
                    )  # Should our timespan start at the beginning of a month?
                    if time_length == "today":
                        minstamp, maxstamp = archiveDaySpan(timespan.stop)
                    elif time_length == "week":
                        week_start = to_int(
                            self.config_dict["Station"].get("week_start", 6)
                        )
                        minstamp, maxstamp = archiveWeekSpan(timespan.stop, week_start)
                    elif time_length == "month":
                        minstamp, maxstamp = archiveMonthSpan(timespan.stop)
                    elif time_length == "year":
                        minstamp, maxstamp = archiveYearSpan(timespan.stop)
                    elif time_length == "days_ago":
                        minstamp, maxstamp = archiveDaySpan(
                            timespan.stop, days_ago=time_ago
                        )
                    elif time_length == "weeks_ago":
                        week_start = to_int(
                            self.config_dict["Station"].get("week_start", 6)
                        )
                        minstamp, maxstamp = archiveWeekSpan(
                            timespan.stop, week_start, weeks_ago=time_ago
                        )
                    elif time_length == "months_ago":
                        minstamp, maxstamp = archiveMonthSpan(
                            timespan.stop, months_ago=time_ago
                        )
                    elif time_length == "years_ago":
                        minstamp, maxstamp = archiveYearSpan(
                            timespan.stop, years_ago=time_ago
                        )
                    elif time_length == "day_specific":
                        # Set an arbitrary hour within the specific day to get
                        # that full day timespan and not the day before.
                        # e.g. 1pm
                        day_dt = datetime.datetime.strptime(
                            str(year_specific)
                            + "-"
                            + str(month_specific)
                            + "-"
                            + str(day_specific)
                            + " 13",
                            "%Y-%m-%d %H",
                        )
                        daystamp = int(time.mktime(day_dt.timetuple()))
                        minstamp, maxstamp = archiveDaySpan(daystamp)
                    elif time_length == "month_specific":
                        # Set an arbitrary day within the specific month to get
                        # that full month timespan and not the day before.
                        # e.g. 5th day
                        month_dt = datetime.datetime.strptime(
                            str(year_specific) + "-" + str(month_specific) + "-5",
                            "%Y-%m-%d",
                        )
                        monthstamp = int(time.mktime(month_dt.timetuple()))
                        minstamp, maxstamp = archiveMonthSpan(monthstamp)
                    elif time_length == "year_specific":
                        # Get a date in the middle of the year to get the full
                        # year epoch so WeeWX can find the year timespan.
                        year_dt = datetime.datetime.strptime(
                            str(year_specific) + "-8-1", "%Y-%m-%d"
                        )
                        yearstamp = int(time.mktime(year_dt.timetuple()))
                        minstamp, maxstamp = archiveYearSpan(yearstamp)
                    elif time_length == "year_to_now":
                        minstamp, maxstamp = self.timespan_year_to_now(timespan.stop)
                    elif time_length == "hour_ago_to_now":
                        if start_at_midnight:
                            span_start, span_stop = archiveSpanSpan(
                                timespan.stop, hour_delta=time_ago
                            )
                            minstamp, maxstamp = TimeSpan(
                                startOfDay(span_start), span_stop
                            )
                        else:
                            minstamp, maxstamp = archiveSpanSpan(
                                timespan.stop, hour_delta=time_ago
                            )
                    elif time_length == "day_ago_to_now":
                        if start_at_midnight:
                            span_start, span_stop = archiveSpanSpan(
                                timespan.stop, day_delta=time_ago
                            )
                            minstamp, maxstamp = TimeSpan(
                                startOfDay(span_start), span_stop
                            )
                        else:
                            minstamp, maxstamp = archiveSpanSpan(
                                timespan.stop, day_delta=time_ago
                            )
                    elif time_length == "week_ago_to_now":
                        if start_at_midnight:
                            span_start, span_stop = archiveSpanSpan(
                                timespan.stop, week_delta=time_ago
                            )
                            minstamp, maxstamp = TimeSpan(
                                startOfDay(span_start), span_stop
                            )
                        else:
                            minstamp, maxstamp = archiveSpanSpan(
                                timespan.stop, week_delta=time_ago
                            )
                    elif time_length == "month_ago_to_now":
                        if start_at_midnight:
                            span_start, span_stop = archiveSpanSpan(
                                timespan.stop, month_delta=time_ago
                            )
                            minstamp, maxstamp = TimeSpan(
                                startOfDay(span_start), span_stop
                            )
                        else:
                            minstamp, maxstamp = archiveSpanSpan(
                                timespan.stop, day_delta=time_ago * 31
                            )
                    elif time_length == "year_ago_to_now":
                        if start_at_midnight:
                            span_start, span_stop = archiveSpanSpan(
                                timespan.stop, year_delta=time_ago
                            )
                            minstamp, maxstamp = TimeSpan(
                                startOfDay(span_start), span_stop
                            )
                        else:
                            minstamp, maxstamp = archiveSpanSpan(
                                timespan.stop, day_delta=time_ago * 365
                            )
                    elif time_length == "timestamp_ago_to_now":
                        if start_at_midnight:
                            minstamp, maxstamp = TimeSpan(
                                startOfDay(time_ago), timespan.stop
                            )
                        else:
                            minstamp, maxstamp = TimeSpan(time_ago, timespan.stop)
                    elif time_length == "timespan_specific":
                        minstamp = line_options.get("timespan_start", None)
                        maxstamp = line_options.get("timespan_stop", None)
                        if minstamp is None or maxstamp is None:
                            log.error(
                                "Error trying to create timespan_specific graph. "
                                "You are missing either timespan_start or timespan_stop options."
                            )
                    elif time_length == "all":
                        minstamp = start_ts
                        maxstamp = stop_ts
                    else:
                        # Rolling timespans using seconds

                        # Convert to int() for minstamp math and for
                        # point_timestamp conditional later
                        time_length = int(time_length)

                        # Take the generation time and subtract the time_length
                        # to get our start time
                        if start_at_midnight:
                            span_start = plotgen_ts - time_length
                            minstamp = startOfDay(span_start)
                        else:
                            minstamp = plotgen_ts - time_length
                        maxstamp = plotgen_ts

                    if start_at_whole_hour:
                        minstamp -= minstamp % 3600

                    if start_at_beginning_of_month:
                        start_ts, stop_ts = archiveMonthSpan(minstamp)
                        minstamp = start_ts

                    # Find if this chart is using a new database binding.
                    # Default to the binding set in plot_options
                    binding = line_options.get("data_binding", binding)
                    archive = self.db_binder.get_manager(binding)

                    # Find the observation type if specified (e.g. more than 1
                    # of the same on a chart). (e.g. outTemp, rainFall,
                    # windDir, etc.)
                    observation_type = line_options.get("observation_type", line_name)

                    # If we have a weather range, define what the actual
                    # observation type to lookup in the db is, and to use for
                    # yAxis labels
                    weatherRange_obs_lookup = line_options.get("range_type", None)

                    # Get any custom names for this observation
                    name = line_options.get("name", None)
                    if not name:
                        # No explicit name. Look up a generic one. NB:
                        # label_dict is a KeyDict which will substitute the key
                        # if the value is not in the dictionary.
                        if weatherRange_obs_lookup is not None:
                            name = label_dict[weatherRange_obs_lookup]
                        else:
                            name = label_dict[observation_type]

                    # Look for aggregation type:
                    aggregate_type = line_options.get("aggregate_type")
                    if aggregate_type in (None, "", "None", "none"):
                        # No aggregation specified.
                        aggregate_type = aggregate_interval = None
                    else:
                        try:
                            # Aggregation specified. Get the interval.
                            aggregate_interval = weeutil.weeutil.nominal_spans(
                                line_options.get("aggregate_interval")
                            )
                        except KeyError:
                            log.error(
                                f"HighchartsJsonGenerator: aggregate interval required for aggregate type {aggregate_type}",
                            )
                            log.error(
                                f"HighchartsJsonGenerator: line type {observation_type} skipped",
                            )
                            continue

                    # use different target unit
                    special_target_unit = line_options.get("unit", None)

                    # Get the unit label
                    if observation_type == "rainDurTotal":
                        obs_label = "rainDur"
                    elif observation_type == "hailDurTotal":
                        obs_label = "hailDur"
                    elif observation_type == "sunshineDurTotal":
                        obs_label = "sunshineDur"
                    elif observation_type == "rainTotal":
                        obs_label = "rain"
                    elif (
                        observation_type == "weatherRange"
                        and weatherRange_obs_lookup is not None
                    ):
                        obs_label = weatherRange_obs_lookup
                    else:
                        obs_label = observation_type
                    unit_label = line_options.get(
                        "yAxis_label_unit",
                        self.formatter.get_label_string(
                            special_target_unit
                            if special_target_unit
                            else self.converter.getTargetUnit(
                                obs_label, aggregate_type
                            )[0]
                        ),
                    )

                    # Set the yAxis label. Place into series for custom
                    # JavaScript. Highcharts will ignore these by default
                    yAxisLabel_config = line_options.get("yAxis_label", None)
                    # Set a default yAxis label if graphs.conf yAxis_label is
                    # none and there's a unit_label - e.g. Temperature (F)
                    if yAxisLabel_config is None and unit_label:
                        yAxis_label = name + " (" + unit_label.strip() + ")"
                    elif yAxisLabel_config and unit_label:
                        yAxis_label = (
                            yAxisLabel_config + " (" + unit_label.strip() + ")"
                        )
                    elif yAxisLabel_config:
                        yAxis_label = yAxisLabel_config
                    else:
                        # Unknown observation, set the default label to ""
                        yAxis_label = ""
                    output[chart_group][plotname]["options"][
                        "yAxis_label"
                    ] = yAxis_label
                    output[chart_group][plotname]["series"][line_name][
                        "yAxis_label"
                    ] = yAxis_label

                    # Check for average type:
                    average_type = line_options.get("average_type")
                    if average_type in (None, "", "None", "none"):
                        # No average type specified so force to none.
                        average_type = None

                    # Mirrored charts
                    mirrored_value = line_options.get("mirrored_value", None)

                    # Custom CSS
                    css_class = line_options.get("css_class", None)
                    output[chart_group][plotname]["options"]["css_class"] = css_class

                    # Setup polar charts
                    polar = line_options.get("polar", None)
                    if polar is not None and to_bool(polar):
                        # Only turn on polar if it's not none and it's true (1 or True)
                        output[chart_group][plotname]["series"][line_name][
                            "polar"
                        ] = "true"
                    else:
                        output[chart_group][plotname]["series"][line_name][
                            "polar"
                        ] = "false"

                    # This for loop is to get any user provided highcharts
                    # series config data. Built-in highcharts variable names
                    # accepted.
                    for highcharts_config, highcharts_value in self.chart_dict[
                        chart_group
                    ][plotname][line_name].items():
                        output[chart_group][plotname]["series"][line_name][
                            highcharts_config
                        ] = highcharts_value

                    # Override any highcharts series configs with standardized
                    # data, then generate the data output
                    output[chart_group][plotname]["series"][line_name]["name"] = name

                    # Set the yAxis min and max if present. Useful for the
                    # rxCheckPercent plots
                    yAxis_min = line_options.get("yAxis_min", None)
                    if yAxis_min:
                        output[chart_group][plotname]["series"][line_name][
                            "yAxis_min"
                        ] = yAxis_min
                    yAxis_max = line_options.get("yAxis_max", None)
                    if yAxis_max:
                        output[chart_group][plotname]["series"][line_name][
                            "yAxis_max"
                        ] = yAxis_max

                    # data rounding
                    obs_round = None
                    if (
                        obs_round is None
                        and self.chart_dict[chart_group][plotname][line_name]
                        .get("numberFormat", dict())
                        .get("decimals")
                        is not None
                    ):
                        # The user specified decimals. Use them for rounding,
                        # too.
                        try:
                            obs_round = float(
                                self.chart_dict[chart_group][plotname][line_name][
                                    "numberFormat"
                                ]["decimals"]
                            )
                        except (ValueError, TypeError):
                            log.error(
                                f"""cannot use numberFormat decimals {self.chart_dict[chart_group][plotname][line_name]["numberFormat"]["decimals"]} for rounding"""
                            )
                    if obs_round is None:
                        # Add rounding from weewx.conf/skin.conf so Highcharts can use it
                        if observation_type == "rainDurTotal":
                            rounding_obs_lookup = "rainDur"
                        elif observation_type == "hailDurTotal":
                            rounding_obs_lookup = "hailDur"
                        elif observation_type == "sunshineDurTotal":
                            rounding_obs_lookup = "sunshineDur"
                        elif observation_type == "rainTotal":
                            rounding_obs_lookup = "rain"
                        elif observation_type == "weatherRange":
                            rounding_obs_lookup = weatherRange_obs_lookup
                        elif observation_type == "haysChart":
                            rounding_obs_lookup = "windSpeed"
                        else:
                            rounding_obs_lookup = observation_type
                        try:
                            obs_group = weewx.units.obs_group_dict[rounding_obs_lookup]
                            obs_unit = self.converter.group_unit_dict[obs_group]
                            obs_round = self.skin_dict["Units"]["StringFormats"].get(
                                obs_unit, "0"
                            )[2]
                        except Exception:
                            # Not a valid WeeWX schema name - maybe this is
                            # windRose or something?
                            obs_round = -1
                    output[chart_group][plotname]["series"][line_name][
                        "rounding"
                    ] = obs_round

                    def get_rainbow_color(value, min, max):

                        # If value is off-scale high/low, assign max/min color
                        if value < min:
                            value = min
                        elif value > max:
                            value = max

                        # Using sine waves to generate rainbow colors (see
                        # below). Set the value to range from 8π/7 (blue)
                        # to 3π (purple).
                        i = (value - min) / (max - min) * 5.83 + 3.59

                        # https://krazydad.com/tutorials/makecolors.php
                        # Creating sine waves for red, green, and blue,
                        # and then offsetting by 2π/3 and 4π/3, creates
                        # a loop of rainbow colors. The sine waves are
                        # centered at 255/2 and have an amplitude of
                        # 255/2, so they vary from 0 to 255.
                        n = sin(i) * 127.5 + 127.5
                        red = format(int(n), "x")  # convert to hex
                        n = sin(i + 2.09) * 127.5 + 127.5
                        green = format(int(n), "x")  # convert to hex
                        n = sin(i + 4.19) * 127.5 + 127.5
                        blue = format(int(n), "x")  # convert to hex
                        return "#" + red + green + blue

                    # Set default colors, unless the user has specified
                    # otherwise in graphs.conf
                    wind_rose_color = {}
                    for x in range(7):
                        wind_rose_color[x] = line_options.get(
                            f"beauford{x}", get_rainbow_color(x, 0, 6)
                        )

                    # Build series data
                    series_data = self.get_observation_data(
                        binding,
                        archive,
                        observation_type,
                        minstamp,
                        maxstamp,
                        aggregate_type,
                        aggregate_interval,
                        average_type,
                        time_length,
                        xAxis_groupby,
                        xAxis_categories,
                        mirrored_value,
                        weatherRange_obs_lookup,
                        wind_rose_color,
                        special_target_unit,
                        obs_round,
                    )

                    # Build the final series data JSON
                    if isinstance(series_data, dict):
                        # If the returned type is a dict, then it's from the
                        # xAxis groupby section containing labels. Need to
                        # repack data, and update xAxis_categories.

                        # Use SQL Labels?
                        if "use_sql_labels" in series_data:
                            if series_data["use_sql_labels"]:
                                output[chart_group][plotname]["options"][
                                    "xAxis_categories"
                                ] = series_data["xAxis_groupby_labels"]
                        elif "weatherRange" in series_data:
                            output[chart_group][plotname]["series"][line_name][
                                "range_unit"
                            ] = series_data["range_unit"]
                            output[chart_group][plotname]["series"][line_name][
                                "range_unit_label"
                            ] = series_data["range_unit_label"]

                        # No matter what, reset data back to just the series
                        # data and not a dict of values
                        output[chart_group][plotname]["series"][line_name]["data"] = (
                            list(series_data["obsdata"])
                        )
                    else:
                        # No custom series data overrides, so just add
                        # series_data to the chart series data
                        output[chart_group][plotname]["series"][line_name]["data"] = (
                            list(series_data)
                        )

                    # Final pass through
                    # self.highcharts_series_options_to_float() to convert the
                    # remaining options with numeric values to float such that
                    # Highcharts can make use of them.
                    output[chart_group][plotname]["series"][line_name] = (
                        self.highcharts_series_options_to_float(
                            output[chart_group][plotname]["series"][line_name]
                        )
                    )

            # Write the output to the JSON file
            with open(json_filename, mode="w") as jf:
                jf.write(json.dumps(output[chart_group], indent=4))

            # Save the graphs.conf to a json file for future debugging
            chart_json_filename = html_dest_dir + "/graphs.json"
            with open(chart_json_filename, mode="w") as cjf:
                cjf.write(json.dumps(self.chart_dict, indent=4))

    def get_observation_data(
        self,
        binding,
        archive,
        observation,
        start_ts,
        end_ts,
        aggregate_type,
        aggregate_interval,
        average_type,
        time_length,
        xAxis_groupby,
        xAxis_categories,
        mirrored_value,
        weatherRange_obs_lookup,
        wind_rose_color,
        special_target_unit,
        obs_round,
    ):
        """
        Get the SQL vectors for the observation, the aggregate type and the
        interval of time
        """

        # Cache frequently accessed attributes
        skin_dict = self.skin_dict
        converter = self.converter
        config_dict = self.config_dict

        if observation == "windRose":
            # Special Belchertown wind rose with Highcharts aggregator Wind
            # speeds are split into the first 7 beaufort groups.
            # https://en.wikipedia.org/wiki/Beaufort_scale

            # Force no aggregate_type
            if aggregate_type:
                aggregate_type = None

            # Force no aggregate_interval
            if aggregate_interval:
                aggregate_interval = None

            # Get windDir and windSpeed observations
            timespan = TimeSpan(start_ts, end_ts)

            (time_start_vt, time_stop_vt, windDir_vt) = weewx.xtypes.get_series(
                "windDir",
                timespan,
                archive,
                aggregate_type,
                aggregate_interval,
            )
            # Round to 0 decimal places for wind direction
            windDir_round_vt = [
                round(x) if x is not None else None for x in windDir_vt[0]
            ]

            (time_start_vt, time_stop_vt, windSpeed_vt) = weewx.xtypes.get_series(
                "windSpeed",
                timespan,
                archive,
                aggregate_type,
                aggregate_interval,
            )
            windSpeed_vt = self.converter.convert(windSpeed_vt)
            usage_round = int(
                skin_dict["Units"]["StringFormats"].get(windSpeed_vt[2], "2f")[-2]
            )
            windSpeed_round_vt = [
                round(x, usage_round) if x is not None else None
                for x in windSpeed_vt[0]
            ]

            # Exit if the vectors are None
            if windDir_vt[1] is None or windSpeed_vt[1] is None:
                empty_windrose = [{"name": "", "data": []}]
                return empty_windrose

            # Get the unit label from the skin dict for speed.
            windSpeed_unit = windSpeed_vt[1]
            windSpeed_unit_label = skin_dict["Units"]["Labels"][windSpeed_unit]

            # Initialize wind speed groups more efficiently
            wind_groups = [{"dir": [], "speed": []} for _ in range(7)]

            # Define beaufort scale thresholds for different units (more efficient than nested ifs)
            beaufort_thresholds = {
                ("mile_per_hour", "mile_per_hour2"): [1, 4, 8, 13, 19, 25],
                ("km_per_hour", "km_per_hour2"): [2, 6, 12, 20, 29, 39],
                ("meter_per_second", "meter_per_second2"): [
                    0.5,
                    1.6,
                    3.4,
                    5.6,
                    8,
                    10.8,
                ],
                ("knot", "knot2"): [1, 4, 7, 11, 17, 22],
                "beaufort": [2, 3, 4, 5, 6, 7],
            }

            # Find matching threshold set
            thresholds = None
            for units, thresh in beaufort_thresholds.items():
                if isinstance(units, tuple) and windSpeed_unit in units:
                    thresholds = thresh
                    break
                elif windSpeed_unit == units:
                    thresholds = thresh
                    break

            if thresholds is None:
                thresholds = [1, 4, 8, 13, 19, 25]  # Default to mph

            # Process wind data efficiently
            for windDir, windSpeed in zip(windDir_round_vt, windSpeed_round_vt):
                if windDir is not None and windSpeed is not None:
                    # Determine group index based on thresholds
                    group_idx = 6  # Default to highest group
                    for i, threshold in enumerate(thresholds):
                        if windSpeed < threshold:
                            group_idx = i
                            break

                    wind_groups[group_idx]["dir"].append(windDir)
                    wind_groups[group_idx]["speed"].append(windSpeed)

            # Get the windRose data for all groups
            series_data = [
                self.create_windrose_data(g["dir"], g["speed"]) for g in wind_groups
            ]

            # Calculate wind frequency percentages
            wind_sum = sum(sum(data) for data in series_data)
            if wind_sum > 0:
                series_data = [
                    [round(val / wind_sum * 100) for val in data]
                    for data in series_data
                ]

            # Setup the labels based on unit (using dictionary for efficiency)
            speed_range_labels = {
                ("mile_per_hour", "mile_per_hour2"): [
                    "< 1",
                    "1-3",
                    "4-7",
                    "8-12",
                    "13-18",
                    "19-24",
                    "25+",
                ],
                ("km_per_hour", "km_per_hour2"): [
                    "< 2",
                    "2-5",
                    "6-11",
                    "12-19",
                    "20-28",
                    "29-38",
                    "39+",
                ],
                ("meter_per_second", "meter_per_second2"): [
                    "< 0.5",
                    "0.5-1.5",
                    "1.6-3.3",
                    "3.4-5.5",
                    "5.5-7.9",
                    "8-10.7",
                    "10.8+",
                ],
                ("knot", "knot2"): [
                    "< 1",
                    "1-3",
                    "4-6",
                    "7-10",
                    "11-16",
                    "17-21",
                    "22+",
                ],
                "beaufort": ["0", "1", "2", "3", "4", "5", "6+"],
            }

            # Find matching labels
            labels = None
            for units, lbls in speed_range_labels.items():
                if isinstance(units, tuple) and windSpeed_unit in units:
                    labels = lbls
                    break
                elif windSpeed_unit == units:
                    labels = lbls
                    break

            if labels is None:
                labels = [
                    "< 1",
                    "1-3",
                    "4-7",
                    "8-12",
                    "13-18",
                    "19-24",
                    "25+",
                ]  # Default to mph

            # Build series data efficiently using list comprehension
            series = [
                {
                    "name": f"{labels[i]} {windSpeed_unit_label}",
                    "type": "column",
                    "color": wind_rose_color[i],
                    "zIndex": 106 - i,
                    "stacking": "normal",
                    "fillOpacity": 0.75,
                    "data": series_data[i],
                }
                for i in range(7)
            ]

            return series

        # Special Belchertown Weather Range (radial)
        # https://www.highcharts.com/blog/tutorials/209-the-art-of-the-chart-weather-radials/
        if observation == "weatherRange":

            # Define what we are looking up
            if weatherRange_obs_lookup is not None:
                obs_lookup = weatherRange_obs_lookup
            else:
                log.error(
                    "Error trying to create the weather range graph. "
                    "You are missing the range_type configuration item."
                )

            # Force 1 day if aggregate_interval. These charts are meant to show
            # a column range for high, low and average for a full day.
            if not aggregate_interval:
                aggregate_interval = 86400

            # Get min values
            aggregate_type = "min"
            try:
                (time_start_vt, time_stop_vt, obs_vt) = weewx.xtypes.get_series(
                    obs_lookup,
                    TimeSpan(start_ts, end_ts),
                    archive,
                    aggregate_type,
                    aggregate_interval,
                )
            except Exception as e:
                log.error(
                    f"Error trying to use database binding {binding} to graph observation {obs_lookup}. "
                    f"Error was: {e}."
                )

            self.insert_null_value_timestamps_to_end_ts(
                time_start_vt,
                time_stop_vt,
                obs_vt,
                start_ts,
                end_ts,
                aggregate_interval,
            )

            min_obs_vt = self.converter.convert(obs_vt)

            # Get max values
            aggregate_type = "max"
            try:
                (time_start_vt, time_stop_vt, obs_vt) = weewx.xtypes.get_series(
                    obs_lookup,
                    TimeSpan(start_ts, end_ts),
                    archive,
                    aggregate_type,
                    aggregate_interval,
                )
            except Exception as e:
                log.error(
                    f"Error trying to use database binding {binding} to graph observation {obs_lookup}. "
                    f"Error was: {e}."
                )

            self.insert_null_value_timestamps_to_end_ts(
                time_start_vt,
                time_stop_vt,
                obs_vt,
                start_ts,
                end_ts,
                aggregate_interval,
            )

            max_obs_vt = self.converter.convert(obs_vt)

            # Get avg values
            aggregate_type = "avg"
            try:
                (time_start_vt, time_stop_vt, obs_vt) = weewx.xtypes.get_series(
                    obs_lookup,
                    TimeSpan(start_ts, end_ts),
                    archive,
                    aggregate_type,
                    aggregate_interval,
                )
            except Exception as e:
                log.error(
                    f"Error trying to use database binding {binding} to graph observation {obs_lookup}. "
                    f"Error was: {e}."
                )

            self.insert_null_value_timestamps_to_end_ts(
                time_start_vt,
                time_stop_vt,
                obs_vt,
                start_ts,
                end_ts,
                aggregate_interval,
            )

            avg_obs_vt = self.converter.convert(obs_vt)

            obs_unit = avg_obs_vt[1]
            obs_unit_label = skin_dict["Units"]["Labels"].get(obs_unit, "")

            # Convert to millis and zip all together
            time_ms = [float(x) * 1000 for x in time_start_vt[0]]
            output_data = zip(time_ms, min_obs_vt[0], max_obs_vt[0], avg_obs_vt[0])

            data = {
                "weatherRange": True,
                "obsdata": output_data,
                "range_unit": obs_unit,
                "range_unit_label": obs_unit_label,
            }

            return data

        if observation == "aqiChart":
            global aqi
            global aqi_category
            data = {"aqiChart": True, "obsdata": [{"y": aqi, "category": aqi_category}]}
            return data

        # Hays chart
        if observation == "haysChart":

            start_ts = int(start_ts)
            end_ts = int(end_ts)

            # Set aggregate interval based on timespan and make sure it is
            # between 5 minutes and 1 day
            logging.debug(f"Start time is {start_ts} and end time is {end_ts}")
            aggregate_interval = (end_ts - start_ts) / 360
            if aggregate_interval < 300:
                aggregate_interval = 300
            elif aggregate_interval > 86400:
                aggregate_interval = 86400
            logging.debug(f"Interval is: {aggregate_interval}")

            aggregate_type = "max"
            # Get min values
            obs_lookup = "windSpeed"
            try:
                (time_start_vt, time_stop_vt, obs_vt) = weewx.xtypes.get_series(
                    obs_lookup,
                    TimeSpan(start_ts, end_ts),
                    archive,
                    aggregate_type,
                    aggregate_interval,
                )
            except Exception as e:
                log.error(
                    f"Error trying to use database binding {binding} to graph observation {obs_lookup}. "
                    f"Error was: {e}."
                )

            self.insert_null_value_timestamps_to_end_ts(
                time_start_vt,
                time_stop_vt,
                obs_vt,
                start_ts,
                end_ts,
                aggregate_interval,
            )

            min_obs_vt = self.converter.convert(obs_vt)

            # Get max values
            obs_lookup = "windGust"
            try:
                (time_start_vt, time_stop_vt, obs_vt) = weewx.xtypes.get_series(
                    obs_lookup,
                    TimeSpan(start_ts, end_ts),
                    archive,
                    aggregate_type,
                    aggregate_interval,
                )
            except Exception as e:
                log.error(
                    f"Error trying to use database binding {binding} to graph observation {obs_lookup}. "
                    f"Error was: {e}."
                )

            self.insert_null_value_timestamps_to_end_ts(
                time_start_vt,
                time_stop_vt,
                obs_vt,
                start_ts,
                end_ts,
                aggregate_interval,
            )

            max_obs_vt = self.converter.convert(obs_vt)

            obs_unit = max_obs_vt[1]
            obs_unit_label = skin_dict["Units"]["Labels"].get(obs_unit, "")

            # Convert to millis and zip all together
            time_ms = [float(x) * 1000 for x in time_start_vt[0]]
            output_data = zip(time_ms, min_obs_vt[0], max_obs_vt[0])

            data = {
                "haysChart": True,
                "obsdata": output_data,
                "range_unit": obs_unit,
                "range_unit_label": obs_unit_label,
            }

            return data

        # Special Belchertown Skin rain counter
        if observation == "rainDurTotal":
            obs_lookup = "rainDur"
            # Force sum on this observation
            if aggregate_interval:
                aggregate_type = "sum"
        elif observation == "hailDurTotal":
            obs_lookup = "hailDur"
            # Force sum on this observation
            if aggregate_interval:
                aggregate_type = "sum"
        elif observation == "sunshineDurTotal":
            obs_lookup = "sunshineDur"
            # Force sum on this observation
            if aggregate_interval:
                aggregate_type = "sum"
        elif observation == "rainTotal":
            obs_lookup = "rain"
            # Force sum on this observation
            if aggregate_interval:
                aggregate_type = "sum"
        elif observation == "rainRate":
            obs_lookup = "rainRate"
            # Force max on this observation
            if aggregate_interval:
                aggregate_type = "max"
        else:
            obs_lookup = observation

        #   Special aggregation_subtype measures to enable average rainfall, max and min temperatures to be calculated

        if (
            aggregate_type == "avg"
            and observation == "avgRainfall"
            and aggregate_interval == 86400
        ):
            obs_lookup = "rain"
            obs_label = "Rainfall"

        if xAxis_groupby or len(xAxis_categories) >= 1:
            # Setup the converter - for some reason converter doesn't work
            # for the group_unit_dict in this section Get the target unit
            # nickname (something like 'US' or 'METRIC'):
            target_unit_nickname = config_dict["StdConvert"]["target_unit"]
            # Get the target unit: weewx.US, weewx.METRIC, weewx.METRICWX
            target_unit = weewx.units.unit_constants[target_unit_nickname.upper()]
            # Bind to the appropriate standard converter units
            converter = weewx.units.StdUnitConverters[target_unit]

            # Find what kind of database we're working with and specify the
            # correctly tailored SQL Query for each type of database
            data_binding = config_dict["StdArchive"]["data_binding"]
            database = config_dict["DataBindings"][data_binding]["database"]
            database_type = config_dict["Databases"][database]["database_type"]
            driver = config_dict["DatabaseTypes"][database_type]["driver"]
            xAxis_labels = []
            obsvalues = []

            # Define the xAxis group by for the sql query. Default to month
            if xAxis_groupby == "hour":
                strformat = "%H"
            elif xAxis_groupby == "day":
                strformat = "%d"
            elif xAxis_groupby == "month":
                strformat = "%m"
            elif xAxis_groupby == "year":
                strformat = "%Y"
            elif xAxis_groupby == "":
                strformat = "%m"
            else:
                strformat = "%m"

            # Default catch all in case the aggregate_type isn't defined, default to sum
            if aggregate_type is None:
                aggregate_type = "sum"

            if isinstance(time_length, int):
                order_sql = " ORDER BY dateTime ASC"
            else:
                order_sql = ""

            # Special case for time_length = all, force to use complete days only
            if time_length == "all":
                start_ts = startOfDay(archive.firstGoodStamp()) + 86400
                end_ts = startOfDay(archive.lastGoodStamp())

            # Set up subquery groupby clause
            if xAxis_groupby == "year":
                subqry_groupby = '"%Y"'
            elif xAxis_groupby == "month":
                subqry_groupby = '"%Y%m"'
            elif xAxis_groupby == "day":
                subqry_groupby = '"%Y%m%d"'
            elif xAxis_groupby == "hour":
                subqry_groupby = '"%Y%m%d%H"'
            else:
                subqry_groupby = ""

            if driver == "weedb.sqlite":
                # Use daily summaries where possible - MUST BE FOR WHOLE DAYS determined by start and stop times otherwise use archive
                if (
                    xAxis_groupby != "hour"
                    and isStartOfDay(start_ts)
                    and isStartOfDay(end_ts)
                    and end_ts - start_ts > 0
                ):  # 1 or more exact days
                    # Avg is a special case
                    if aggregate_type == "avg":
                        # Avg(sum) requires a subquery with the correct group by clause
                        if average_type is not None and average_type == "sum":
                            sql_lookup = f"""
                                SELECT dt1 AS {xAxis_groupby}, 
                                AVG(obs1) AS obs 
                                FROM (SELECT strftime('{strformat}', datetime(dateTime, 'unixepoch', 'localtime')) AS dt1, SUM(sum) AS obs1 
                                FROM archive_day_{obs_lookup} WHERE dateTime >= {start_ts} AND dateTime < {end_ts} 
                                GROUP BY strftime({subqry_groupby}, datetime(dateTime, "unixepoch", "localtime"))) 
                                GROUP BY dt1{order_sql};
                            """
                        # avg cases with an average_type
                        elif average_type is not None:
                            sql_lookup = f"""
                                SELECT strftime('{strformat}', datetime(dateTime, 'unixepoch', 'localtime')) AS {xAxis_groupby}, 
                                {aggregate_type}({average_type}) AS obs 
                                FROM archive_day_{obs_lookup} WHERE dateTime >= {start_ts} AND dateTime < {end_ts} 
                                GROUP BY strftime('{strformat}', datetime(dateTime, 'unixepoch', 'localtime')){order_sql};
                            """
                        # remaining avg cases without an average_type use weighted average
                        else:
                            sql_lookup = f"""
                                SELECT strftime('{strformat}', datetime(dateTime, 'unixepoch', 'localtime')) AS {xAxis_groupby}, 
                                SUM(wsum)/SUM(sumtime) AS obs 
                                FROM archive_day_{obs_lookup} WHERE dateTime >= {start_ts} AND dateTime < {end_ts} 
                                GROUP BY strftime('{strformat}', datetime(dateTime, 'unixepoch', 'localtime')){order_sql};
                            """
                    # other aggregate_type cases use direct interrogation of daily summary
                    else:
                        sql_lookup = f"""
                            SELECT strftime('{strformat}', datetime(dateTime, 'unixepoch', 'localtime')) AS {xAxis_groupby}, 
                            {aggregate_type}({aggregate_type}) AS obs 
                            FROM archive_day_{obs_lookup} 
                            WHERE dateTime >= {start_ts} AND dateTime < {end_ts} GROUP BY strftime('{strformat}', datetime(dateTime, 'unixepoch', 'localtime')){order_sql};
                        """
                else:
                    # archive access with no average_type
                    if average_type is None:
                        sql_lookup = f"""
                            SELECT strftime('{strformat}', datetime(dateTime, 'unixepoch', 'localtime')) AS {xAxis_groupby}, 
                            IFNULL({aggregate_type}({obs_lookup}),0) AS obs 
                            FROM archive WHERE dateTime >= {start_ts} AND dateTime < {end_ts} 
                            GROUP BY strftime('{strformat}', datetime(dateTime, 'unixepoch', 'localtime')){order_sql};
                        """

                    # average_type requiring a subquery
                    else:
                        sql_lookup = f"""
                            SELECT dt1 AS {xAxis_groupby}, 
                            {aggregate_type}(obs1) AS obs 
                            FROM (SELECT strftime('{strformat}', datetime(dateTime, 'unixepoch', 'localtime')) AS dt1, 
                            IFNULL({average_type}({obs_lookup}),0) AS obs1 
                            FROM archive WHERE dateTime >= {start_ts} AND dateTime < {end_ts} 
                            GROUP BY strftime({subqry_groupby}, datetime(dateTime, 'unixepoch', 'localtime'))) 
                            GROUP BY dt1{order_sql};
                        """

            elif driver == "weedb.mysql":
                # Use daily summaries where possible - MUST BE FOR WHOLE DAYS determined by start and stop times otherwise use archive
                if (
                    xAxis_groupby != "hour"
                    and isStartOfDay(start_ts)
                    and isStartOfDay(end_ts)
                    and end_ts - start_ts > 0
                ):  # 1 or more exact days
                    # Avg is a special case
                    if aggregate_type == "avg":
                        # Avg(sum) requires a subquery with the correct group by clause
                        if average_type is not None and average_type == "sum":
                            sql_lookup = f"""
                                SELECT dt1 AS {xAxis_groupby}, 
                                AVG(obs1) AS obs 
                                FROM (SELECT FROM_UNIXTIME(dateTime, '%{strformat}') AS dt1, SUM(sum) AS obs1 
                                FROM archive_day_{obs_lookup} WHERE dateTime >= {start_ts} AND dateTime < {end_ts} 
                                GROUP BY FROM_UNIXTIME(dateTime, '{subqry_groupby.strip("%")}') ) AS subq 
                                GROUP BY dt1{order_sql};
                            """
                        # avg cases with an average_type
                        elif average_type is not None:
                            sql_lookup = f"""
                                SELECT FROM_UNIXTIME(dateTime, '%{strformat}') AS {xAxis_groupby}, 
                                {aggregate_type}({average_type}) AS obs 
                                FROM archive_day_{obs_lookup} WHERE dateTime >= {start_ts} AND dateTime < {end_ts} 
                                GROUP BY FROM_UNIXTIME(dateTime, '%{strformat}'){order_sql};
                            """
                        # remaining avg cases without an average_type use weighted average
                        else:
                            sql_lookup = f"""
                                SELECT FROM_UNIXTIME(dateTime, '%{strformat}') AS {xAxis_groupby}, 
                                SUM(wsum)/SUM(sumtime) AS obs 
                                FROM archive_day_{obs_lookup} WHERE dateTime >= {start_ts} AND dateTime < {end_ts} 
                                GROUP BY FROM_UNIXTIME(dateTime, '%{strformat}'){order_sql};
                            """
                    # other aggregate_type cases use direct interrogation of daily summary
                    else:
                        sql_lookup = f"""
                            SELECT FROM_UNIXTIME(dateTime, '%{strformat}') AS {xAxis_groupby}, 
                            {aggregate_type}({aggregate_type}) AS obs 
                            FROM archive_day_{obs_lookup} 
                            WHERE dateTime >= {start_ts} AND dateTime < {end_ts} GROUP BY FROM_UNIXTIME(dateTime, '%{strformat}'){order_sql};
                        """
                else:
                    # archive access with no average_type
                    if average_type is None:
                        sql_lookup = f"""
                            SELECT FROM_UNIXTIME(dateTime, '%{strformat}') AS {xAxis_groupby}, 
                            IFNULL({aggregate_type}({obs_lookup}),0) AS obs 
                            FROM archive WHERE dateTime >= {start_ts} AND dateTime < {end_ts} 
                            GROUP BY FROM_UNIXTIME(dateTime, '%{strformat}'){order_sql};
                        """

                    # average_type requiring a subquery
                    else:
                        sql_lookup = f"""
                            SELECT dt1 AS {xAxis_groupby}, 
                            {aggregate_type}(obs1) AS obs 
                            FROM (SELECT FROM_UNIXTIME(dateTime, '%{strformat}') AS dt1, 
                            IFNULL({average_type}({obs_lookup}),0) AS obs1 
                            FROM archive WHERE dateTime >= {start_ts} AND dateTime < {end_ts} 
                            GROUP BY FROM_UNIXTIME(dateTime, '{subqry_groupby.strip("%")}')) AS subq 
                            GROUP BY dt1{order_sql};
                        """

            # Setup values for the converter
            try:
                obs_group = weewx.units.obs_group_dict[obs_lookup]
                obs_unit_from_target_unit = converter.group_unit_dict[obs_group]
            except Exception:
                # This observation doesn't exist within WeeWX schema so nothing
                # to convert, so set None type
                obs_group = None
                obs_unit_from_target_unit = None

            # introduce test to catch any sql errors; a try / except sequence

            try:
                query = archive.genSql(sql_lookup)
            except Exception as e:
                log.error(f"SQL error in sql_lookup. The error is: {e}")

            for row in query:
                xAxis_labels.append(row[0])
                row_tuple = (row[1], obs_unit_from_target_unit, obs_group)
                if special_target_unit:
                    row_converted = weewx.units.convert(row_tuple, special_target_unit)
                else:
                    row_converted = self.converter.convert(row_tuple)
                obsvalues.append(row_converted[0])

            # If the values are to be mirrored, we need to make them negative
            if mirrored_value:
                for i in obsvalues:
                    if i is not None:
                        i = -i

            # Return a dict which has the value for if we need to add labels
            # from sql or not.
            if len(xAxis_categories) == 0:
                data = {
                    "use_sql_labels": True,
                    "xAxis_groupby_labels": xAxis_labels,
                    "obsdata": obsvalues,
                }
            else:
                data = {
                    "use_sql_labels": False,
                    "xAxis_groupby_labels": "",
                    "obsdata": obsvalues,
                }
            return data

        # Begin standard observation lookups
        try:
            (time_start_vt, time_stop_vt, obs_vt) = weewx.xtypes.get_series(
                obs_lookup,
                TimeSpan(start_ts, end_ts),
                archive,
                aggregate_type,
                aggregate_interval,
            )
        except Exception as e:
            log.error(
                f"Error trying to use database binding {binding} to graph observation {obs_lookup}. Error was: {e}."
            )

        self.insert_null_value_timestamps_to_end_ts(
            time_start_vt, time_stop_vt, obs_vt, start_ts, end_ts, aggregate_interval
        )

        if special_target_unit:
            log.debug(
                f"unit_group={obs_vt[2]} source_unit={obs_vt[1]} special_target_unit={special_target_unit}"
            )
            obs_vt = weewx.units.Converter({obs_vt[2]: special_target_unit}).convert(
                obs_vt
            )
        else:
            obs_vt = self.converter.convert(obs_vt)

        # Special handling for the rainDur.
        if observation == "rainDurTotal":
            rainDur_count = 0
            obs_round_vt = []
            for rainDur in obs_vt[0]:
                if rainDur is None or rainDur == "":
                    obs_round_vt.append(rainDur)
                    continue
                rainDur_count = rainDur_count + rainDur
                obs_round_vt.append(round(rainDur_count, 2))
        # Special handling for the rainDur.
        elif observation == "hailDurTotal":
            hailDur_count = 0
            obs_round_vt = []
            for hailDur in obs_vt[0]:
                if hailDur is None or hailDur == "":
                    obs_round_vt.append(hailDur)
                    continue
                hailDur_count = hailDur_count + hailDur
                obs_round_vt.append(round(hailDur_count, 2))
        elif observation == "sunshineDurTotal":
            sunshineDur_count = 0
            obs_round_vt = []
            for sunshineDur in obs_vt[0]:
                if sunshineDur is None or sunshineDur == "":
                    obs_round_vt.append(sunshineDur)
                    continue
                sunshineDur_count = sunshineDur_count + sunshineDur
                obs_round_vt.append(round(sunshineDur_count, 2))

        # Special handling for the rain.
        elif observation == "rainTotal":
            # The WeeWX "rain" observation is really "bucket tips". This
            # special counter increments the bucket tips over timespan to
            # return rain total.
            rain_count = 0
            obs_round_vt = []
            for rain in obs_vt[0]:
                # If the rain value is None or "", add it as 0.0
                if rain is None or rain == "":
                    # rain = 0.0
                    # Do not keep adding None or empty results, so that
                    # full-length charts (like WeeWX v4 archiveYearSpan) don't
                    # have a line that continues past the last actual plot
                    obs_round_vt.append(rain)
                    continue
                rain_count = rain_count + rain
                obs_round_vt.append(round(rain_count, 2))
        else:
            # Send all other observations through the usual process, except
            # Barometer for finer detail
            if observation == "barometer":
                usage_round = int(
                    skin_dict["Units"]["StringFormats"].get(obs_vt[1], "1f")[-2]
                )
                obs_round_vt = [
                    round(x, usage_round) if x is not None else None for x in obs_vt[0]
                ]
            else:
                try:
                    if obs_round is None:
                        usage_round = int(
                            skin_dict["Units"]["StringFormats"].get(obs_vt[1], "2f")[-2]
                        )
                    else:
                        usage_round = int(obs_round) + 1
                except ValueError:
                    log.info(
                        f"Observation {observation} is using unit {obs_vt[1]} "
                        f"""that returns {skin_dict["Units"]["StringFormats"].get(obs_vt[1])} """
                        "for StringFormat, rather than float point decimal format value - using 0 as rounding"
                    )
                    usage_round = 0

                obs_round_vt = [self.round_none(x, usage_round) for x in obs_vt[0]]

        # "Today" charts, "timespan_specific" charts and floating timespan
        # charts have the point timestamp on the stop time so we don't see the
        # previous minute in the tooltip. (e.g. 4:59 instead of 5:00)
        # Everything else has it on the start time so we don't see the next day
        # in the tooltip (e.g. Jan 2 instead of Jan 1)
        try:
            if not aggregate_type:
                point_timestamp = time_stop_vt
            elif aggregate_interval and (
                aggregate_interval == 3600 or aggregate_interval == 2629800
            ):
                point_timestamp = time_start_vt
            else:
                point_timestamp = (
                    [(x + y) / 2.0 for x, y in zip(time_start_vt[0], time_stop_vt[0])],
                    time_start_vt[1],
                    time_start_vt[2],
                )
        except Exception:
            point_timestamp = time_stop_vt

        # If the values are to be mirrored, we need to make them negative
        if mirrored_value:
            for i in range(len(obs_round_vt)):
                if obs_round_vt[i] is not None:
                    obs_round_vt[i] = -obs_round_vt[i]

        time_ms = [float(x) * 1000 for x in point_timestamp[0]]
        data = zip(time_ms, obs_round_vt)

        return data

    def insert_null_value_timestamps_to_end_ts(
        self, time_start_vt, time_stop_vt, obs_vt, start_ts, end_ts, interval
    ):
        """
        In WeeWX 4.5.1 xtypes.py was modified to not return any data points which didn't exist in the archive database.
        This function adds the 'future' data points from the last timestamp in the list up until end_ts with None entries.
        This means that graphs still have the option of showing a full day or month or year on the x axis depending on the time_length specfied.
        """
        count = 0

        if interval is not None:
            try:
                ts = time_start_vt[0][-1] + interval
            except Exception:
                ts = start_ts

            while ts < end_ts:
                time_start_vt[0].append(ts)
                time_stop_vt[0].append(ts)
                ts = ts + interval
                count = count + 1

        for i in range(count):
            obs_vt[0].append(None)

    def round_none(self, value, places):
        """Round value to 'places' places but also permit a value of None"""
        if value is not None:
            try:
                value = round(value, places)
            except Exception:
                value = None
        return value

    def timespan_year_to_now(self, time_ts, grace=1, years_ago=0):
        """
        In WeeWX 4 the get_series() for archiveYearSpan returns the full 365
        day chart.  if users do not want a full year (with empty data) and
        would rather a Jan 1 to "now", then they can use this custom timespan

        This is taken right from weewx, but adapted to end at the current
        timestamp, and not the following Jan 1.
        """
        if time_ts is None:
            return None
        time_ts -= grace
        _day_date = datetime.date.fromtimestamp(time_ts)
        return TimeSpan(
            int(time.mktime((_day_date.year - years_ago, 1, 1, 0, 0, 0, 0, 0, -1))),
            int(float(time_ts)),
        )

    def create_windrose_data(self, windDir_list, windSpeed_list):
        # List comprehension borrowed from weewx-wd extension
        # Create windrose_list container and initialise to all 0s
        windrose_list = [0.0 for x in range(16)]

        # Step through each windDir and add corresponding windSpeed to windrose_list
        x = 0
        while x < len(windDir_list):
            # Only want to add windSpeed if both windSpeed and windDir have a value
            if windSpeed_list[x] is not None and windDir_list[x] is not None:
                # Add the windSpeed value to the corresponding element of our
                # windrose list
                windrose_list[
                    int((windDir_list[x] + 11.25) / 22.5) % 16
                ] += windSpeed_list[x]
            x += 1

        # Step through our windrose list and round all elements to 1 decimal place
        y = 0
        while y < len(windrose_list):
            windrose_list[y] = round(windrose_list[y], 1)
            y += 1
        # Need to return a string of the list elements comma separated, no
        # spaces and bounded by [ and ]
        # windroseData = '[' + ','.join(str(z) for z in windrose_list) + ']'
        return windrose_list

    def highcharts_series_options_to_float(self, d):
        """
        Recurse through all the series options and set any strings that
        should be numbers to float.
        https://stackoverflow.com/a/54565277/1177153
        """

        try:
            for k, v in d.items():
                if isinstance(v, dict):
                    # Check nested dicts
                    self.highcharts_series_options_to_float(v)
                else:
                    try:
                        v = to_float(v)
                        d.update({k: v})
                    except Exception:
                        pass
            return d
        except Exception:
            # This item isn't a dict, so return it back
            return d
