## Home page block "onthisday" (see home_sections in skin.conf): today against the same date in past years
#set $otd = $on_this_day_summary
#if $otd
#import datetime
#try
 #set $otd_date = $datetime.datetime.fromtimestamp($current.dateTime.raw).strftime('%d. %B')
#except
 #set $otd_date = datetime.datetime.today().strftime('%d. %B')
#end try

##set $otd_date = '<time data-ts="%s" data-format="otd_time_records_page_rainfall_range_begin"></time>' % $current.dateTime.raw
<section class="wx-onthisday">
    <div class="wx-section-head">
        <h4 style="text-align: center; class="wx-section-title"><i class="fa fa-calendar" aria-hidden="true"></i> $obs.label.records_on_this_day $otd_date </h4>
    </div>
    #if $otd.note
    #set $note = str($obs.label["onthisday_" + $otd.note]).replace("{date}", $otd_date).replace("{year}", str($otd.note_year))
    <p class="wx-otd-note wx-otd-$otd.note">$note</p>
    #end if
    #if $otd.today
    <p class="wx-otd-today-line"><i class="wx-otd-key wx-otd-key-today"></i>$obs.label.onthisday_today: $otd.today.low – $otd.today.high</p>
    #end if
    <div class="wx-otd-scale">
        <div class="wx-otd-end wx-otd-cold">
            <div class="wx-otd-label">$obs.label.onthisday_record_low</div>
            <div class="wx-otd-value">$otd.low</div>
            <div class="wx-otd-year">$str($obs.label.onthisday_record_year).replace("{year}", str($otd.low_year))</div>
        </div>
        <div class="wx-otd-track">
            <span class="wx-otd-average" style="left: ${otd.avg_bar.left}%; width: ${otd.avg_bar.width}%"></span>
            #if $otd.today_bar
            <span class="wx-otd-today" style="left: ${otd.today_bar.left}%; width: ${otd.today_bar.width}%"></span>
            #end if
        </div>
        <div class="wx-otd-end wx-otd-warm">
            <div class="wx-otd-label">$obs.label.onthisday_record_high</div>
            <div class="wx-otd-value">$otd.high</div>
            <div class="wx-otd-year">$str($obs.label.onthisday_record_year).replace("{year}", str($otd.high_year))</div>
        </div>
    </div>
    <div class="wx-otd-legend">
        <span><i class="wx-otd-key wx-otd-key-average"></i>$obs.label.onthisday_average: $otd.avg_low – $otd.avg_high</span>
    </div>
</section>
#end if
