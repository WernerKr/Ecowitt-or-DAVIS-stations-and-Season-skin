"""
This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later
version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE.  See the GNU General Public License for more details.

                 Installer for Ecowitt Local HTTP API Driver

Version: 0.2.5                                       Date: 13 Oct 2025

Revision History
    10 July 2025      v0.1.0
        -   initial implementation
    31 July 2025      v0.2.0
        -   all now ready
    7 Aug 2025      v0.2.1
        -   renamed wn31_sig/rssi to wh31_sig/rssi
    08 Aug 2025            v0.2.2
        - dB -> dBm

    21 Aug 2025            v0.2.3
        - correction if lightning timestamp = "--/--/---- --:--:--"
        - Error message hidden: process_lightning_array: Error processing distance: Could not convert '--.-' to a float
        - added console_batt, consoleext_batt, charge_stat (WS6210)

    04 Oct 2025            v0.2.4
        - if driver is used as a service, Rain and Piezo Rain are only mapped as t_rain and p_rain in loop data, 
          in archive ( SDcard, cloud ) Rain and Hail are still mapped as rain and hail! 
          Reason for this: if Ecowittcustom is used as a station, Rain and Piezo Rain are recorded multiple times.
        - new Sensor wn38 (BGT)
        - bug with 'PM2.5 ch1' .. 'ch4' and Data from SDCard solved (correct is 'PM2.5 CH1' )
        - added soilad1..16

    13 Oct 2025            v0.2.5
        - added apName
        - added stationtype
        - Calculates WBGT when not transmitted
        - 24h rain (piezo) from Ecowitt cloud
        - workaround if no SDCard inserted (thanks to rosensama )  

"""

# python imports
import configobj
import io
from setup import ExtensionInstaller

# WeeWX imports
import weewx


REQUIRED_WEEWX_VERSION = "4.0.0"
DRIVER_VERSION = "0.2.5"
# define our config as a multiline string so we can preserve comments


ecowitt_config = """

# Whether to try indefinitely to load the driver
loop_on_init = 1


[EcowittHttp]
    # This section is for the Ecowitt Local HTTP API driver.
    # The driver to use:
    driver = user.ecowitt_http
    
    # how often to poll the device
    poll_interval = 20
    # how many attempts to contact the device before giving up
    max_tries = 3
    # wait time in seconds between retries to contact the device
    retry_wait = 5
    # max wait for device to respond to a HTTP request
    url_timeout = 10
    
    # whether to show all battery state data including nonsense data and 
    # sensors that are disabled sensors and connecting
    show_all_batt = False

    # whether to always log unknown API fields, unknown fields are always 
    # logged at the debug level, this will log them at the info level
    log_unknown_fields = False
    
    # do we show registered sensor data only
    only_registered = True

    # Is a WN32P used for indoor temperature, humidity and pressure - default = False
    wn32_indoor = False

    # Is a WN32 used for outdoor temperature and humidity - default = False
    wn32_outdoor = False

    # How often to check for device firmware updates, 0 disables firmware 
    # update checks. Available firmware updates are logged.
    firmware_update_check_interval = 86400
    
    # debug list: 
    #debug = rain, raindelta, wind, lightning, loop, sensors, parser, catchup, collector, archive

    # The device IP address:
    ip_address = www.xxx.yyy.zzz

    api_key = 00000000-1111-2222-3333-444444444444
    app_key = DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD
    mac = 55:44:33:22:11:00

    catchup_grace = 0
    
    [[catchup]]
    # source = either, both, net, device  ## not set = None, default is then either or both

##############################################################################
[StdReport]

    [[SeasonsEcowitt]]
# lang = de
        lang = en
        skin = SeasonsEcowitt
        enable = false
        HTML_ROOT = /var/www/html/weewx

##############################################################################
[DataBindings]
    
    [[wx_binding]]
        schema_new = schemas.wview_ecowitt.schema
        schema_rssi = schemas.wview_ecowittrssi.schema

##############################################################################
[Databases]
    
    [[archive_sqlite]]
        database_name_new = weewx_ecowitt.sdb
        database_type = SQLite

##############################################################################

[StdWXCalculate]

    [[Calculations]]
        rain = prefer_hardware
        hail = prefer_hardware
        t_rain = prefer_hardware
        p_rain = prefer_hardware
        lightning_distance = prefer_hardware
        lightning_strike_count = prefer_hardware

[StdArchive]
    record_generation = software
    record_generation_new = software

[StdCalibrate]

    [[Corrections]]
        luminosity = radiation * 126.7 if radiation is not None else None

        pb = heap if heap is not None else None
        
        lightning_distance_save = lightning_dist if lightning_dist is not None else None
        lightning_distance = lightning_dist if lightning_strike_count > 0 else None
        lightning_noise_count = lightning_strike_count if lightning_strike_count > 0 else None

        # from v0.2.4  is this required if the driver is used as a Data_Service
        # data_services = user.ecowitt_http.EcowittHttpService
        #rain = t_rain if t_rain is not None
        #hail = p_rain if p_rain is not None #if hail is used as default piezo rain

           
[Accumulator]
        # GW1000, Ecowittcustom, Ecowitt local HTTP API driver extractors
    [[model]]
        accumulator = firstlast
        extractor = last
    [[stationtype]]
        accumulator = firstlast
        extractor = last
    [[apName]]
        accumulator = firstlast
        extractor = last

    [[gain0]]
        extractor = last
    [[gain1]]
        extractor = last
    [[gain2]]
        extractor = last
    [[gain3]]
        extractor = last
    [[gain4]]
        extractor = last
    [[gain5]]
        extractor = last
    
    [[lightning_distance]]
        extractor = last
    [[lightning_strike_count]]
        extractor = sum
    [[lightning_last_det_time]]
        extractor = last
    [[lightningcount]]
        extractor = last
    [[lightning_noise_count]]
        extractor = sum
    
    [[maxdailygust]]
        extractor = last
    [[daymaxwind]]
        extractor = last
    [[windspdmph_avg10m]]
        extractor = last
    [[winddir_avg10m]]
        extractor = last
    
    [[rainRate]]
        extractor = max
    [[stormRain]]
        extractor = last
    [[hourRain]]
        extractor = last
    [[dayRain]]
        extractor = last
    [[weekRain]]
        extractor = last
    [[monthRain]]
        extractor = last
    [[yearRain]]
        extractor = last
    [[totalRain]]
        extractor = last
    
    [[rrain_piezo]]
        extractor = max
    [[erain_piezo]]
        extractor = last
    [[hrain_piezo]]
        extractor = last
    [[drain_piezo]]
        extractor = last
    [[wrain_piezo]]
        extractor = last
    [[mrain_piezo]]
        extractor = last
    [[yrain_piezo]]
        extractor = last

    [[t_rainyear]]
        extractor = last
    [[p_rainyear]]
        extractor = last

    [[p_rain]]
        extractor = sum
    [[t_rain]]
        extractor = sum

    [[p_rainrate]]
        extractor = max
    [[p_eventrain]]
        extractor = last
    [[p_hourrain]]
        extractor = last
    [[p_dayrain]]
        extractor = last
    [[p_weekrain]]
        extractor = last
    [[p_monthrain]]
        extractor = last
    
    [[dayHail]]
        extractor = last
    [[hail]]
        extractor = sum
    
    [[vpd]]
        extractor = last
    [[depth_ch1]]
        extractor = last
    [[depth_ch2]]
        extractor = last
    [[depth_ch3]]
        extractor = last
    [[depth_ch4]]
        extractor = last
    
    [[pm2_51_24hav]]
        extractor = last
    [[pm2_52_24hav]]
        extractor = last
    [[pm2_53_24hav]]
        extractor = last
    [[pm2_54_24hav]]
        extractor = last
    [[24havpm255]]
        extractor = last
    
    [[pm2_51_24h_avg]]
        extractor = last
    [[pm2_52_24h_avg]]
        extractor = last
    [[pm2_53_24h_avg]]
        extractor = last
    [[pm2_54_24h_avg]]
        extractor = last
    [[pm2_55_24h_avg]]
        extractor = last
    [[pm10_24h_avg]]
        extractor = last
    [[co2_24h_avg]]
        extractor = last
    
    [[wn25_batt]]
        extractor = last
    [[wh25_batt]]
        extractor = last
    [[wh26_batt]]
        extractor = last
    [[wh31_ch1_batt]]
        extractor = last
    [[wh31_ch2_batt]]
        extractor = last
    [[wh31_ch3_batt]]
        extractor = last
    [[wh31_ch4_batt]]
        extractor = last
    [[wh31_ch5_batt]]
        extractor = last
    [[wh31_ch6_batt]]
        extractor = last
    [[wh31_ch7_batt]]
        extractor = last
    [[wh31_ch8_batt]]
        extractor = last
    [[wn35_ch1_batt]]
        extractor = last
    [[wn35_ch2_batt]]
        extractor = last
    [[wn35_ch3_batt]]
        extractor = last
    [[wn35_ch4_batt]]
        extractor = last
    [[wn35_ch5_batt]]
        extractor = last
    [[wn35_ch6_batt]]
        extractor = last
    [[wn35_ch7_batt]]
        extractor = last
    [[wn35_ch8_batt]]
        extractor = last
    [[wh40_batt]]
        extractor = last
    [[wh41_ch1_batt]]
        extractor = last
    [[wh41_ch2_batt]]
        extractor = last
    [[wh41_ch3_batt]]
        extractor = last
    [[wh41_ch4_batt]]
        extractor = last
    [[wh45_batt]]
        extractor = last
    [[wh51_ch1_batt]]
        extractor = last
    [[wh51_ch2_batt]]
        extractor = last
    [[wh51_ch3_batt]]
        extractor = last
    [[wh51_ch4_batt]]
        extractor = last
    [[wh51_ch5_batt]]
        extractor = last
    [[wh51_ch6_batt]]
        extractor = last
    [[wh51_ch7_batt]]
        extractor = last
    [[wh51_ch8_batt]]
        extractor = last
    [[wh51_ch9_batt]]
        extractor = last
    [[wh51_ch10_batt]]
        extractor = last
    [[wh51_ch11_batt]]
        extractor = last
    [[wh51_ch12_batt]]
        extractor = last
    [[wh51_ch13_batt]]
        extractor = last
    [[wh51_ch14_batt]]
        extractor = last
    [[wh51_ch15_batt]]
        extractor = last
    [[wh51_ch16_batt]]
        extractor = last
    [[wh55_ch1_batt]]
        extractor = last
    [[wh55_ch2_batt]]
        extractor = last
    [[wh55_ch3_batt]]
        extractor = last
    [[wh55_ch4_batt]]
        extractor = last
    [[wh57_batt]]
        extractor = last
    [[wh65_batt]]
        extractor = last
    [[wh68_batt]]
        extractor = last
    [[wh69_batt]]
        extractor = last
    [[ws80_batt]]
        extractor = last
    [[ws85_batt]]
        extractor = last
    [[ws90_batt]]
        extractor = last
    [[ws85cap_volt]]
        extractor = last
    [[ws90cap_volt]]
        extractor = last
    [[ws1900batt]]
        extractor = last
    [[console_batt]]
        extractor = last
    [[ldsbatt1]]
        extractor = last
    [[ldsbatt2]]
        extractor = last
    [[ldsbatt3]]
        extractor = last
    [[ldsbatt4]]
        extractor = last

    # End Ecowitt local HTTP API driver, Ecowittcustom driver extractors

"""

# construct our config dict
ecowitt_dict = configobj.ConfigObj(io.StringIO(ecowitt_config))


def version_compare(v1, v2):
    """Basic 'distutils' and 'packaging' free version comparison.

    v1 and v2 are WeeWX version numbers in string format.

    Returns:
        0 if v1 and v2 are the same
        -1 if v1 is less than v2
        +1 if v1 is greater than v2
    """

    import itertools
    mash = itertools.zip_longest(v1.split('.'), v2.split('.'), fillvalue='0')
    for x1, x2 in mash:
        if x1 > x2:
            return 1
        if x1 < x2:
            return -1
    return 0


def loader():
    return EcowittHttpInstaller()


class EcowittHttpInstaller(ExtensionInstaller):
    def __init__(self):
        if version_compare(weewx.__version__, REQUIRED_WEEWX_VERSION) < 0:
            msg = "%s requires WeeWX %s or greater, found %s" % (''.join(('Ecowitt local HTTP API driver ', DRIVER_VERSION)),
                                                                 REQUIRED_WEEWX_VERSION,
                                                                 weewx.__version__)
            raise weewx.UnsupportedFeature(msg)
        super().__init__(
            version=DRIVER_VERSION,
            name='Ecowitt_HTTP',
            description='WeeWX driver for devices supporting the Ecowitt local HTTP API.',
            author="Gary Roderick and Werner Krenn",
            author_email="",
            files=[
                ('bin/user', [
                    'bin/user/ecowitt_http.py',
                    'bin/user/historygenerator3.py',
                    'bin/user/sunrainduration.py',
                    'bin/user/add_ecowitt_allsignaldata_v5.sh',
                    'bin/user/add_ecowitt_allsoiladdata_v5.sh',
                    'bin/user/add_ecowitt_allrssidata_1.sh',
                    'bin/user/add_ecowitt_data_v5.sh',
                ]),
                ('bin/schemas', [
                    'bin/schemas/wview_ecowitt.py',
                    'bin/schemas/wview_ecowittrssi.py',
                ]),
                ('skins', [
                    'skins/SeasonsEcowitt/index.html.tmpl',
                    'skins/SeasonsEcowitt/telemetry.html.tmpl',
                    'skins/SeasonsEcowitt/celestial.html.tmpl',
                    'skins/SeasonsEcowitt/rss.xml.tmpl',
                    'skins/SeasonsEcowitt/statistics.html.tmpl',
                    'skins/SeasonsEcowitt/tabular.html.tmpl',
                    'skins/SeasonsEcowitt/skin.conf',
                    'skins/SeasonsEcowitt/seasons.css',
                    'skins/SeasonsEcowitt/seasons.js',
                    'skins/SeasonsEcowitt/current.inc',
                    'skins/SeasonsEcowitt/hilo.inc',
                    'skins/SeasonsEcowitt/sensors.inc',
                    'skins/SeasonsEcowitt/about.inc',
                    'skins/SeasonsEcowitt/titlebar.inc',
                    'skins/SeasonsEcowitt/statistics.inc',
                    'skins/SeasonsEcowitt/analytics.inc',
                    'skins/SeasonsEcowitt/celestial.inc',
                    'skins/SeasonsEcowitt/identifier.inc',
                    'skins/SeasonsEcowitt/map.inc',
                    'skins/SeasonsEcowitt/sunmoon.inc',
                    'skins/SeasonsEcowitt/radar.inc',
                    'skins/SeasonsEcowitt/satellite.inc',
                    'skins/SeasonsEcowitt/cmon.inc',
                    'skins/SeasonsEcowitt/Batt0.png',
                    'skins/SeasonsEcowitt/Batt1.png',
                    'skins/SeasonsEcowitt/Batt2.png',
                    'skins/SeasonsEcowitt/Batt3.png',
                    'skins/SeasonsEcowitt/Batt4.png',
                    'skins/SeasonsEcowitt/Batt5.png',
                    'skins/SeasonsEcowitt/Batt6.png',
                    'skins/SeasonsEcowitt/Batt6x.png',
                    'skins/SeasonsEcowitt/lang/de.conf',
                    'skins/SeasonsEcowitt/lang/en.conf',
                    'skins/SeasonsEcowitt/NOAA/NOAA-%Y-%m.txt.tmpl',
                    'skins/SeasonsEcowitt/NOAA/NOAA-%Y.txt.tmpl',
                    'skins/SeasonsEcowitt/font/OpenSans-Bold.ttf',
                    'skins/SeasonsEcowitt/font/OpenSans-Regular.ttf',
                    'skins/SeasonsEcowitt/font/OpenSans.woff',
                    'skins/SeasonsEcowitt/font/OpenSans.woff2',
                    'skins/SeasonsEcowitt/font/OFL.txt',
                    'skins/SeasonsEcowitt/font/license.txt',
                ])
            ],
            config=ecowitt_dict
        )